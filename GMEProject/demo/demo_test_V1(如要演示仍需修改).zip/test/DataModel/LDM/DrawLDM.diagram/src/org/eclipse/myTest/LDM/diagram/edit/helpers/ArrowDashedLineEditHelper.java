package org.eclipse.myTest.LDM.diagram.edit.helpers;

/**
 * @generated
 */
public class ArrowDashedLineEditHelper extends
		org.eclipse.myTest.LDM.diagram.edit.helpers.MyLDMBaseEditHelper {
}
