package org.eclipse.myTest.LDM.diagram.edit.helpers;

/**
 * @generated
 */
public class ArrowSolidLineEditHelper extends
		org.eclipse.myTest.LDM.diagram.edit.helpers.MyLDMBaseEditHelper {
}
