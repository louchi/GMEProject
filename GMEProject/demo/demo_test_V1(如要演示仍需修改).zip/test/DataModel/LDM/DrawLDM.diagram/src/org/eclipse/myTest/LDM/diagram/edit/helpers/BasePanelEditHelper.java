package org.eclipse.myTest.LDM.diagram.edit.helpers;

/**
 * @generated
 */
public class BasePanelEditHelper extends
		org.eclipse.myTest.LDM.diagram.edit.helpers.MyLDMBaseEditHelper {
}
