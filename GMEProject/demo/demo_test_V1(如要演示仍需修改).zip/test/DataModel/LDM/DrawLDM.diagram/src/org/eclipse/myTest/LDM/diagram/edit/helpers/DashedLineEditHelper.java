package org.eclipse.myTest.LDM.diagram.edit.helpers;

/**
 * @generated
 */
public class DashedLineEditHelper extends
		org.eclipse.myTest.LDM.diagram.edit.helpers.MyLDMBaseEditHelper {
}
