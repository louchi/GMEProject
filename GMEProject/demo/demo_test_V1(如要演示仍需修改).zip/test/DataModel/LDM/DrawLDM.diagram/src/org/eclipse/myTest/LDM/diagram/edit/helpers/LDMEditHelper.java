package org.eclipse.myTest.LDM.diagram.edit.helpers;

/**
 * @generated
 */
public class LDMEditHelper extends
		org.eclipse.myTest.LDM.diagram.edit.helpers.MyLDMBaseEditHelper {
}
