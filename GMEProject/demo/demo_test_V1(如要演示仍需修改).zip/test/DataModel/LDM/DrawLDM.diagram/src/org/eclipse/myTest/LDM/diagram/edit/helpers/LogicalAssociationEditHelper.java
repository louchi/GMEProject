package org.eclipse.myTest.LDM.diagram.edit.helpers;

/**
 * @generated
 */
public class LogicalAssociationEditHelper extends
		org.eclipse.myTest.LDM.diagram.edit.helpers.MyLDMBaseEditHelper {
}
