package org.eclipse.myTest.LDM.diagram.edit.helpers;

/**
 * @generated
 */
public class SolidLineEditHelper extends
		org.eclipse.myTest.LDM.diagram.edit.helpers.MyLDMBaseEditHelper {
}
