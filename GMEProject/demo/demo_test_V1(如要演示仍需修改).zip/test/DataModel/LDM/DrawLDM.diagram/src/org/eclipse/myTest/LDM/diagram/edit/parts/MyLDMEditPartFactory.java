package org.eclipse.myTest.LDM.diagram.edit.parts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

/**
 * @generated
 */
public class MyLDMEditPartFactory implements EditPartFactory {

	/**
	 * @generated
	 */
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getVisualID(view)) {

			case org.eclipse.myTest.LDM.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.BasePanelEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewNameEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.LDMEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.LDMEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.LDMNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.LDMNameEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationNameEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityNameEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineNameEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineNameEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineNameEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart(
						view);

			case org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineNameEditPart(
						view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	 * @generated
	 */
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	 * @generated
	 */
	public static CellEditorLocator getTextCellEditorLocator(
			ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE
				.getTextCellEditorLocator(source);
	}

}
