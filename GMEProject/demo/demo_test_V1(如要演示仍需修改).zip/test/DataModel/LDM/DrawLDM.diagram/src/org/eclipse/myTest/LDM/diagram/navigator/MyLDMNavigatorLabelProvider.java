package org.eclipse.myTest.LDM.diagram.navigator;

import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class MyLDMNavigatorLabelProvider extends LabelProvider implements
		ICommonLabelProvider, ITreePathLabelProvider {

	/**
	 * @generated
	 */
	static {
		org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem
				&& !isOwnView(((org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem) element)
						.getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	 * @generated
	 */
	public Image getImage(Object element) {
		if (element instanceof org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorGroup) {
			org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorGroup group = (org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorGroup) element;
			return org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().getBundledImage(group.getIcon());
		}

		if (element instanceof org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem) {
			org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem navigatorItem = (org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		return super.getImage(element);
	}

	/**
	 * @generated
	 */
	public Image getImage(View view) {
		switch (org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.LDM.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Diagram?LDM.myTest.eclipse.org?BasePanel", org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.BasePanel_1000); //$NON-NLS-1$
		case org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?LDM.myTest.eclipse.org?DashedLine", org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.DashedLine_4004); //$NON-NLS-1$
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?LDM.myTest.eclipse.org?ArrowDashedLine", org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowDashedLine_4003); //$NON-NLS-1$
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?LDM.myTest.eclipse.org?ArrowSolidLine", org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowSolidLine_4001); //$NON-NLS-1$
		case org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?LDM.myTest.eclipse.org?SolidLine", org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.SolidLine_4002); //$NON-NLS-1$
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?LDM.myTest.eclipse.org?LogicalEntity", org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalEntity_2004); //$NON-NLS-1$
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?LDM.myTest.eclipse.org?LogicalAssociation", org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalAssociation_2003); //$NON-NLS-1$
		case org.eclipse.myTest.LDM.diagram.edit.parts.LDMEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?LDM.myTest.eclipse.org?LDM", org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LDM_2002); //$NON-NLS-1$
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?LDM.myTest.eclipse.org?LogicalView", org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalView_2001); //$NON-NLS-1$
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
				.getInstance().getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null
				&& elementType != null
				&& org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
						.isKnownElementType(elementType)) {
			image = org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
					.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public String getText(Object element) {
		if (element instanceof org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorGroup) {
			org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorGroup group = (org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem) {
			org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem navigatorItem = (org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		return super.getText(element);
	}

	/**
	 * @generated
	 */
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.LDM.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
			return getBasePanel_1000Text(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
			return getDashedLine_4004Text(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
			return getArrowDashedLine_4003Text(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
			return getArrowSolidLine_4001Text(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
			return getSolidLine_4002Text(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityEditPart.VISUAL_ID:
			return getLogicalEntity_2004Text(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationEditPart.VISUAL_ID:
			return getLogicalAssociation_2003Text(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LDMEditPart.VISUAL_ID:
			return getLDM_2002Text(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewEditPart.VISUAL_ID:
			return getLogicalView_2001Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	 * @generated
	 */
	private String getBasePanel_1000Text(View view) {
		return ""; //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private String getDashedLine_4004Text(View view) {
		IParser parser = org.eclipse.myTest.LDM.diagram.providers.MyLDMParserProvider
				.getParser(
						org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.DashedLine_4004,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
								.getType(org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 6004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getArrowDashedLine_4003Text(View view) {
		IParser parser = org.eclipse.myTest.LDM.diagram.providers.MyLDMParserProvider
				.getParser(
						org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowDashedLine_4003,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
								.getType(org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 6003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getArrowSolidLine_4001Text(View view) {
		IParser parser = org.eclipse.myTest.LDM.diagram.providers.MyLDMParserProvider
				.getParser(
						org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowSolidLine_4001,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
								.getType(org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 6001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getSolidLine_4002Text(View view) {
		IParser parser = org.eclipse.myTest.LDM.diagram.providers.MyLDMParserProvider
				.getParser(
						org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.SolidLine_4002,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
								.getType(org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 6002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getLogicalEntity_2004Text(View view) {
		IParser parser = org.eclipse.myTest.LDM.diagram.providers.MyLDMParserProvider
				.getParser(
						org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalEntity_2004,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
								.getType(org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 5004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getLogicalAssociation_2003Text(View view) {
		IParser parser = org.eclipse.myTest.LDM.diagram.providers.MyLDMParserProvider
				.getParser(
						org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalAssociation_2003,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
								.getType(org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 5003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getLDM_2002Text(View view) {
		IParser parser = org.eclipse.myTest.LDM.diagram.providers.MyLDMParserProvider
				.getParser(
						org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LDM_2002,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
								.getType(org.eclipse.myTest.LDM.diagram.edit.parts.LDMNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 5002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getLogicalView_2001Text(View view) {
		IParser parser = org.eclipse.myTest.LDM.diagram.providers.MyLDMParserProvider
				.getParser(
						org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalView_2001,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
								.getType(org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 5001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	 * @generated
	 */
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return org.eclipse.myTest.LDM.diagram.edit.parts.BasePanelEditPart.MODEL_ID
				.equals(org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
						.getModelID(view));
	}

}
