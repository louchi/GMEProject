package org.eclipse.myTest.LDM.diagram.navigator;

import org.eclipse.jface.viewers.ViewerSorter;

/**
 * @generated
 */
public class MyLDMNavigatorSorter extends ViewerSorter {

	/**
	 * @generated
	 */
	private static final int GROUP_CATEGORY = 4006;

	/**
	 * @generated
	 */
	public int category(Object element) {
		if (element instanceof org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem) {
			org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem item = (org.eclipse.myTest.LDM.diagram.navigator.MyLDMNavigatorItem) element;
			return org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
