package org.eclipse.myTest.LDM.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	 * @generated
	 */
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Messages() {
	}

	/**
	 * @generated
	 */
	public static String MyLDMCreationWizardTitle;

	/**
	 * @generated
	 */
	public static String MyLDMCreationWizard_DiagramModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String MyLDMCreationWizard_DiagramModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String MyLDMCreationWizard_DomainModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String MyLDMCreationWizard_DomainModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String MyLDMCreationWizardOpenEditorError;

	/**
	 * @generated
	 */
	public static String MyLDMCreationWizardCreationError;

	/**
	 * @generated
	 */
	public static String MyLDMCreationWizardPageExtensionError;

	/**
	 * @generated
	 */
	public static String MyLDMDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String MyLDMDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String MyLDMDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	 * @generated
	 */
	public static String MyLDMDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	 * @generated
	 */
	public static String MyLDMDocumentProvider_isModifiable;

	/**
	 * @generated
	 */
	public static String MyLDMDocumentProvider_handleElementContentChanged;

	/**
	 * @generated
	 */
	public static String MyLDMDocumentProvider_IncorrectInputError;

	/**
	 * @generated
	 */
	public static String MyLDMDocumentProvider_NoDiagramInResourceError;

	/**
	 * @generated
	 */
	public static String MyLDMDocumentProvider_DiagramLoadingError;

	/**
	 * @generated
	 */
	public static String MyLDMDocumentProvider_UnsynchronizedFileSaveError;

	/**
	 * @generated
	 */
	public static String MyLDMDocumentProvider_SaveDiagramTask;

	/**
	 * @generated
	 */
	public static String MyLDMDocumentProvider_SaveNextResourceTask;

	/**
	 * @generated
	 */
	public static String MyLDMDocumentProvider_SaveAsOperation;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_WizardTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_CreationPageName;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_CreationPageTitle;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_CreationPageDescription;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_RootSelectionPageName;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_InitDiagramCommand;

	/**
	 * @generated
	 */
	public static String MyLDMNewDiagramFileWizard_IncorrectRootError;

	/**
	 * @generated
	 */
	public static String MyLDMDiagramEditor_SavingDeletedFile;

	/**
	 * @generated
	 */
	public static String MyLDMDiagramEditor_SaveAsErrorTitle;

	/**
	 * @generated
	 */
	public static String MyLDMDiagramEditor_SaveAsErrorMessage;

	/**
	 * @generated
	 */
	public static String MyLDMDiagramEditor_SaveErrorTitle;

	/**
	 * @generated
	 */
	public static String MyLDMDiagramEditor_SaveErrorMessage;

	/**
	 * @generated
	 */
	public static String MyLDMElementChooserDialog_SelectModelElementTitle;

	/**
	 * @generated
	 */
	public static String ModelElementSelectionPageMessage;

	/**
	 * @generated
	 */
	public static String ValidateActionMessage;

	/**
	 * @generated
	 */
	public static String LDM1Group_title;

	/**
	 * @generated
	 */
	public static String Connections2Group_title;

	/**
	 * @generated
	 */
	public static String LogicalAssociation1CreationTool_title;

	/**
	 * @generated
	 */
	public static String LogicalAssociation1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String LogicalEntity2CreationTool_title;

	/**
	 * @generated
	 */
	public static String LogicalEntity2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String LDM23CreationTool_title;

	/**
	 * @generated
	 */
	public static String LDM23CreationTool_desc;

	/**
	 * @generated
	 */
	public static String LogicalView4CreationTool_title;

	/**
	 * @generated
	 */
	public static String LogicalView4CreationTool_desc;

	/**
	 * @generated
	 */
	public static String SolidLine1CreationTool_title;

	/**
	 * @generated
	 */
	public static String SolidLine1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String DashedLine2CreationTool_title;

	/**
	 * @generated
	 */
	public static String DashedLine2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String ArrowDashedLine3CreationTool_title;

	/**
	 * @generated
	 */
	public static String ArrowDashedLine3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String ArrowSolidLine4CreationTool_title;

	/**
	 * @generated
	 */
	public static String ArrowSolidLine4CreationTool_desc;

	/**
	 * @generated
	 */
	public static String CommandName_OpenDiagram;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_BasePanel_1000_links;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_DashedLine_4004_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_DashedLine_4004_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_ArrowDashedLine_4003_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_ArrowDashedLine_4003_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_ArrowSolidLine_4001_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_ArrowSolidLine_4001_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_SolidLine_4002_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_SolidLine_4002_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_LogicalEntity_2004_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_LogicalEntity_2004_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_LogicalAssociation_2003_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_LogicalAssociation_2003_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_LDM_2002_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_LDM_2002_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_LogicalView_2001_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_LogicalView_2001_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnexpectedValueType;

	/**
	 * @generated
	 */
	public static String AbstractParser_WrongStringConversion;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnknownLiteral;

	/**
	 * @generated
	 */
	public static String MessageFormatParser_InvalidInputError;

	/**
	 * @generated
	 */
	public static String MyLDMModelingAssistantProviderTitle;

	/**
	 * @generated
	 */
	public static String MyLDMModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
