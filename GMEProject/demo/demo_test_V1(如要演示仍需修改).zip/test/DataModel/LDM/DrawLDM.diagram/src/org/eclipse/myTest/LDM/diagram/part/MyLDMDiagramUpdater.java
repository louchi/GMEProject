package org.eclipse.myTest.LDM.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

/**
 * @generated
 */
public class MyLDMDiagramUpdater {

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMNodeDescriptor> getSemanticChildren(
			View view) {
		switch (org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.LDM.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
			return getBasePanel_1000SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMNodeDescriptor> getBasePanel_1000SemanticChildren(
			View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		org.eclipse.myTest.LDM.BasePanel modelElement = (org.eclipse.myTest.LDM.BasePanel) view
				.getElement();
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMNodeDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMNodeDescriptor>();
		for (Iterator<?> it = modelElement.getHaveShapes().iterator(); it
				.hasNext();) {
			org.eclipse.myTest.LDM.AbstractShapes childElement = (org.eclipse.myTest.LDM.AbstractShapes) it
					.next();
			int visualID = org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMNodeDescriptor(
						childElement, visualID));
				continue;
			}
			if (visualID == org.eclipse.myTest.LDM.diagram.edit.parts.LDMEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMNodeDescriptor(
						childElement, visualID));
				continue;
			}
			if (visualID == org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMNodeDescriptor(
						childElement, visualID));
				continue;
			}
			if (visualID == org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getContainedLinks(
			View view) {
		switch (org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.LDM.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
			return getBasePanel_1000ContainedLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewEditPart.VISUAL_ID:
			return getLogicalView_2001ContainedLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LDMEditPart.VISUAL_ID:
			return getLDM_2002ContainedLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationEditPart.VISUAL_ID:
			return getLogicalAssociation_2003ContainedLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityEditPart.VISUAL_ID:
			return getLogicalEntity_2004ContainedLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
			return getArrowSolidLine_4001ContainedLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
			return getSolidLine_4002ContainedLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
			return getArrowDashedLine_4003ContainedLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
			return getDashedLine_4004ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getIncomingLinks(
			View view) {
		switch (org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewEditPart.VISUAL_ID:
			return getLogicalView_2001IncomingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LDMEditPart.VISUAL_ID:
			return getLDM_2002IncomingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationEditPart.VISUAL_ID:
			return getLogicalAssociation_2003IncomingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityEditPart.VISUAL_ID:
			return getLogicalEntity_2004IncomingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
			return getArrowSolidLine_4001IncomingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
			return getSolidLine_4002IncomingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
			return getArrowDashedLine_4003IncomingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
			return getDashedLine_4004IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getOutgoingLinks(
			View view) {
		switch (org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewEditPart.VISUAL_ID:
			return getLogicalView_2001OutgoingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LDMEditPart.VISUAL_ID:
			return getLDM_2002OutgoingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationEditPart.VISUAL_ID:
			return getLogicalAssociation_2003OutgoingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityEditPart.VISUAL_ID:
			return getLogicalEntity_2004OutgoingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
			return getArrowSolidLine_4001OutgoingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
			return getSolidLine_4002OutgoingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
			return getArrowDashedLine_4003OutgoingLinks(view);
		case org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
			return getDashedLine_4004OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getBasePanel_1000ContainedLinks(
			View view) {
		org.eclipse.myTest.LDM.BasePanel modelElement = (org.eclipse.myTest.LDM.BasePanel) view
				.getElement();
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		result.addAll(getContainedTypeModelFacetLinks_ArrowSolidLine_4001(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_SolidLine_4002(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_ArrowDashedLine_4003(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_DashedLine_4004(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLogicalView_2001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLDM_2002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLogicalAssociation_2003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLogicalEntity_2004ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getArrowSolidLine_4001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getSolidLine_4002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getArrowDashedLine_4003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getDashedLine_4004ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLogicalView_2001IncomingLinks(
			View view) {
		org.eclipse.myTest.LDM.LogicalView modelElement = (org.eclipse.myTest.LDM.LogicalView) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_ArrowSolidLine_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_SolidLine_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_ArrowDashedLine_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DashedLine_4004(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLDM_2002IncomingLinks(
			View view) {
		org.eclipse.myTest.LDM.LDM modelElement = (org.eclipse.myTest.LDM.LDM) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_ArrowSolidLine_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_SolidLine_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_ArrowDashedLine_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DashedLine_4004(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLogicalAssociation_2003IncomingLinks(
			View view) {
		org.eclipse.myTest.LDM.LogicalAssociation modelElement = (org.eclipse.myTest.LDM.LogicalAssociation) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_ArrowSolidLine_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_SolidLine_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_ArrowDashedLine_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DashedLine_4004(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLogicalEntity_2004IncomingLinks(
			View view) {
		org.eclipse.myTest.LDM.LogicalEntity modelElement = (org.eclipse.myTest.LDM.LogicalEntity) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_ArrowSolidLine_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_SolidLine_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_ArrowDashedLine_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DashedLine_4004(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getArrowSolidLine_4001IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getSolidLine_4002IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getArrowDashedLine_4003IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getDashedLine_4004IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLogicalView_2001OutgoingLinks(
			View view) {
		org.eclipse.myTest.LDM.LogicalView modelElement = (org.eclipse.myTest.LDM.LogicalView) view
				.getElement();
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_ArrowSolidLine_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_SolidLine_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_ArrowDashedLine_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DashedLine_4004(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLDM_2002OutgoingLinks(
			View view) {
		org.eclipse.myTest.LDM.LDM modelElement = (org.eclipse.myTest.LDM.LDM) view
				.getElement();
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_ArrowSolidLine_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_SolidLine_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_ArrowDashedLine_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DashedLine_4004(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLogicalAssociation_2003OutgoingLinks(
			View view) {
		org.eclipse.myTest.LDM.LogicalAssociation modelElement = (org.eclipse.myTest.LDM.LogicalAssociation) view
				.getElement();
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_ArrowSolidLine_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_SolidLine_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_ArrowDashedLine_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DashedLine_4004(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getLogicalEntity_2004OutgoingLinks(
			View view) {
		org.eclipse.myTest.LDM.LogicalEntity modelElement = (org.eclipse.myTest.LDM.LogicalEntity) view
				.getElement();
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_ArrowSolidLine_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_SolidLine_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_ArrowDashedLine_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DashedLine_4004(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getArrowSolidLine_4001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getSolidLine_4002OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getArrowDashedLine_4003OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getDashedLine_4004OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getContainedTypeModelFacetLinks_ArrowSolidLine_4001(
			org.eclipse.myTest.LDM.BasePanel container) {
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		for (Iterator<?> links = container.getHaveLines().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.LDM.ArrowSolidLine) {
				continue;
			}
			org.eclipse.myTest.LDM.ArrowSolidLine link = (org.eclipse.myTest.LDM.ArrowSolidLine) linkObject;
			if (org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes dst = link.getTo();
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowSolidLine_4001,
					org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getContainedTypeModelFacetLinks_SolidLine_4002(
			org.eclipse.myTest.LDM.BasePanel container) {
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		for (Iterator<?> links = container.getHaveLines().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.LDM.SolidLine) {
				continue;
			}
			org.eclipse.myTest.LDM.SolidLine link = (org.eclipse.myTest.LDM.SolidLine) linkObject;
			if (org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes dst = link.getTo();
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.SolidLine_4002,
					org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getContainedTypeModelFacetLinks_ArrowDashedLine_4003(
			org.eclipse.myTest.LDM.BasePanel container) {
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		for (Iterator<?> links = container.getHaveLines().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.LDM.ArrowDashedLine) {
				continue;
			}
			org.eclipse.myTest.LDM.ArrowDashedLine link = (org.eclipse.myTest.LDM.ArrowDashedLine) linkObject;
			if (org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes dst = link.getTo();
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowDashedLine_4003,
					org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getContainedTypeModelFacetLinks_DashedLine_4004(
			org.eclipse.myTest.LDM.BasePanel container) {
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		for (Iterator<?> links = container.getHaveLines().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.LDM.DashedLine) {
				continue;
			}
			org.eclipse.myTest.LDM.DashedLine link = (org.eclipse.myTest.LDM.DashedLine) linkObject;
			if (org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes dst = link.getTo();
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.DashedLine_4004,
					org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getIncomingTypeModelFacetLinks_ArrowSolidLine_4001(
			org.eclipse.myTest.LDM.AbstractShapes target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != org.eclipse.myTest.LDM.LDMPackage.eINSTANCE
					.getAbstractLine_To()
					|| false == setting.getEObject() instanceof org.eclipse.myTest.LDM.ArrowSolidLine) {
				continue;
			}
			org.eclipse.myTest.LDM.ArrowSolidLine link = (org.eclipse.myTest.LDM.ArrowSolidLine) setting
					.getEObject();
			if (org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					target,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowSolidLine_4001,
					org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getIncomingTypeModelFacetLinks_SolidLine_4002(
			org.eclipse.myTest.LDM.AbstractShapes target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != org.eclipse.myTest.LDM.LDMPackage.eINSTANCE
					.getAbstractLine_To()
					|| false == setting.getEObject() instanceof org.eclipse.myTest.LDM.SolidLine) {
				continue;
			}
			org.eclipse.myTest.LDM.SolidLine link = (org.eclipse.myTest.LDM.SolidLine) setting
					.getEObject();
			if (org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					target,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.SolidLine_4002,
					org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getIncomingTypeModelFacetLinks_ArrowDashedLine_4003(
			org.eclipse.myTest.LDM.AbstractShapes target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != org.eclipse.myTest.LDM.LDMPackage.eINSTANCE
					.getAbstractLine_To()
					|| false == setting.getEObject() instanceof org.eclipse.myTest.LDM.ArrowDashedLine) {
				continue;
			}
			org.eclipse.myTest.LDM.ArrowDashedLine link = (org.eclipse.myTest.LDM.ArrowDashedLine) setting
					.getEObject();
			if (org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					target,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowDashedLine_4003,
					org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getIncomingTypeModelFacetLinks_DashedLine_4004(
			org.eclipse.myTest.LDM.AbstractShapes target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != org.eclipse.myTest.LDM.LDMPackage.eINSTANCE
					.getAbstractLine_To()
					|| false == setting.getEObject() instanceof org.eclipse.myTest.LDM.DashedLine) {
				continue;
			}
			org.eclipse.myTest.LDM.DashedLine link = (org.eclipse.myTest.LDM.DashedLine) setting
					.getEObject();
			if (org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					target,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.DashedLine_4004,
					org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getOutgoingTypeModelFacetLinks_ArrowSolidLine_4001(
			org.eclipse.myTest.LDM.AbstractShapes source) {
		org.eclipse.myTest.LDM.BasePanel container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof org.eclipse.myTest.LDM.BasePanel) {
				container = (org.eclipse.myTest.LDM.BasePanel) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		for (Iterator<?> links = container.getHaveLines().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.LDM.ArrowSolidLine) {
				continue;
			}
			org.eclipse.myTest.LDM.ArrowSolidLine link = (org.eclipse.myTest.LDM.ArrowSolidLine) linkObject;
			if (org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes dst = link.getTo();
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			if (src != source) {
				continue;
			}
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowSolidLine_4001,
					org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getOutgoingTypeModelFacetLinks_SolidLine_4002(
			org.eclipse.myTest.LDM.AbstractShapes source) {
		org.eclipse.myTest.LDM.BasePanel container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof org.eclipse.myTest.LDM.BasePanel) {
				container = (org.eclipse.myTest.LDM.BasePanel) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		for (Iterator<?> links = container.getHaveLines().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.LDM.SolidLine) {
				continue;
			}
			org.eclipse.myTest.LDM.SolidLine link = (org.eclipse.myTest.LDM.SolidLine) linkObject;
			if (org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes dst = link.getTo();
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			if (src != source) {
				continue;
			}
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.SolidLine_4002,
					org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getOutgoingTypeModelFacetLinks_ArrowDashedLine_4003(
			org.eclipse.myTest.LDM.AbstractShapes source) {
		org.eclipse.myTest.LDM.BasePanel container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof org.eclipse.myTest.LDM.BasePanel) {
				container = (org.eclipse.myTest.LDM.BasePanel) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		for (Iterator<?> links = container.getHaveLines().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.LDM.ArrowDashedLine) {
				continue;
			}
			org.eclipse.myTest.LDM.ArrowDashedLine link = (org.eclipse.myTest.LDM.ArrowDashedLine) linkObject;
			if (org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes dst = link.getTo();
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			if (src != source) {
				continue;
			}
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowDashedLine_4003,
					org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getOutgoingTypeModelFacetLinks_DashedLine_4004(
			org.eclipse.myTest.LDM.AbstractShapes source) {
		org.eclipse.myTest.LDM.BasePanel container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof org.eclipse.myTest.LDM.BasePanel) {
				container = (org.eclipse.myTest.LDM.BasePanel) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> result = new LinkedList<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor>();
		for (Iterator<?> links = container.getHaveLines().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.LDM.DashedLine) {
				continue;
			}
			org.eclipse.myTest.LDM.DashedLine link = (org.eclipse.myTest.LDM.DashedLine) linkObject;
			if (org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID != org.eclipse.myTest.LDM.diagram.part.MyLDMVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.LDM.AbstractShapes dst = link.getTo();
			org.eclipse.myTest.LDM.AbstractShapes src = link.getFrom();
			if (src != source) {
				continue;
			}
			result.add(new org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.DashedLine_4004,
					org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		 * @generated
		 */

		public List<org.eclipse.myTest.LDM.diagram.part.MyLDMNodeDescriptor> getSemanticChildren(
				View view) {
			return MyLDMDiagramUpdater.getSemanticChildren(view);
		}

		/**
		 * @generated
		 */

		public List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getContainedLinks(
				View view) {
			return MyLDMDiagramUpdater.getContainedLinks(view);
		}

		/**
		 * @generated
		 */

		public List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getIncomingLinks(
				View view) {
			return MyLDMDiagramUpdater.getIncomingLinks(view);
		}

		/**
		 * @generated
		 */

		public List<org.eclipse.myTest.LDM.diagram.part.MyLDMLinkDescriptor> getOutgoingLinks(
				View view) {
			return MyLDMDiagramUpdater.getOutgoingLinks(view);
		}
	};

}
