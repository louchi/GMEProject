package org.eclipse.myTest.LDM.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class MyLDMNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	 * @generated
	 */
	public MyLDMNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
