package org.eclipse.myTest.LDM.diagram.part;

import java.util.Collections;
import java.util.List;

import org.eclipse.gef.Tool;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeConnectionTool;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeCreationTool;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MyLDMPaletteFactory {

	/**
	 * @generated
	 */
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createLDM1Group());
		paletteRoot.add(createConnections2Group());
	}

	/**
	 * Creates "LDM" palette tool group
	 * @generated
	 */
	private PaletteContainer createLDM1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				org.eclipse.myTest.LDM.diagram.part.Messages.LDM1Group_title);
		paletteContainer.setId("createLDM1Group"); //$NON-NLS-1$
		paletteContainer.add(createLogicalAssociation1CreationTool());
		paletteContainer.add(createLogicalEntity2CreationTool());
		paletteContainer.add(createLDM23CreationTool());
		paletteContainer.add(createLogicalView4CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Connections" palette tool group
	 * @generated
	 */
	private PaletteContainer createConnections2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				org.eclipse.myTest.LDM.diagram.part.Messages.Connections2Group_title);
		paletteContainer.setId("createConnections2Group"); //$NON-NLS-1$
		paletteContainer.add(createSolidLine1CreationTool());
		paletteContainer.add(createDashedLine2CreationTool());
		paletteContainer.add(createArrowDashedLine3CreationTool());
		paletteContainer.add(createArrowSolidLine4CreationTool());
		return paletteContainer;
	}

	/**
	 * @generated
	 */
	private ToolEntry createLogicalAssociation1CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				org.eclipse.myTest.LDM.diagram.part.Messages.LogicalAssociation1CreationTool_title,
				org.eclipse.myTest.LDM.diagram.part.Messages.LogicalAssociation1CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalAssociation_2003));
		entry.setId("createLogicalAssociation1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalAssociation_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createLogicalEntity2CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				org.eclipse.myTest.LDM.diagram.part.Messages.LogicalEntity2CreationTool_title,
				org.eclipse.myTest.LDM.diagram.part.Messages.LogicalEntity2CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalEntity_2004));
		entry.setId("createLogicalEntity2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalEntity_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createLDM23CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				org.eclipse.myTest.LDM.diagram.part.Messages.LDM23CreationTool_title,
				org.eclipse.myTest.LDM.diagram.part.Messages.LDM23CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LDM_2002));
		entry.setId("createLDM23CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LDM_2002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createLogicalView4CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				org.eclipse.myTest.LDM.diagram.part.Messages.LogicalView4CreationTool_title,
				org.eclipse.myTest.LDM.diagram.part.Messages.LogicalView4CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalView_2001));
		entry.setId("createLogicalView4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.LogicalView_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSolidLine1CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				org.eclipse.myTest.LDM.diagram.part.Messages.SolidLine1CreationTool_title,
				org.eclipse.myTest.LDM.diagram.part.Messages.SolidLine1CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.SolidLine_4002));
		entry.setId("createSolidLine1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.SolidLine_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createDashedLine2CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				org.eclipse.myTest.LDM.diagram.part.Messages.DashedLine2CreationTool_title,
				org.eclipse.myTest.LDM.diagram.part.Messages.DashedLine2CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.DashedLine_4004));
		entry.setId("createDashedLine2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.DashedLine_4004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createArrowDashedLine3CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				org.eclipse.myTest.LDM.diagram.part.Messages.ArrowDashedLine3CreationTool_title,
				org.eclipse.myTest.LDM.diagram.part.Messages.ArrowDashedLine3CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowDashedLine_4003));
		entry.setId("createArrowDashedLine3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowDashedLine_4003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createArrowSolidLine4CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				org.eclipse.myTest.LDM.diagram.part.Messages.ArrowSolidLine4CreationTool_title,
				org.eclipse.myTest.LDM.diagram.part.Messages.ArrowSolidLine4CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowSolidLine_4001));
		entry.setId("createArrowSolidLine4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.LDM.diagram.providers.MyLDMElementTypes.ArrowSolidLine_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private static class NodeToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List<IElementType> elementTypes;

		/**
		 * @generated
		 */
		private NodeToolEntry(String title, String description,
				List<IElementType> elementTypes) {
			super(title, description, null, null);
			this.elementTypes = elementTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeCreationTool(elementTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}

	/**
	 * @generated
	 */
	private static class LinkToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List<IElementType> relationshipTypes;

		/**
		 * @generated
		 */
		private LinkToolEntry(String title, String description,
				List<IElementType> relationshipTypes) {
			super(title, description, null, null);
			this.relationshipTypes = relationshipTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeConnectionTool(relationshipTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}
}
