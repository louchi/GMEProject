package org.eclipse.myTest.LDM.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
