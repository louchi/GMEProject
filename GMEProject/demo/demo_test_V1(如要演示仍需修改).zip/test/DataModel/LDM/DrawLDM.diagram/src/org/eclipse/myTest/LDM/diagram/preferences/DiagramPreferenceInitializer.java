package org.eclipse.myTest.LDM.diagram.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * @generated
 */
public class DiagramPreferenceInitializer extends AbstractPreferenceInitializer {

	/**
	 * @generated
	 */
	public void initializeDefaultPreferences() {
		IPreferenceStore store = getPreferenceStore();
		org.eclipse.myTest.LDM.diagram.preferences.DiagramGeneralPreferencePage
				.initDefaults(store);
		org.eclipse.myTest.LDM.diagram.preferences.DiagramAppearancePreferencePage
				.initDefaults(store);
		org.eclipse.myTest.LDM.diagram.preferences.DiagramConnectionsPreferencePage
				.initDefaults(store);
		org.eclipse.myTest.LDM.diagram.preferences.DiagramPrintingPreferencePage
				.initDefaults(store);
		org.eclipse.myTest.LDM.diagram.preferences.DiagramRulersAndGridPreferencePage
				.initDefaults(store);

	}

	/**
	 * @generated
	 */
	protected IPreferenceStore getPreferenceStore() {
		return org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
				.getInstance().getPreferenceStore();
	}
}
