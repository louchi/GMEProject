package org.eclipse.myTest.LDM.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.PrintingPreferencePage;

/**
 * @generated
 */
public class DiagramPrintingPreferencePage extends PrintingPreferencePage {

	/**
	 * @generated
	 */
	public DiagramPrintingPreferencePage() {
		setPreferenceStore(org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
