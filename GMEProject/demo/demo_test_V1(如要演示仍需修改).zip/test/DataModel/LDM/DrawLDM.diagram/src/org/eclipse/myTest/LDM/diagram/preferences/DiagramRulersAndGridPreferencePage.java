package org.eclipse.myTest.LDM.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
