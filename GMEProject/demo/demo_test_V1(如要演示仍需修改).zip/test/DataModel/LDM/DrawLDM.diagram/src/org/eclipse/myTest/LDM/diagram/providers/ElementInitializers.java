package org.eclipse.myTest.LDM.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	 * @generated
	 */
	public static ElementInitializers getInstance() {
		ElementInitializers cached = org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
				.getInstance().getElementInitializers();
		if (cached == null) {
			org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
					.getInstance().setElementInitializers(
							cached = new ElementInitializers());
		}
		return cached;
	}
}
