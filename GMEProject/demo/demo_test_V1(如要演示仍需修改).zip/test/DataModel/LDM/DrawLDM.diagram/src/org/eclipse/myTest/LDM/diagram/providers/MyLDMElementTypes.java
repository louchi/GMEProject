package org.eclipse.myTest.LDM.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;

/**
 * @generated
 */
public class MyLDMElementTypes {

	/**
	 * @generated
	 */
	private MyLDMElementTypes() {
	}

	/**
	 * @generated
	 */
	private static Map<IElementType, ENamedElement> elements;

	/**
	 * @generated
	 */
	private static ImageRegistry imageRegistry;

	/**
	 * @generated
	 */
	private static Set<IElementType> KNOWN_ELEMENT_TYPES;

	/**
	 * @generated
	 */
	public static final IElementType BasePanel_1000 = getElementType("DrawLDM.diagram.BasePanel_1000"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType LogicalView_2001 = getElementType("DrawLDM.diagram.LogicalView_2001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType LDM_2002 = getElementType("DrawLDM.diagram.LDM_2002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType LogicalAssociation_2003 = getElementType("DrawLDM.diagram.LogicalAssociation_2003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType LogicalEntity_2004 = getElementType("DrawLDM.diagram.LogicalEntity_2004"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType ArrowSolidLine_4001 = getElementType("DrawLDM.diagram.ArrowSolidLine_4001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType SolidLine_4002 = getElementType("DrawLDM.diagram.SolidLine_4002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType ArrowDashedLine_4003 = getElementType("DrawLDM.diagram.ArrowDashedLine_4003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType DashedLine_4004 = getElementType("DrawLDM.diagram.DashedLine_4004"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	private static ImageRegistry getImageRegistry() {
		if (imageRegistry == null) {
			imageRegistry = new ImageRegistry();
		}
		return imageRegistry;
	}

	/**
	 * @generated
	 */
	private static String getImageRegistryKey(ENamedElement element) {
		return element.getName();
	}

	/**
	 * @generated
	 */
	private static ImageDescriptor getProvidedImageDescriptor(
			ENamedElement element) {
		if (element instanceof EStructuralFeature) {
			EStructuralFeature feature = ((EStructuralFeature) element);
			EClass eContainingClass = feature.getEContainingClass();
			EClassifier eType = feature.getEType();
			if (eContainingClass != null && !eContainingClass.isAbstract()) {
				element = eContainingClass;
			} else if (eType instanceof EClass
					&& !((EClass) eType).isAbstract()) {
				element = eType;
			}
		}
		if (element instanceof EClass) {
			EClass eClass = (EClass) element;
			if (!eClass.isAbstract()) {
				return org.eclipse.myTest.LDM.diagram.part.MyLDMDiagramEditorPlugin
						.getInstance().getItemImageDescriptor(
								eClass.getEPackage().getEFactoryInstance()
										.create(eClass));
			}
		}
		// TODO : support structural features
		return null;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		String key = getImageRegistryKey(element);
		ImageDescriptor imageDescriptor = getImageRegistry().getDescriptor(key);
		if (imageDescriptor == null) {
			imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
		}
		return imageDescriptor;
	}

	/**
	 * @generated
	 */
	public static Image getImage(ENamedElement element) {
		String key = getImageRegistryKey(element);
		Image image = getImageRegistry().get(key);
		if (image == null) {
			ImageDescriptor imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
			image = getImageRegistry().get(key);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImageDescriptor(element);
	}

	/**
	 * @generated
	 */
	public static Image getImage(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImage(element);
	}

	/**
	 * Returns 'type' of the ecore object associated with the hint.
	 * 
	 * @generated
	 */
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap<IElementType, ENamedElement>();

			elements.put(BasePanel_1000,
					org.eclipse.myTest.LDM.LDMPackage.eINSTANCE.getBasePanel());

			elements.put(LogicalView_2001,
					org.eclipse.myTest.LDM.LDMPackage.eINSTANCE
							.getLogicalView());

			elements.put(LDM_2002,
					org.eclipse.myTest.LDM.LDMPackage.eINSTANCE.getLDM());

			elements.put(LogicalAssociation_2003,
					org.eclipse.myTest.LDM.LDMPackage.eINSTANCE
							.getLogicalAssociation());

			elements.put(LogicalEntity_2004,
					org.eclipse.myTest.LDM.LDMPackage.eINSTANCE
							.getLogicalEntity());

			elements.put(ArrowSolidLine_4001,
					org.eclipse.myTest.LDM.LDMPackage.eINSTANCE
							.getArrowSolidLine());

			elements.put(SolidLine_4002,
					org.eclipse.myTest.LDM.LDMPackage.eINSTANCE.getSolidLine());

			elements.put(ArrowDashedLine_4003,
					org.eclipse.myTest.LDM.LDMPackage.eINSTANCE
							.getArrowDashedLine());

			elements.put(DashedLine_4004,
					org.eclipse.myTest.LDM.LDMPackage.eINSTANCE.getDashedLine());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	 * @generated
	 */
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	 * @generated
	 */
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet<IElementType>();
			KNOWN_ELEMENT_TYPES.add(BasePanel_1000);
			KNOWN_ELEMENT_TYPES.add(LogicalView_2001);
			KNOWN_ELEMENT_TYPES.add(LDM_2002);
			KNOWN_ELEMENT_TYPES.add(LogicalAssociation_2003);
			KNOWN_ELEMENT_TYPES.add(LogicalEntity_2004);
			KNOWN_ELEMENT_TYPES.add(ArrowSolidLine_4001);
			KNOWN_ELEMENT_TYPES.add(SolidLine_4002);
			KNOWN_ELEMENT_TYPES.add(ArrowDashedLine_4003);
			KNOWN_ELEMENT_TYPES.add(DashedLine_4004);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	 * @generated
	 */
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case org.eclipse.myTest.LDM.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
			return BasePanel_1000;
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalViewEditPart.VISUAL_ID:
			return LogicalView_2001;
		case org.eclipse.myTest.LDM.diagram.edit.parts.LDMEditPart.VISUAL_ID:
			return LDM_2002;
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalAssociationEditPart.VISUAL_ID:
			return LogicalAssociation_2003;
		case org.eclipse.myTest.LDM.diagram.edit.parts.LogicalEntityEditPart.VISUAL_ID:
			return LogicalEntity_2004;
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
			return ArrowSolidLine_4001;
		case org.eclipse.myTest.LDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
			return SolidLine_4002;
		case org.eclipse.myTest.LDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
			return ArrowDashedLine_4003;
		case org.eclipse.myTest.LDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
			return DashedLine_4004;
		}
		return null;
	}

}
