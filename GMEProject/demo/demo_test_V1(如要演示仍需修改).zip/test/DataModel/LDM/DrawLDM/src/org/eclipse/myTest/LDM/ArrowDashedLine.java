/**
 */
package org.eclipse.myTest.LDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arrow Dashed Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.LDM.LDMPackage#getArrowDashedLine()
 * @model
 * @generated
 */
public interface ArrowDashedLine extends AbstractLine {
} // ArrowDashedLine
