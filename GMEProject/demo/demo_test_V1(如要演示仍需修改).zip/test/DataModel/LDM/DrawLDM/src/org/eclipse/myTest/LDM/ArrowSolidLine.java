/**
 */
package org.eclipse.myTest.LDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arrow Solid Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.LDM.LDMPackage#getArrowSolidLine()
 * @model
 * @generated
 */
public interface ArrowSolidLine extends AbstractLine {
} // ArrowSolidLine
