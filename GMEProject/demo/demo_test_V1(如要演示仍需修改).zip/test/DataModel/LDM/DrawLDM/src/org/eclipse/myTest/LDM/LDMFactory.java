/**
 */
package org.eclipse.myTest.LDM;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.myTest.LDM.LDMPackage
 * @generated
 */
public interface LDMFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	LDMFactory eINSTANCE = org.eclipse.myTest.LDM.impl.LDMFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Base Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Base Panel</em>'.
	 * @generated
	 */
	BasePanel createBasePanel();

	/**
	 * Returns a new object of class '<em>Abstract Shapes</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Abstract Shapes</em>'.
	 * @generated
	 */
	AbstractShapes createAbstractShapes();

	/**
	 * Returns a new object of class '<em>Abstract Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Abstract Line</em>'.
	 * @generated
	 */
	AbstractLine createAbstractLine();

	/**
	 * Returns a new object of class '<em>Logical Association</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Logical Association</em>'.
	 * @generated
	 */
	LogicalAssociation createLogicalAssociation();

	/**
	 * Returns a new object of class '<em>Logical Entity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Logical Entity</em>'.
	 * @generated
	 */
	LogicalEntity createLogicalEntity();

	/**
	 * Returns a new object of class '<em>LDM</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>LDM</em>'.
	 * @generated
	 */
	LDM createLDM();

	/**
	 * Returns a new object of class '<em>Logical View</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Logical View</em>'.
	 * @generated
	 */
	LogicalView createLogicalView();

	/**
	 * Returns a new object of class '<em>Solid Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Solid Line</em>'.
	 * @generated
	 */
	SolidLine createSolidLine();

	/**
	 * Returns a new object of class '<em>Dashed Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dashed Line</em>'.
	 * @generated
	 */
	DashedLine createDashedLine();

	/**
	 * Returns a new object of class '<em>Arrow Dashed Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Arrow Dashed Line</em>'.
	 * @generated
	 */
	ArrowDashedLine createArrowDashedLine();

	/**
	 * Returns a new object of class '<em>Arrow Solid Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Arrow Solid Line</em>'.
	 * @generated
	 */
	ArrowSolidLine createArrowSolidLine();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	LDMPackage getLDMPackage();

} //LDMFactory
