/**
 */
package org.eclipse.myTest.LDM;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.myTest.LDM.LDMFactory
 * @model kind="package"
 * @generated
 */
public interface LDMPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "LDM";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "LDM.myTest.eclipse.org";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "org.eclipse.myTest";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	LDMPackage eINSTANCE = org.eclipse.myTest.LDM.impl.LDMPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.BasePanelImpl <em>Base Panel</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.BasePanelImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getBasePanel()
	 * @generated
	 */
	int BASE_PANEL = 0;

	/**
	 * The feature id for the '<em><b>Have Shapes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL__HAVE_SHAPES = 0;

	/**
	 * The feature id for the '<em><b>Have Lines</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL__HAVE_LINES = 1;

	/**
	 * The number of structural features of the '<em>Base Panel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Base Panel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.AbstractShapesImpl <em>Abstract Shapes</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.AbstractShapesImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getAbstractShapes()
	 * @generated
	 */
	int ABSTRACT_SHAPES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES__NAME = 0;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES__SOURCES = 1;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES__TARGETS = 2;

	/**
	 * The number of structural features of the '<em>Abstract Shapes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Abstract Shapes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.AbstractLineImpl <em>Abstract Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.AbstractLineImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getAbstractLine()
	 * @generated
	 */
	int ABSTRACT_LINE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE__NAME = 0;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE__FROM = 1;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE__TO = 2;

	/**
	 * The number of structural features of the '<em>Abstract Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Abstract Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.LogicalAssociationImpl <em>Logical Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.LogicalAssociationImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getLogicalAssociation()
	 * @generated
	 */
	int LOGICAL_ASSOCIATION = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ASSOCIATION__NAME = ABSTRACT_SHAPES__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ASSOCIATION__SOURCES = ABSTRACT_SHAPES__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ASSOCIATION__TARGETS = ABSTRACT_SHAPES__TARGETS;

	/**
	 * The number of structural features of the '<em>Logical Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ASSOCIATION_FEATURE_COUNT = ABSTRACT_SHAPES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Logical Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ASSOCIATION_OPERATION_COUNT = ABSTRACT_SHAPES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.LogicalEntityImpl <em>Logical Entity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.LogicalEntityImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getLogicalEntity()
	 * @generated
	 */
	int LOGICAL_ENTITY = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ENTITY__NAME = ABSTRACT_SHAPES__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ENTITY__SOURCES = ABSTRACT_SHAPES__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ENTITY__TARGETS = ABSTRACT_SHAPES__TARGETS;

	/**
	 * The number of structural features of the '<em>Logical Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ENTITY_FEATURE_COUNT = ABSTRACT_SHAPES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Logical Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_ENTITY_OPERATION_COUNT = ABSTRACT_SHAPES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.LDMImpl <em>LDM</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.LDMImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getLDM()
	 * @generated
	 */
	int LDM = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LDM__NAME = ABSTRACT_SHAPES__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LDM__SOURCES = ABSTRACT_SHAPES__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LDM__TARGETS = ABSTRACT_SHAPES__TARGETS;

	/**
	 * The number of structural features of the '<em>LDM</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LDM_FEATURE_COUNT = ABSTRACT_SHAPES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>LDM</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LDM_OPERATION_COUNT = ABSTRACT_SHAPES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.LogicalViewImpl <em>Logical View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.LogicalViewImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getLogicalView()
	 * @generated
	 */
	int LOGICAL_VIEW = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_VIEW__NAME = ABSTRACT_SHAPES__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_VIEW__SOURCES = ABSTRACT_SHAPES__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_VIEW__TARGETS = ABSTRACT_SHAPES__TARGETS;

	/**
	 * The number of structural features of the '<em>Logical View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_VIEW_FEATURE_COUNT = ABSTRACT_SHAPES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Logical View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOGICAL_VIEW_OPERATION_COUNT = ABSTRACT_SHAPES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.SolidLineImpl <em>Solid Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.SolidLineImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getSolidLine()
	 * @generated
	 */
	int SOLID_LINE = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE__NAME = ABSTRACT_LINE__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE__FROM = ABSTRACT_LINE__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE__TO = ABSTRACT_LINE__TO;

	/**
	 * The number of structural features of the '<em>Solid Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE_FEATURE_COUNT = ABSTRACT_LINE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Solid Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE_OPERATION_COUNT = ABSTRACT_LINE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.DashedLineImpl <em>Dashed Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.DashedLineImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getDashedLine()
	 * @generated
	 */
	int DASHED_LINE = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE__NAME = ABSTRACT_LINE__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE__FROM = ABSTRACT_LINE__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE__TO = ABSTRACT_LINE__TO;

	/**
	 * The number of structural features of the '<em>Dashed Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE_FEATURE_COUNT = ABSTRACT_LINE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Dashed Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE_OPERATION_COUNT = ABSTRACT_LINE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.ArrowDashedLineImpl <em>Arrow Dashed Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.ArrowDashedLineImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getArrowDashedLine()
	 * @generated
	 */
	int ARROW_DASHED_LINE = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE__NAME = ABSTRACT_LINE__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE__FROM = ABSTRACT_LINE__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE__TO = ABSTRACT_LINE__TO;

	/**
	 * The number of structural features of the '<em>Arrow Dashed Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE_FEATURE_COUNT = ABSTRACT_LINE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Arrow Dashed Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE_OPERATION_COUNT = ABSTRACT_LINE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.LDM.impl.ArrowSolidLineImpl <em>Arrow Solid Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.LDM.impl.ArrowSolidLineImpl
	 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getArrowSolidLine()
	 * @generated
	 */
	int ARROW_SOLID_LINE = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE__NAME = ABSTRACT_LINE__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE__FROM = ABSTRACT_LINE__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE__TO = ABSTRACT_LINE__TO;

	/**
	 * The number of structural features of the '<em>Arrow Solid Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE_FEATURE_COUNT = ABSTRACT_LINE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Arrow Solid Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE_OPERATION_COUNT = ABSTRACT_LINE_OPERATION_COUNT + 0;


	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.BasePanel <em>Base Panel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Base Panel</em>'.
	 * @see org.eclipse.myTest.LDM.BasePanel
	 * @generated
	 */
	EClass getBasePanel();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.myTest.LDM.BasePanel#getHaveShapes <em>Have Shapes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Have Shapes</em>'.
	 * @see org.eclipse.myTest.LDM.BasePanel#getHaveShapes()
	 * @see #getBasePanel()
	 * @generated
	 */
	EReference getBasePanel_HaveShapes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.myTest.LDM.BasePanel#getHaveLines <em>Have Lines</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Have Lines</em>'.
	 * @see org.eclipse.myTest.LDM.BasePanel#getHaveLines()
	 * @see #getBasePanel()
	 * @generated
	 */
	EReference getBasePanel_HaveLines();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.AbstractShapes <em>Abstract Shapes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Shapes</em>'.
	 * @see org.eclipse.myTest.LDM.AbstractShapes
	 * @generated
	 */
	EClass getAbstractShapes();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.myTest.LDM.AbstractShapes#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.myTest.LDM.AbstractShapes#getName()
	 * @see #getAbstractShapes()
	 * @generated
	 */
	EAttribute getAbstractShapes_Name();

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.myTest.LDM.AbstractShapes#getSources <em>Sources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sources</em>'.
	 * @see org.eclipse.myTest.LDM.AbstractShapes#getSources()
	 * @see #getAbstractShapes()
	 * @generated
	 */
	EReference getAbstractShapes_Sources();

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.myTest.LDM.AbstractShapes#getTargets <em>Targets</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Targets</em>'.
	 * @see org.eclipse.myTest.LDM.AbstractShapes#getTargets()
	 * @see #getAbstractShapes()
	 * @generated
	 */
	EReference getAbstractShapes_Targets();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.AbstractLine <em>Abstract Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Line</em>'.
	 * @see org.eclipse.myTest.LDM.AbstractLine
	 * @generated
	 */
	EClass getAbstractLine();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.myTest.LDM.AbstractLine#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.myTest.LDM.AbstractLine#getName()
	 * @see #getAbstractLine()
	 * @generated
	 */
	EAttribute getAbstractLine_Name();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.myTest.LDM.AbstractLine#getFrom <em>From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>From</em>'.
	 * @see org.eclipse.myTest.LDM.AbstractLine#getFrom()
	 * @see #getAbstractLine()
	 * @generated
	 */
	EReference getAbstractLine_From();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.myTest.LDM.AbstractLine#getTo <em>To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>To</em>'.
	 * @see org.eclipse.myTest.LDM.AbstractLine#getTo()
	 * @see #getAbstractLine()
	 * @generated
	 */
	EReference getAbstractLine_To();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.LogicalAssociation <em>Logical Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Logical Association</em>'.
	 * @see org.eclipse.myTest.LDM.LogicalAssociation
	 * @generated
	 */
	EClass getLogicalAssociation();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.LogicalEntity <em>Logical Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Logical Entity</em>'.
	 * @see org.eclipse.myTest.LDM.LogicalEntity
	 * @generated
	 */
	EClass getLogicalEntity();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.LDM <em>LDM</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>LDM</em>'.
	 * @see org.eclipse.myTest.LDM.LDM
	 * @generated
	 */
	EClass getLDM();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.LogicalView <em>Logical View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Logical View</em>'.
	 * @see org.eclipse.myTest.LDM.LogicalView
	 * @generated
	 */
	EClass getLogicalView();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.SolidLine <em>Solid Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solid Line</em>'.
	 * @see org.eclipse.myTest.LDM.SolidLine
	 * @generated
	 */
	EClass getSolidLine();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.DashedLine <em>Dashed Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dashed Line</em>'.
	 * @see org.eclipse.myTest.LDM.DashedLine
	 * @generated
	 */
	EClass getDashedLine();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.ArrowDashedLine <em>Arrow Dashed Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Arrow Dashed Line</em>'.
	 * @see org.eclipse.myTest.LDM.ArrowDashedLine
	 * @generated
	 */
	EClass getArrowDashedLine();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.LDM.ArrowSolidLine <em>Arrow Solid Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Arrow Solid Line</em>'.
	 * @see org.eclipse.myTest.LDM.ArrowSolidLine
	 * @generated
	 */
	EClass getArrowSolidLine();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	LDMFactory getLDMFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.BasePanelImpl <em>Base Panel</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.BasePanelImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getBasePanel()
		 * @generated
		 */
		EClass BASE_PANEL = eINSTANCE.getBasePanel();

		/**
		 * The meta object literal for the '<em><b>Have Shapes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASE_PANEL__HAVE_SHAPES = eINSTANCE.getBasePanel_HaveShapes();

		/**
		 * The meta object literal for the '<em><b>Have Lines</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASE_PANEL__HAVE_LINES = eINSTANCE.getBasePanel_HaveLines();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.AbstractShapesImpl <em>Abstract Shapes</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.AbstractShapesImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getAbstractShapes()
		 * @generated
		 */
		EClass ABSTRACT_SHAPES = eINSTANCE.getAbstractShapes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_SHAPES__NAME = eINSTANCE.getAbstractShapes_Name();

		/**
		 * The meta object literal for the '<em><b>Sources</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_SHAPES__SOURCES = eINSTANCE.getAbstractShapes_Sources();

		/**
		 * The meta object literal for the '<em><b>Targets</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_SHAPES__TARGETS = eINSTANCE.getAbstractShapes_Targets();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.AbstractLineImpl <em>Abstract Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.AbstractLineImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getAbstractLine()
		 * @generated
		 */
		EClass ABSTRACT_LINE = eINSTANCE.getAbstractLine();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_LINE__NAME = eINSTANCE.getAbstractLine_Name();

		/**
		 * The meta object literal for the '<em><b>From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_LINE__FROM = eINSTANCE.getAbstractLine_From();

		/**
		 * The meta object literal for the '<em><b>To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_LINE__TO = eINSTANCE.getAbstractLine_To();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.LogicalAssociationImpl <em>Logical Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.LogicalAssociationImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getLogicalAssociation()
		 * @generated
		 */
		EClass LOGICAL_ASSOCIATION = eINSTANCE.getLogicalAssociation();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.LogicalEntityImpl <em>Logical Entity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.LogicalEntityImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getLogicalEntity()
		 * @generated
		 */
		EClass LOGICAL_ENTITY = eINSTANCE.getLogicalEntity();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.LDMImpl <em>LDM</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.LDMImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getLDM()
		 * @generated
		 */
		EClass LDM = eINSTANCE.getLDM();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.LogicalViewImpl <em>Logical View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.LogicalViewImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getLogicalView()
		 * @generated
		 */
		EClass LOGICAL_VIEW = eINSTANCE.getLogicalView();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.SolidLineImpl <em>Solid Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.SolidLineImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getSolidLine()
		 * @generated
		 */
		EClass SOLID_LINE = eINSTANCE.getSolidLine();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.DashedLineImpl <em>Dashed Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.DashedLineImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getDashedLine()
		 * @generated
		 */
		EClass DASHED_LINE = eINSTANCE.getDashedLine();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.ArrowDashedLineImpl <em>Arrow Dashed Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.ArrowDashedLineImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getArrowDashedLine()
		 * @generated
		 */
		EClass ARROW_DASHED_LINE = eINSTANCE.getArrowDashedLine();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.LDM.impl.ArrowSolidLineImpl <em>Arrow Solid Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.LDM.impl.ArrowSolidLineImpl
		 * @see org.eclipse.myTest.LDM.impl.LDMPackageImpl#getArrowSolidLine()
		 * @generated
		 */
		EClass ARROW_SOLID_LINE = eINSTANCE.getArrowSolidLine();

	}

} //LDMPackage
