/**
 */
package org.eclipse.myTest.LDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Logical Association</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.LDM.LDMPackage#getLogicalAssociation()
 * @model
 * @generated
 */
public interface LogicalAssociation extends AbstractShapes {
} // LogicalAssociation
