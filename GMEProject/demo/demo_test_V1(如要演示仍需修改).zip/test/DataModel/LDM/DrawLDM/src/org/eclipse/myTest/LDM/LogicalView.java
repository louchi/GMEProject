/**
 */
package org.eclipse.myTest.LDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Logical View</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.LDM.LDMPackage#getLogicalView()
 * @model
 * @generated
 */
public interface LogicalView extends AbstractShapes {
} // LogicalView
