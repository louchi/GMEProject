/**
 */
package org.eclipse.myTest.LDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Solid Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.LDM.LDMPackage#getSolidLine()
 * @model
 * @generated
 */
public interface SolidLine extends AbstractLine {
} // SolidLine
