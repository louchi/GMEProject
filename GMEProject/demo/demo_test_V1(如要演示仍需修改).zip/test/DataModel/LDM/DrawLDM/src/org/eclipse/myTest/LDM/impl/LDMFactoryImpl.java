/**
 */
package org.eclipse.myTest.LDM.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.myTest.LDM.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class LDMFactoryImpl extends EFactoryImpl implements LDMFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static LDMFactory init() {
		try {
			LDMFactory theLDMFactory = (LDMFactory)EPackage.Registry.INSTANCE.getEFactory(LDMPackage.eNS_URI);
			if (theLDMFactory != null) {
				return theLDMFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new LDMFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LDMFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case LDMPackage.BASE_PANEL: return createBasePanel();
			case LDMPackage.ABSTRACT_SHAPES: return createAbstractShapes();
			case LDMPackage.ABSTRACT_LINE: return createAbstractLine();
			case LDMPackage.LOGICAL_ASSOCIATION: return createLogicalAssociation();
			case LDMPackage.LOGICAL_ENTITY: return createLogicalEntity();
			case LDMPackage.LDM: return createLDM();
			case LDMPackage.LOGICAL_VIEW: return createLogicalView();
			case LDMPackage.SOLID_LINE: return createSolidLine();
			case LDMPackage.DASHED_LINE: return createDashedLine();
			case LDMPackage.ARROW_DASHED_LINE: return createArrowDashedLine();
			case LDMPackage.ARROW_SOLID_LINE: return createArrowSolidLine();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BasePanel createBasePanel() {
		BasePanelImpl basePanel = new BasePanelImpl();
		return basePanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractShapes createAbstractShapes() {
		AbstractShapesImpl abstractShapes = new AbstractShapesImpl();
		return abstractShapes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractLine createAbstractLine() {
		AbstractLineImpl abstractLine = new AbstractLineImpl();
		return abstractLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LogicalAssociation createLogicalAssociation() {
		LogicalAssociationImpl logicalAssociation = new LogicalAssociationImpl();
		return logicalAssociation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LogicalEntity createLogicalEntity() {
		LogicalEntityImpl logicalEntity = new LogicalEntityImpl();
		return logicalEntity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LDM createLDM() {
		LDMImpl ldm = new LDMImpl();
		return ldm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LogicalView createLogicalView() {
		LogicalViewImpl logicalView = new LogicalViewImpl();
		return logicalView;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SolidLine createSolidLine() {
		SolidLineImpl solidLine = new SolidLineImpl();
		return solidLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DashedLine createDashedLine() {
		DashedLineImpl dashedLine = new DashedLineImpl();
		return dashedLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ArrowDashedLine createArrowDashedLine() {
		ArrowDashedLineImpl arrowDashedLine = new ArrowDashedLineImpl();
		return arrowDashedLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ArrowSolidLine createArrowSolidLine() {
		ArrowSolidLineImpl arrowSolidLine = new ArrowSolidLineImpl();
		return arrowSolidLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LDMPackage getLDMPackage() {
		return (LDMPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static LDMPackage getPackage() {
		return LDMPackage.eINSTANCE;
	}

} //LDMFactoryImpl
