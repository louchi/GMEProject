/**
 */
package org.eclipse.myTest.LDM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.LDM.LDM;
import org.eclipse.myTest.LDM.LDMPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>LDM</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class LDMImpl extends AbstractShapesImpl implements LDM {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LDMImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LDMPackage.Literals.LDM;
	}

} //LDMImpl
