/**
 */
package org.eclipse.myTest.LDM.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.myTest.LDM.AbstractLine;
import org.eclipse.myTest.LDM.AbstractShapes;
import org.eclipse.myTest.LDM.ArrowDashedLine;
import org.eclipse.myTest.LDM.ArrowSolidLine;
import org.eclipse.myTest.LDM.BasePanel;
import org.eclipse.myTest.LDM.DashedLine;
import org.eclipse.myTest.LDM.LDMFactory;
import org.eclipse.myTest.LDM.LDMPackage;
import org.eclipse.myTest.LDM.LogicalAssociation;
import org.eclipse.myTest.LDM.LogicalEntity;
import org.eclipse.myTest.LDM.LogicalView;
import org.eclipse.myTest.LDM.SolidLine;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class LDMPackageImpl extends EPackageImpl implements LDMPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass basePanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractShapesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass logicalAssociationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass logicalEntityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ldmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass logicalViewEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solidLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dashedLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass arrowDashedLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass arrowSolidLineEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eclipse.myTest.LDM.LDMPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private LDMPackageImpl() {
		super(eNS_URI, LDMFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link LDMPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static LDMPackage init() {
		if (isInited) return (LDMPackage)EPackage.Registry.INSTANCE.getEPackage(LDMPackage.eNS_URI);

		// Obtain or create and register package
		LDMPackageImpl theLDMPackage = (LDMPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof LDMPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new LDMPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theLDMPackage.createPackageContents();

		// Initialize created meta-data
		theLDMPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theLDMPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(LDMPackage.eNS_URI, theLDMPackage);
		return theLDMPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBasePanel() {
		return basePanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBasePanel_HaveShapes() {
		return (EReference)basePanelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBasePanel_HaveLines() {
		return (EReference)basePanelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractShapes() {
		return abstractShapesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractShapes_Name() {
		return (EAttribute)abstractShapesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractShapes_Sources() {
		return (EReference)abstractShapesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractShapes_Targets() {
		return (EReference)abstractShapesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractLine() {
		return abstractLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractLine_Name() {
		return (EAttribute)abstractLineEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractLine_From() {
		return (EReference)abstractLineEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractLine_To() {
		return (EReference)abstractLineEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLogicalAssociation() {
		return logicalAssociationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLogicalEntity() {
		return logicalEntityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLDM() {
		return ldmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLogicalView() {
		return logicalViewEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSolidLine() {
		return solidLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDashedLine() {
		return dashedLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getArrowDashedLine() {
		return arrowDashedLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getArrowSolidLine() {
		return arrowSolidLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LDMFactory getLDMFactory() {
		return (LDMFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		basePanelEClass = createEClass(BASE_PANEL);
		createEReference(basePanelEClass, BASE_PANEL__HAVE_SHAPES);
		createEReference(basePanelEClass, BASE_PANEL__HAVE_LINES);

		abstractShapesEClass = createEClass(ABSTRACT_SHAPES);
		createEAttribute(abstractShapesEClass, ABSTRACT_SHAPES__NAME);
		createEReference(abstractShapesEClass, ABSTRACT_SHAPES__SOURCES);
		createEReference(abstractShapesEClass, ABSTRACT_SHAPES__TARGETS);

		abstractLineEClass = createEClass(ABSTRACT_LINE);
		createEAttribute(abstractLineEClass, ABSTRACT_LINE__NAME);
		createEReference(abstractLineEClass, ABSTRACT_LINE__FROM);
		createEReference(abstractLineEClass, ABSTRACT_LINE__TO);

		logicalAssociationEClass = createEClass(LOGICAL_ASSOCIATION);

		logicalEntityEClass = createEClass(LOGICAL_ENTITY);

		ldmEClass = createEClass(LDM);

		logicalViewEClass = createEClass(LOGICAL_VIEW);

		solidLineEClass = createEClass(SOLID_LINE);

		dashedLineEClass = createEClass(DASHED_LINE);

		arrowDashedLineEClass = createEClass(ARROW_DASHED_LINE);

		arrowSolidLineEClass = createEClass(ARROW_SOLID_LINE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		logicalAssociationEClass.getESuperTypes().add(this.getAbstractShapes());
		logicalEntityEClass.getESuperTypes().add(this.getAbstractShapes());
		ldmEClass.getESuperTypes().add(this.getAbstractShapes());
		logicalViewEClass.getESuperTypes().add(this.getAbstractShapes());
		solidLineEClass.getESuperTypes().add(this.getAbstractLine());
		dashedLineEClass.getESuperTypes().add(this.getAbstractLine());
		arrowDashedLineEClass.getESuperTypes().add(this.getAbstractLine());
		arrowSolidLineEClass.getESuperTypes().add(this.getAbstractLine());

		// Initialize classes, features, and operations; add parameters
		initEClass(basePanelEClass, BasePanel.class, "BasePanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBasePanel_HaveShapes(), this.getAbstractShapes(), null, "haveShapes", null, 0, -1, BasePanel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBasePanel_HaveLines(), this.getAbstractLine(), null, "haveLines", null, 0, -1, BasePanel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractShapesEClass, AbstractShapes.class, "AbstractShapes", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractShapes_Name(), ecorePackage.getEString(), "name", null, 0, 1, AbstractShapes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractShapes_Sources(), this.getAbstractLine(), null, "sources", null, 0, -1, AbstractShapes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractShapes_Targets(), this.getAbstractLine(), null, "targets", null, 0, -1, AbstractShapes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractLineEClass, AbstractLine.class, "AbstractLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractLine_Name(), ecorePackage.getEString(), "name", null, 0, 1, AbstractLine.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractLine_From(), this.getAbstractShapes(), null, "from", null, 0, 1, AbstractLine.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractLine_To(), this.getAbstractShapes(), null, "to", null, 0, 1, AbstractLine.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(logicalAssociationEClass, LogicalAssociation.class, "LogicalAssociation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(logicalEntityEClass, LogicalEntity.class, "LogicalEntity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(ldmEClass, org.eclipse.myTest.LDM.LDM.class, "LDM", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(logicalViewEClass, LogicalView.class, "LogicalView", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solidLineEClass, SolidLine.class, "SolidLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(dashedLineEClass, DashedLine.class, "DashedLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(arrowDashedLineEClass, ArrowDashedLine.class, "ArrowDashedLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(arrowSolidLineEClass, ArrowSolidLine.class, "ArrowSolidLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}

} //LDMPackageImpl
