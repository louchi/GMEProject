/**
 */
package org.eclipse.myTest.LDM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.LDM.LDMPackage;
import org.eclipse.myTest.LDM.LogicalEntity;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Logical Entity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class LogicalEntityImpl extends AbstractShapesImpl implements LogicalEntity {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LogicalEntityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LDMPackage.Literals.LOGICAL_ENTITY;
	}

} //LogicalEntityImpl
