/**
 */
package org.eclipse.myTest.LDM.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import org.eclipse.myTest.LDM.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.myTest.LDM.LDMPackage
 * @generated
 */
public class LDMAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static LDMPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LDMAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = LDMPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LDMSwitch<Adapter> modelSwitch =
		new LDMSwitch<Adapter>() {
			@Override
			public Adapter caseBasePanel(BasePanel object) {
				return createBasePanelAdapter();
			}
			@Override
			public Adapter caseAbstractShapes(AbstractShapes object) {
				return createAbstractShapesAdapter();
			}
			@Override
			public Adapter caseAbstractLine(AbstractLine object) {
				return createAbstractLineAdapter();
			}
			@Override
			public Adapter caseLogicalAssociation(LogicalAssociation object) {
				return createLogicalAssociationAdapter();
			}
			@Override
			public Adapter caseLogicalEntity(LogicalEntity object) {
				return createLogicalEntityAdapter();
			}
			@Override
			public Adapter caseLDM(LDM object) {
				return createLDMAdapter();
			}
			@Override
			public Adapter caseLogicalView(LogicalView object) {
				return createLogicalViewAdapter();
			}
			@Override
			public Adapter caseSolidLine(SolidLine object) {
				return createSolidLineAdapter();
			}
			@Override
			public Adapter caseDashedLine(DashedLine object) {
				return createDashedLineAdapter();
			}
			@Override
			public Adapter caseArrowDashedLine(ArrowDashedLine object) {
				return createArrowDashedLineAdapter();
			}
			@Override
			public Adapter caseArrowSolidLine(ArrowSolidLine object) {
				return createArrowSolidLineAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.BasePanel <em>Base Panel</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.BasePanel
	 * @generated
	 */
	public Adapter createBasePanelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.AbstractShapes <em>Abstract Shapes</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.AbstractShapes
	 * @generated
	 */
	public Adapter createAbstractShapesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.AbstractLine <em>Abstract Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.AbstractLine
	 * @generated
	 */
	public Adapter createAbstractLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.LogicalAssociation <em>Logical Association</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.LogicalAssociation
	 * @generated
	 */
	public Adapter createLogicalAssociationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.LogicalEntity <em>Logical Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.LogicalEntity
	 * @generated
	 */
	public Adapter createLogicalEntityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.LDM <em>LDM</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.LDM
	 * @generated
	 */
	public Adapter createLDMAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.LogicalView <em>Logical View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.LogicalView
	 * @generated
	 */
	public Adapter createLogicalViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.SolidLine <em>Solid Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.SolidLine
	 * @generated
	 */
	public Adapter createSolidLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.DashedLine <em>Dashed Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.DashedLine
	 * @generated
	 */
	public Adapter createDashedLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.ArrowDashedLine <em>Arrow Dashed Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.ArrowDashedLine
	 * @generated
	 */
	public Adapter createArrowDashedLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.LDM.ArrowSolidLine <em>Arrow Solid Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.LDM.ArrowSolidLine
	 * @generated
	 */
	public Adapter createArrowSolidLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //LDMAdapterFactory
