package org.eclipse.myTest.PDM.diagram.edit.helpers;

/**
 * @generated
 */
public class BasePanelEditHelper extends
		org.eclipse.myTest.PDM.diagram.edit.helpers.MyPDMBaseEditHelper {
}
