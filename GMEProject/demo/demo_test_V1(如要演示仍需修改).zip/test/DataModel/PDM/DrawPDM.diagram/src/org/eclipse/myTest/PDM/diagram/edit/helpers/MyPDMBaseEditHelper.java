package org.eclipse.myTest.PDM.diagram.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * @generated
 */
public class MyPDMBaseEditHelper extends GeneratedEditHelperBase {

}
