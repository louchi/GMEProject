package org.eclipse.myTest.PDM.diagram.edit.helpers;

/**
 * @generated
 */
public class PlatformEntityEditHelper extends
		org.eclipse.myTest.PDM.diagram.edit.helpers.MyPDMBaseEditHelper {
}
