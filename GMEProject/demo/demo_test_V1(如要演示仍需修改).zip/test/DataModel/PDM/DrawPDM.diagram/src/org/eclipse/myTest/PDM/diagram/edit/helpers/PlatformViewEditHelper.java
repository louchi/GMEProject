package org.eclipse.myTest.PDM.diagram.edit.helpers;

/**
 * @generated
 */
public class PlatformViewEditHelper extends
		org.eclipse.myTest.PDM.diagram.edit.helpers.MyPDMBaseEditHelper {
}
