package org.eclipse.myTest.PDM.diagram.edit.parts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

/**
 * @generated
 */
public class MyPDMEditPartFactory implements EditPartFactory {

	/**
	 * @generated
	 */
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
					.getVisualID(view)) {

			case org.eclipse.myTest.PDM.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.BasePanelEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.PDMEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.PDMEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.PDMNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.PDMNameEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewNameEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityNameEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationNameEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.ArrowSolidLineEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowSolidLineNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.ArrowSolidLineNameEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.DashedLineEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.DashedLineNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.DashedLineNameEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.ArrowDashedLineEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowDashedLineNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.ArrowDashedLineNameEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.SolidLineEditPart(
						view);

			case org.eclipse.myTest.PDM.diagram.edit.parts.SolidLineNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.PDM.diagram.edit.parts.SolidLineNameEditPart(
						view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	 * @generated
	 */
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	 * @generated
	 */
	public static CellEditorLocator getTextCellEditorLocator(
			ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE
				.getTextCellEditorLocator(source);
	}

}
