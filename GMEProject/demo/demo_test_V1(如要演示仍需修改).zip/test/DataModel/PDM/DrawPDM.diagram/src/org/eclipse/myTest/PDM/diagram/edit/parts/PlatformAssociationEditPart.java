package org.eclipse.myTest.PDM.diagram.edit.parts;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.draw2d.FlowLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.RoundedRectangle;
import org.eclipse.draw2d.Shape;
import org.eclipse.draw2d.StackLayout;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.LayoutEditPolicy;
import org.eclipse.gef.requests.CreateRequest;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ShapeNodeEditPart;
import org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles;
import org.eclipse.gmf.runtime.diagram.ui.editpolicies.FlowLayoutEditPolicy;
import org.eclipse.gmf.runtime.draw2d.ui.figures.ConstrainedToolbarLayout;
import org.eclipse.gmf.runtime.draw2d.ui.figures.WrappingLabel;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.gef.ui.figures.DefaultSizeNodeFigure;
import org.eclipse.gmf.runtime.gef.ui.figures.NodeFigure;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.swt.graphics.Color;

/**
 * @generated
 */
public class PlatformAssociationEditPart extends ShapeNodeEditPart {

	/**
	 * @generated
	 */
	public static final int VISUAL_ID = 2004;

	/**
	 * @generated
	 */
	protected IFigure contentPane;

	/**
	 * @generated
	 */
	protected IFigure primaryShape;

	/**
	 * @generated
	 */
	public PlatformAssociationEditPart(View view) {
		super(view);
	}

	/**
	 * @generated
	 */
	protected void createDefaultEditPolicies() {
		super.createDefaultEditPolicies();
		installEditPolicy(
				EditPolicyRoles.SEMANTIC_ROLE,
				new org.eclipse.myTest.PDM.diagram.edit.policies.PlatformAssociationItemSemanticEditPolicy());
		installEditPolicy(EditPolicy.LAYOUT_ROLE, createLayoutEditPolicy());
		// XXX need an SCR to runtime to have another abstract superclass that would let children add reasonable editpolicies
		// removeEditPolicy(org.eclipse.gmf.runtime.diagram.ui.editpolicies.EditPolicyRoles.CONNECTION_HANDLES_ROLE);
	}

	/**
	 * @generated
	 */
	protected LayoutEditPolicy createLayoutEditPolicy() {

		FlowLayoutEditPolicy lep = new FlowLayoutEditPolicy() {

			protected Command createAddCommand(EditPart child, EditPart after) {
				return null;
			}

			protected Command createMoveChildCommand(EditPart child,
					EditPart after) {
				return null;
			}

			protected Command getCreateCommand(CreateRequest request) {
				return null;
			}
		};
		return lep;
	}

	/**
	 * @generated
	 */
	protected IFigure createNodeShape() {
		return primaryShape = new PlatformAssociationFigure();
	}

	/**
	 * @generated
	 */
	public PlatformAssociationFigure getPrimaryShape() {
		return (PlatformAssociationFigure) primaryShape;
	}

	/**
	 * @generated
	 */
	protected boolean addFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationNameEditPart) {
			((org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationNameEditPart) childEditPart)
					.setLabel(getPrimaryShape()
							.getFigurePlatformAssociationNameFigure());
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected boolean removeFixedChild(EditPart childEditPart) {
		if (childEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationNameEditPart) {
			return true;
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected void addChildVisual(EditPart childEditPart, int index) {
		if (addFixedChild(childEditPart)) {
			return;
		}
		super.addChildVisual(childEditPart, -1);
	}

	/**
	 * @generated
	 */
	protected void removeChildVisual(EditPart childEditPart) {
		if (removeFixedChild(childEditPart)) {
			return;
		}
		super.removeChildVisual(childEditPart);
	}

	/**
	 * @generated
	 */
	protected IFigure getContentPaneFor(IGraphicalEditPart editPart) {
		return getContentPane();
	}

	/**
	 * @generated
	 */
	protected NodeFigure createNodePlate() {
		DefaultSizeNodeFigure result = new DefaultSizeNodeFigure(40, 40);
		return result;
	}

	/**
	 * Creates figure for this edit part.
	 * 
	 * Body of this method does not depend on settings in generation model
	 * so you may safely remove <i>generated</i> tag and modify it.
	 * 
	 * @generated
	 */
	protected NodeFigure createNodeFigure() {
		NodeFigure figure = createNodePlate();
		figure.setLayoutManager(new StackLayout());
		IFigure shape = createNodeShape();
		figure.add(shape);
		contentPane = setupContentPane(shape);
		return figure;
	}

	/**
	 * Default implementation treats passed figure as content pane.
	 * Respects layout one may have set for generated figure.
	 * @param nodeShape instance of generated figure class
	 * @generated
	 */
	protected IFigure setupContentPane(IFigure nodeShape) {
		if (nodeShape.getLayoutManager() == null) {
			ConstrainedToolbarLayout layout = new ConstrainedToolbarLayout();
			layout.setSpacing(5);
			nodeShape.setLayoutManager(layout);
		}
		return nodeShape; // use nodeShape itself as contentPane
	}

	/**
	 * @generated
	 */
	public IFigure getContentPane() {
		if (contentPane != null) {
			return contentPane;
		}
		return super.getContentPane();
	}

	/**
	 * @generated
	 */
	protected void setForegroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setForegroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setBackgroundColor(Color color) {
		if (primaryShape != null) {
			primaryShape.setBackgroundColor(color);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineWidth(int width) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineWidth(width);
		}
	}

	/**
	 * @generated
	 */
	protected void setLineType(int style) {
		if (primaryShape instanceof Shape) {
			((Shape) primaryShape).setLineStyle(style);
		}
	}

	/**
	 * @generated
	 */
	public EditPart getPrimaryChildEditPart() {
		return getChildBySemanticHint(org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
				.getType(org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationNameEditPart.VISUAL_ID));
	}

	/**
	 * @generated
	 */
	public List<IElementType> getMARelTypesOnSource() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(4);
		types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001);
		types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002);
		types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003);
		types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004);
		return types;
	}

	/**
	 * @generated
	 */
	public List<IElementType> getMARelTypesOnSourceAndTarget(
			IGraphicalEditPart targetEditPart) {
		LinkedList<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PDMEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PDMEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PDMEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PDMEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004);
		}
		if (targetEditPart instanceof org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationEditPart) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public List<IElementType> getMATypesForTarget(IElementType relationshipType) {
		LinkedList<IElementType> types = new LinkedList<IElementType>();
		if (relationshipType == org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004);
		} else if (relationshipType == org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004);
		} else if (relationshipType == org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004);
		} else if (relationshipType == org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public List<IElementType> getMARelTypesOnTarget() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(4);
		types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001);
		types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002);
		types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003);
		types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004);
		return types;
	}

	/**
	 * @generated
	 */
	public List<IElementType> getMATypesForSource(IElementType relationshipType) {
		LinkedList<IElementType> types = new LinkedList<IElementType>();
		if (relationshipType == org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004);
		} else if (relationshipType == org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004);
		} else if (relationshipType == org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004);
		} else if (relationshipType == org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004) {
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003);
			types.add(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004);
		}
		return types;
	}

	/**
	 * @generated
	 */
	public class PlatformAssociationFigure extends RoundedRectangle {

		/**
		 * @generated
		 */
		private WrappingLabel fFigurePlatformAssociationNameFigure;

		/**
		 * @generated
		 */
		public PlatformAssociationFigure() {

			FlowLayout layoutThis = new FlowLayout();
			layoutThis.setStretchMinorAxis(false);
			layoutThis.setMinorAlignment(FlowLayout.ALIGN_LEFTTOP);

			layoutThis.setMajorAlignment(FlowLayout.ALIGN_LEFTTOP);
			layoutThis.setMajorSpacing(5);
			layoutThis.setMinorSpacing(5);
			layoutThis.setHorizontal(true);

			this.setLayoutManager(layoutThis);

			this.setCornerDimensions(new Dimension(getMapMode().DPtoLP(8),
					getMapMode().DPtoLP(8)));
			createContents();
		}

		/**
		 * @generated
		 */
		private void createContents() {

			fFigurePlatformAssociationNameFigure = new WrappingLabel();

			fFigurePlatformAssociationNameFigure.setText("PlatformAssociation");

			this.add(fFigurePlatformAssociationNameFigure);

		}

		/**
		 * @generated
		 */
		public WrappingLabel getFigurePlatformAssociationNameFigure() {
			return fFigurePlatformAssociationNameFigure;
		}

	}

}
