package org.eclipse.myTest.PDM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.commands.DestroyElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.DestroyElementRequest;

/**
 * @generated
 */
public class ArrowDashedLineItemSemanticEditPolicy
		extends
		org.eclipse.myTest.PDM.diagram.edit.policies.MyPDMBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public ArrowDashedLineItemSemanticEditPolicy() {
		super(
				org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003);
	}

	/**
	 * @generated
	 */
	protected Command getDestroyElementCommand(DestroyElementRequest req) {
		return getGEFWrapper(new DestroyElementCommand(req));
	}

}
