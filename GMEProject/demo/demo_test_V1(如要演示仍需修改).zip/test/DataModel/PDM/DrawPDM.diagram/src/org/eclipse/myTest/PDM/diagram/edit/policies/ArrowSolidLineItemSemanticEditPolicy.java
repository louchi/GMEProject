package org.eclipse.myTest.PDM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.commands.DestroyElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.DestroyElementRequest;

/**
 * @generated
 */
public class ArrowSolidLineItemSemanticEditPolicy
		extends
		org.eclipse.myTest.PDM.diagram.edit.policies.MyPDMBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public ArrowSolidLineItemSemanticEditPolicy() {
		super(
				org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001);
	}

	/**
	 * @generated
	 */
	protected Command getDestroyElementCommand(DestroyElementRequest req) {
		return getGEFWrapper(new DestroyElementCommand(req));
	}

}
