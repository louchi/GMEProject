package org.eclipse.myTest.PDM.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.commands.DestroyElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.DestroyElementRequest;

/**
 * @generated
 */
public class SolidLineItemSemanticEditPolicy
		extends
		org.eclipse.myTest.PDM.diagram.edit.policies.MyPDMBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public SolidLineItemSemanticEditPolicy() {
		super(
				org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004);
	}

	/**
	 * @generated
	 */
	protected Command getDestroyElementCommand(DestroyElementRequest req) {
		return getGEFWrapper(new DestroyElementCommand(req));
	}

}
