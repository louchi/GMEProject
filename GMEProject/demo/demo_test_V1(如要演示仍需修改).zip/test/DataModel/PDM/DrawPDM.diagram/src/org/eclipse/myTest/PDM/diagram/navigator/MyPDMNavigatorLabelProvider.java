package org.eclipse.myTest.PDM.diagram.navigator;

import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class MyPDMNavigatorLabelProvider extends LabelProvider implements
		ICommonLabelProvider, ITreePathLabelProvider {

	/**
	 * @generated
	 */
	static {
		org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem
				&& !isOwnView(((org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem) element)
						.getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	 * @generated
	 */
	public Image getImage(Object element) {
		if (element instanceof org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorGroup) {
			org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorGroup group = (org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorGroup) element;
			return org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().getBundledImage(group.getIcon());
		}

		if (element instanceof org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem) {
			org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem navigatorItem = (org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		return super.getImage(element);
	}

	/**
	 * @generated
	 */
	public Image getImage(View view) {
		switch (org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?PDM.myTest.eclipse.org?ArrowDashedLine", org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003); //$NON-NLS-1$
		case org.eclipse.myTest.PDM.diagram.edit.parts.PDMEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?PDM.myTest.eclipse.org?PDM", org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001); //$NON-NLS-1$
		case org.eclipse.myTest.PDM.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Diagram?PDM.myTest.eclipse.org?BasePanel", org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.BasePanel_1000); //$NON-NLS-1$
		case org.eclipse.myTest.PDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?PDM.myTest.eclipse.org?SolidLine", org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004); //$NON-NLS-1$
		case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?PDM.myTest.eclipse.org?PlatformView", org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002); //$NON-NLS-1$
		case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?PDM.myTest.eclipse.org?ArrowSolidLine", org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001); //$NON-NLS-1$
		case org.eclipse.myTest.PDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?PDM.myTest.eclipse.org?DashedLine", org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002); //$NON-NLS-1$
		case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?PDM.myTest.eclipse.org?PlatformAssociation", org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004); //$NON-NLS-1$
		case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?PDM.myTest.eclipse.org?PlatformEntity", org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003); //$NON-NLS-1$
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
				.getInstance().getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null
				&& elementType != null
				&& org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
						.isKnownElementType(elementType)) {
			image = org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
					.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public String getText(Object element) {
		if (element instanceof org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorGroup) {
			org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorGroup group = (org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem) {
			org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem navigatorItem = (org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		return super.getText(element);
	}

	/**
	 * @generated
	 */
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowDashedLineEditPart.VISUAL_ID:
			return getArrowDashedLine_4003Text(view);
		case org.eclipse.myTest.PDM.diagram.edit.parts.PDMEditPart.VISUAL_ID:
			return getPDM_2001Text(view);
		case org.eclipse.myTest.PDM.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
			return getBasePanel_1000Text(view);
		case org.eclipse.myTest.PDM.diagram.edit.parts.SolidLineEditPart.VISUAL_ID:
			return getSolidLine_4004Text(view);
		case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewEditPart.VISUAL_ID:
			return getPlatformView_2002Text(view);
		case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowSolidLineEditPart.VISUAL_ID:
			return getArrowSolidLine_4001Text(view);
		case org.eclipse.myTest.PDM.diagram.edit.parts.DashedLineEditPart.VISUAL_ID:
			return getDashedLine_4002Text(view);
		case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationEditPart.VISUAL_ID:
			return getPlatformAssociation_2004Text(view);
		case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityEditPart.VISUAL_ID:
			return getPlatformEntity_2003Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	 * @generated
	 */
	private String getArrowDashedLine_4003Text(View view) {
		IParser parser = org.eclipse.myTest.PDM.diagram.providers.MyPDMParserProvider
				.getParser(
						org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
								.getType(org.eclipse.myTest.PDM.diagram.edit.parts.ArrowDashedLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 6003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getPDM_2001Text(View view) {
		IParser parser = org.eclipse.myTest.PDM.diagram.providers.MyPDMParserProvider
				.getParser(
						org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
								.getType(org.eclipse.myTest.PDM.diagram.edit.parts.PDMNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 5001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getBasePanel_1000Text(View view) {
		return ""; //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private String getSolidLine_4004Text(View view) {
		IParser parser = org.eclipse.myTest.PDM.diagram.providers.MyPDMParserProvider
				.getParser(
						org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
								.getType(org.eclipse.myTest.PDM.diagram.edit.parts.SolidLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 6004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getPlatformView_2002Text(View view) {
		IParser parser = org.eclipse.myTest.PDM.diagram.providers.MyPDMParserProvider
				.getParser(
						org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
								.getType(org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 5002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getArrowSolidLine_4001Text(View view) {
		IParser parser = org.eclipse.myTest.PDM.diagram.providers.MyPDMParserProvider
				.getParser(
						org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
								.getType(org.eclipse.myTest.PDM.diagram.edit.parts.ArrowSolidLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 6001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getDashedLine_4002Text(View view) {
		IParser parser = org.eclipse.myTest.PDM.diagram.providers.MyPDMParserProvider
				.getParser(
						org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
								.getType(org.eclipse.myTest.PDM.diagram.edit.parts.DashedLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 6002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getPlatformAssociation_2004Text(View view) {
		IParser parser = org.eclipse.myTest.PDM.diagram.providers.MyPDMParserProvider
				.getParser(
						org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
								.getType(org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 5004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getPlatformEntity_2003Text(View view) {
		IParser parser = org.eclipse.myTest.PDM.diagram.providers.MyPDMParserProvider
				.getParser(
						org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003,
						view.getElement() != null ? view.getElement() : view,
						org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
								.getType(org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().logError(
							"Parser was not found for label " + 5003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	 * @generated
	 */
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return org.eclipse.myTest.PDM.diagram.edit.parts.BasePanelEditPart.MODEL_ID
				.equals(org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
						.getModelID(view));
	}

}
