package org.eclipse.myTest.PDM.diagram.navigator;

import org.eclipse.jface.viewers.ViewerSorter;

/**
 * @generated
 */
public class MyPDMNavigatorSorter extends ViewerSorter {

	/**
	 * @generated
	 */
	private static final int GROUP_CATEGORY = 4006;

	/**
	 * @generated
	 */
	public int category(Object element) {
		if (element instanceof org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem) {
			org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem item = (org.eclipse.myTest.PDM.diagram.navigator.MyPDMNavigatorItem) element;
			return org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
					.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
