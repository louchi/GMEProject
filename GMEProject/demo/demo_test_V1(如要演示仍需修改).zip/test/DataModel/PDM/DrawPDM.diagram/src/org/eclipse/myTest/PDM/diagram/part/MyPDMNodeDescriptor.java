package org.eclipse.myTest.PDM.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class MyPDMNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	 * @generated
	 */
	public MyPDMNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
