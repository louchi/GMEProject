package org.eclipse.myTest.PDM.diagram.part;

import java.util.Collections;
import java.util.List;

import org.eclipse.gef.Tool;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeConnectionTool;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeCreationTool;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class MyPDMPaletteFactory {

	/**
	 * @generated
	 */
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createPDM1Group());
		paletteRoot.add(createConnections2Group());
	}

	/**
	 * Creates "PDM" palette tool group
	 * @generated
	 */
	private PaletteContainer createPDM1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				org.eclipse.myTest.PDM.diagram.part.Messages.PDM1Group_title);
		paletteContainer.setId("createPDM1Group"); //$NON-NLS-1$
		paletteContainer
				.setDescription(org.eclipse.myTest.PDM.diagram.part.Messages.PDM1Group_desc);
		paletteContainer.add(createPDM21CreationTool());
		paletteContainer.add(createPlatformView2CreationTool());
		paletteContainer.add(createPlatformAssociation3CreationTool());
		paletteContainer.add(createPlatformEntity4CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Connections" palette tool group
	 * @generated
	 */
	private PaletteContainer createConnections2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				org.eclipse.myTest.PDM.diagram.part.Messages.Connections2Group_title);
		paletteContainer.setId("createConnections2Group"); //$NON-NLS-1$
		paletteContainer.add(createSolidLine1CreationTool());
		paletteContainer.add(createDashedLine2CreationTool());
		paletteContainer.add(createArrowSolidLine3CreationTool());
		paletteContainer.add(createArrowDashedLine4CreationTool());
		return paletteContainer;
	}

	/**
	 * @generated
	 */
	private ToolEntry createPDM21CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				org.eclipse.myTest.PDM.diagram.part.Messages.PDM21CreationTool_title,
				org.eclipse.myTest.PDM.diagram.part.Messages.PDM21CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001));
		entry.setId("createPDM21CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PDM_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createPlatformView2CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				org.eclipse.myTest.PDM.diagram.part.Messages.PlatformView2CreationTool_title,
				org.eclipse.myTest.PDM.diagram.part.Messages.PlatformView2CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002));
		entry.setId("createPlatformView2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformView_2002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createPlatformAssociation3CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				org.eclipse.myTest.PDM.diagram.part.Messages.PlatformAssociation3CreationTool_title,
				org.eclipse.myTest.PDM.diagram.part.Messages.PlatformAssociation3CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004));
		entry.setId("createPlatformAssociation3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformAssociation_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createPlatformEntity4CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				org.eclipse.myTest.PDM.diagram.part.Messages.PlatformEntity4CreationTool_title,
				org.eclipse.myTest.PDM.diagram.part.Messages.PlatformEntity4CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003));
		entry.setId("createPlatformEntity4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.PlatformEntity_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSolidLine1CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				org.eclipse.myTest.PDM.diagram.part.Messages.SolidLine1CreationTool_title,
				org.eclipse.myTest.PDM.diagram.part.Messages.SolidLine1CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004));
		entry.setId("createSolidLine1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.SolidLine_4004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createDashedLine2CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				org.eclipse.myTest.PDM.diagram.part.Messages.DashedLine2CreationTool_title,
				org.eclipse.myTest.PDM.diagram.part.Messages.DashedLine2CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002));
		entry.setId("createDashedLine2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.DashedLine_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createArrowSolidLine3CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				org.eclipse.myTest.PDM.diagram.part.Messages.ArrowSolidLine3CreationTool_title,
				org.eclipse.myTest.PDM.diagram.part.Messages.ArrowSolidLine3CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001));
		entry.setId("createArrowSolidLine3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowSolidLine_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createArrowDashedLine4CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				org.eclipse.myTest.PDM.diagram.part.Messages.ArrowDashedLine4CreationTool_title,
				org.eclipse.myTest.PDM.diagram.part.Messages.ArrowDashedLine4CreationTool_desc,
				Collections
						.singletonList(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003));
		entry.setId("createArrowDashedLine4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
				.getImageDescriptor(org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes.ArrowDashedLine_4003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private static class NodeToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List<IElementType> elementTypes;

		/**
		 * @generated
		 */
		private NodeToolEntry(String title, String description,
				List<IElementType> elementTypes) {
			super(title, description, null, null);
			this.elementTypes = elementTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeCreationTool(elementTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}

	/**
	 * @generated
	 */
	private static class LinkToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List<IElementType> relationshipTypes;

		/**
		 * @generated
		 */
		private LinkToolEntry(String title, String description,
				List<IElementType> relationshipTypes) {
			super(title, description, null, null);
			this.relationshipTypes = relationshipTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeConnectionTool(relationshipTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}
}
