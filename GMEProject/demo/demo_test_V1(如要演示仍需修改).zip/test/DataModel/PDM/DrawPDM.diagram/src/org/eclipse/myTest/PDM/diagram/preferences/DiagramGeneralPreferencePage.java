package org.eclipse.myTest.PDM.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
