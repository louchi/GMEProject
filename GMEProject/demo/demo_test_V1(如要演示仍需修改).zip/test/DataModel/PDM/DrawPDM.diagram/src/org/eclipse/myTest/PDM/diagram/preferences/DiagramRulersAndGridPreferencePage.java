package org.eclipse.myTest.PDM.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
