package org.eclipse.myTest.PDM.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	 * @generated
	 */
	public static ElementInitializers getInstance() {
		ElementInitializers cached = org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
				.getInstance().getElementInitializers();
		if (cached == null) {
			org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
					.getInstance().setElementInitializers(
							cached = new ElementInitializers());
		}
		return cached;
	}
}
