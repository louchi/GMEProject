package org.eclipse.myTest.PDM.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class MyPDMParserProvider extends AbstractProvider implements
		IParserProvider {

	/**
	 * @generated
	 */
	private IParser pDMName_5001Parser;

	/**
	 * @generated
	 */
	private IParser getPDMName_5001Parser() {
		if (pDMName_5001Parser == null) {
			EAttribute[] features = new EAttribute[] { org.eclipse.myTest.PDM.PDMPackage.eINSTANCE
					.getAbstractShapes_Name() };
			org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser parser = new org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser(
					features);
			pDMName_5001Parser = parser;
		}
		return pDMName_5001Parser;
	}

	/**
	 * @generated
	 */
	private IParser platformViewName_5002Parser;

	/**
	 * @generated
	 */
	private IParser getPlatformViewName_5002Parser() {
		if (platformViewName_5002Parser == null) {
			EAttribute[] features = new EAttribute[] { org.eclipse.myTest.PDM.PDMPackage.eINSTANCE
					.getAbstractShapes_Name() };
			org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser parser = new org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser(
					features);
			platformViewName_5002Parser = parser;
		}
		return platformViewName_5002Parser;
	}

	/**
	 * @generated
	 */
	private IParser platformEntityName_5003Parser;

	/**
	 * @generated
	 */
	private IParser getPlatformEntityName_5003Parser() {
		if (platformEntityName_5003Parser == null) {
			EAttribute[] features = new EAttribute[] { org.eclipse.myTest.PDM.PDMPackage.eINSTANCE
					.getAbstractShapes_Name() };
			org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser parser = new org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser(
					features);
			platformEntityName_5003Parser = parser;
		}
		return platformEntityName_5003Parser;
	}

	/**
	 * @generated
	 */
	private IParser platformAssociationName_5004Parser;

	/**
	 * @generated
	 */
	private IParser getPlatformAssociationName_5004Parser() {
		if (platformAssociationName_5004Parser == null) {
			EAttribute[] features = new EAttribute[] { org.eclipse.myTest.PDM.PDMPackage.eINSTANCE
					.getAbstractShapes_Name() };
			org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser parser = new org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser(
					features);
			platformAssociationName_5004Parser = parser;
		}
		return platformAssociationName_5004Parser;
	}

	/**
	 * @generated
	 */
	private IParser arrowSolidLineName_6001Parser;

	/**
	 * @generated
	 */
	private IParser getArrowSolidLineName_6001Parser() {
		if (arrowSolidLineName_6001Parser == null) {
			EAttribute[] features = new EAttribute[] { org.eclipse.myTest.PDM.PDMPackage.eINSTANCE
					.getAbstractLine_Name() };
			org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser parser = new org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser(
					features);
			arrowSolidLineName_6001Parser = parser;
		}
		return arrowSolidLineName_6001Parser;
	}

	/**
	 * @generated
	 */
	private IParser dashedLineName_6002Parser;

	/**
	 * @generated
	 */
	private IParser getDashedLineName_6002Parser() {
		if (dashedLineName_6002Parser == null) {
			EAttribute[] features = new EAttribute[] { org.eclipse.myTest.PDM.PDMPackage.eINSTANCE
					.getAbstractLine_Name() };
			org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser parser = new org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser(
					features);
			dashedLineName_6002Parser = parser;
		}
		return dashedLineName_6002Parser;
	}

	/**
	 * @generated
	 */
	private IParser arrowDashedLineName_6003Parser;

	/**
	 * @generated
	 */
	private IParser getArrowDashedLineName_6003Parser() {
		if (arrowDashedLineName_6003Parser == null) {
			EAttribute[] features = new EAttribute[] { org.eclipse.myTest.PDM.PDMPackage.eINSTANCE
					.getAbstractLine_Name() };
			org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser parser = new org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser(
					features);
			arrowDashedLineName_6003Parser = parser;
		}
		return arrowDashedLineName_6003Parser;
	}

	/**
	 * @generated
	 */
	private IParser solidLineName_6004Parser;

	/**
	 * @generated
	 */
	private IParser getSolidLineName_6004Parser() {
		if (solidLineName_6004Parser == null) {
			EAttribute[] features = new EAttribute[] { org.eclipse.myTest.PDM.PDMPackage.eINSTANCE
					.getAbstractLine_Name() };
			org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser parser = new org.eclipse.myTest.PDM.diagram.parsers.MessageFormatParser(
					features);
			solidLineName_6004Parser = parser;
		}
		return solidLineName_6004Parser;
	}

	/**
	 * @generated
	 */
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case org.eclipse.myTest.PDM.diagram.edit.parts.PDMNameEditPart.VISUAL_ID:
			return getPDMName_5001Parser();
		case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformViewNameEditPart.VISUAL_ID:
			return getPlatformViewName_5002Parser();
		case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformEntityNameEditPart.VISUAL_ID:
			return getPlatformEntityName_5003Parser();
		case org.eclipse.myTest.PDM.diagram.edit.parts.PlatformAssociationNameEditPart.VISUAL_ID:
			return getPlatformAssociationName_5004Parser();
		case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowSolidLineNameEditPart.VISUAL_ID:
			return getArrowSolidLineName_6001Parser();
		case org.eclipse.myTest.PDM.diagram.edit.parts.DashedLineNameEditPart.VISUAL_ID:
			return getDashedLineName_6002Parser();
		case org.eclipse.myTest.PDM.diagram.edit.parts.ArrowDashedLineNameEditPart.VISUAL_ID:
			return getArrowDashedLineName_6003Parser();
		case org.eclipse.myTest.PDM.diagram.edit.parts.SolidLineNameEditPart.VISUAL_ID:
			return getSolidLineName_6004Parser();
		}
		return null;
	}

	/**
	 * Utility method that consults ParserService
	 * @generated
	 */
	public static IParser getParser(IElementType type, EObject object,
			String parserHint) {
		return ParserService.getInstance().getParser(
				new HintAdapter(type, object, parserHint));
	}

	/**
	 * @generated
	 */
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
					.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(org.eclipse.myTest.PDM.diagram.part.MyPDMVisualIDRegistry
					.getVisualID(view));
		}
		return null;
	}

	/**
	 * @generated
	 */
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (org.eclipse.myTest.PDM.diagram.providers.MyPDMElementTypes
					.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	 * @generated
	 */
	private static class HintAdapter extends ParserHintAdapter {

		/**
		 * @generated
		 */
		private final IElementType elementType;

		/**
		 * @generated
		 */
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		 * @generated
		 */
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
