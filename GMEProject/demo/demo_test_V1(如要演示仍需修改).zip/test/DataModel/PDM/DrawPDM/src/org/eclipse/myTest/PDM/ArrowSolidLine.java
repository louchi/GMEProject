/**
 */
package org.eclipse.myTest.PDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arrow Solid Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.PDM.PDMPackage#getArrowSolidLine()
 * @model
 * @generated
 */
public interface ArrowSolidLine extends AbstractLine {
} // ArrowSolidLine
