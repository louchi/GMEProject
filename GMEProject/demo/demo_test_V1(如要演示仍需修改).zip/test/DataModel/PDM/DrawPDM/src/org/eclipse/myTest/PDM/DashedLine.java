/**
 */
package org.eclipse.myTest.PDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dashed Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.PDM.PDMPackage#getDashedLine()
 * @model
 * @generated
 */
public interface DashedLine extends AbstractLine {
} // DashedLine
