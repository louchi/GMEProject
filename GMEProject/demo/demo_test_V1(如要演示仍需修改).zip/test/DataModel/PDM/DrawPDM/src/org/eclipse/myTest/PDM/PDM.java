/**
 */
package org.eclipse.myTest.PDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PDM</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.PDM.PDMPackage#getPDM()
 * @model
 * @generated
 */
public interface PDM extends AbstractShapes {
} // PDM
