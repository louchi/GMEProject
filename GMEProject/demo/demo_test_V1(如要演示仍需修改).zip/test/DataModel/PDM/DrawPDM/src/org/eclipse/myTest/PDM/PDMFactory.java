/**
 */
package org.eclipse.myTest.PDM;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.myTest.PDM.PDMPackage
 * @generated
 */
public interface PDMFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PDMFactory eINSTANCE = org.eclipse.myTest.PDM.impl.PDMFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Base Panel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Base Panel</em>'.
	 * @generated
	 */
	BasePanel createBasePanel();

	/**
	 * Returns a new object of class '<em>Abstract Shapes</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Abstract Shapes</em>'.
	 * @generated
	 */
	AbstractShapes createAbstractShapes();

	/**
	 * Returns a new object of class '<em>Abstract Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Abstract Line</em>'.
	 * @generated
	 */
	AbstractLine createAbstractLine();

	/**
	 * Returns a new object of class '<em>PDM</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>PDM</em>'.
	 * @generated
	 */
	PDM createPDM();

	/**
	 * Returns a new object of class '<em>Platform View</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Platform View</em>'.
	 * @generated
	 */
	PlatformView createPlatformView();

	/**
	 * Returns a new object of class '<em>Platform Association</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Platform Association</em>'.
	 * @generated
	 */
	PlatformAssociation createPlatformAssociation();

	/**
	 * Returns a new object of class '<em>Platform Entity</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Platform Entity</em>'.
	 * @generated
	 */
	PlatformEntity createPlatformEntity();

	/**
	 * Returns a new object of class '<em>Solid Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Solid Line</em>'.
	 * @generated
	 */
	SolidLine createSolidLine();

	/**
	 * Returns a new object of class '<em>Dashed Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dashed Line</em>'.
	 * @generated
	 */
	DashedLine createDashedLine();

	/**
	 * Returns a new object of class '<em>Arrow Solid Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Arrow Solid Line</em>'.
	 * @generated
	 */
	ArrowSolidLine createArrowSolidLine();

	/**
	 * Returns a new object of class '<em>Arrow Dashed Line</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Arrow Dashed Line</em>'.
	 * @generated
	 */
	ArrowDashedLine createArrowDashedLine();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	PDMPackage getPDMPackage();

} //PDMFactory
