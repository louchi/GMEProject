/**
 */
package org.eclipse.myTest.PDM;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.myTest.PDM.PDMFactory
 * @model kind="package"
 * @generated
 */
public interface PDMPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "PDM";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "PDM.myTest.eclipse.org";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "org.eclipse.myTest";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PDMPackage eINSTANCE = org.eclipse.myTest.PDM.impl.PDMPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.BasePanelImpl <em>Base Panel</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.BasePanelImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getBasePanel()
	 * @generated
	 */
	int BASE_PANEL = 0;

	/**
	 * The feature id for the '<em><b>Have Shapes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL__HAVE_SHAPES = 0;

	/**
	 * The feature id for the '<em><b>Have Lines</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL__HAVE_LINES = 1;

	/**
	 * The number of structural features of the '<em>Base Panel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Base Panel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.AbstractShapesImpl <em>Abstract Shapes</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.AbstractShapesImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getAbstractShapes()
	 * @generated
	 */
	int ABSTRACT_SHAPES = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES__NAME = 0;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES__SOURCES = 1;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES__TARGETS = 2;
	
	/********************************�޸�*********************************/
	int ABSTRACT_SHAPES__VALUE =3;  // ������

	/**
	 * The number of structural features of the '<em>Abstract Shapes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES_FEATURE_COUNT = 4;  // ԭ����3
	
	/********************************�޸�*********************************/

	/**
	 * The number of operations of the '<em>Abstract Shapes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.AbstractLineImpl <em>Abstract Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.AbstractLineImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getAbstractLine()
	 * @generated
	 */
	int ABSTRACT_LINE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE__NAME = 0;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE__FROM = 1;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE__TO = 2;

	/**
	 * The number of structural features of the '<em>Abstract Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Abstract Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_LINE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.PDMImpl <em>PDM</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.PDMImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getPDM()
	 * @generated
	 */
	int PDM = 3;  

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PDM__NAME = ABSTRACT_SHAPES__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PDM__SOURCES = ABSTRACT_SHAPES__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PDM__TARGETS = ABSTRACT_SHAPES__TARGETS;
	
	/********************************�޸�*********************************/
	int PDM__VALUE = ABSTRACT_SHAPES__VALUE;
	/********************************�޸�*********************************/

	/**
	 * The number of structural features of the '<em>PDM</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PDM_FEATURE_COUNT = ABSTRACT_SHAPES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>PDM</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PDM_OPERATION_COUNT = ABSTRACT_SHAPES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.PlatformViewImpl <em>Platform View</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.PlatformViewImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getPlatformView()
	 * @generated
	 */
	int PLATFORM_VIEW = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_VIEW__NAME = ABSTRACT_SHAPES__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_VIEW__SOURCES = ABSTRACT_SHAPES__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_VIEW__TARGETS = ABSTRACT_SHAPES__TARGETS;
	
	/********************************�޸�*********************************/
	int PLATFORM_VIEW__VALUE = ABSTRACT_SHAPES__VALUE;
	/********************************�޸�*********************************/

	/**
	 * The number of structural features of the '<em>Platform View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_VIEW_FEATURE_COUNT = ABSTRACT_SHAPES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Platform View</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_VIEW_OPERATION_COUNT = ABSTRACT_SHAPES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.PlatformAssociationImpl <em>Platform Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.PlatformAssociationImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getPlatformAssociation()
	 * @generated
	 */
	int PLATFORM_ASSOCIATION = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ASSOCIATION__NAME = ABSTRACT_SHAPES__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ASSOCIATION__SOURCES = ABSTRACT_SHAPES__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ASSOCIATION__TARGETS = ABSTRACT_SHAPES__TARGETS;
	
	/********************************�޸�*********************************/
	int PLATFORM_ASSOCIATION__VALUE = ABSTRACT_SHAPES__VALUE;
	/********************************�޸�*********************************/

	/**
	 * The number of structural features of the '<em>Platform Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ASSOCIATION_FEATURE_COUNT = ABSTRACT_SHAPES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Platform Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ASSOCIATION_OPERATION_COUNT = ABSTRACT_SHAPES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.PlatformEntityImpl <em>Platform Entity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.PlatformEntityImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getPlatformEntity()
	 * @generated
	 */
	int PLATFORM_ENTITY = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ENTITY__NAME = ABSTRACT_SHAPES__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ENTITY__SOURCES = ABSTRACT_SHAPES__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ENTITY__TARGETS = ABSTRACT_SHAPES__TARGETS;
	/********************************�޸�*********************************/
	int PLATFORM_ENTITY__VALUE = ABSTRACT_SHAPES__VALUE;
	/********************************�޸�*********************************/

	/**
	 * The number of structural features of the '<em>Platform Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ENTITY_FEATURE_COUNT = ABSTRACT_SHAPES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Platform Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLATFORM_ENTITY_OPERATION_COUNT = ABSTRACT_SHAPES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.SolidLineImpl <em>Solid Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.SolidLineImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getSolidLine()
	 * @generated
	 */
	int SOLID_LINE = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE__NAME = ABSTRACT_LINE__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE__FROM = ABSTRACT_LINE__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE__TO = ABSTRACT_LINE__TO;
	
	

	/**
	 * The number of structural features of the '<em>Solid Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE_FEATURE_COUNT = ABSTRACT_LINE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Solid Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOLID_LINE_OPERATION_COUNT = ABSTRACT_LINE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.DashedLineImpl <em>Dashed Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.DashedLineImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getDashedLine()
	 * @generated
	 */
	int DASHED_LINE = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE__NAME = ABSTRACT_LINE__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE__FROM = ABSTRACT_LINE__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE__TO = ABSTRACT_LINE__TO;

	/**
	 * The number of structural features of the '<em>Dashed Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE_FEATURE_COUNT = ABSTRACT_LINE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Dashed Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DASHED_LINE_OPERATION_COUNT = ABSTRACT_LINE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.ArrowSolidLineImpl <em>Arrow Solid Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.ArrowSolidLineImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getArrowSolidLine()
	 * @generated
	 */
	int ARROW_SOLID_LINE = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE__NAME = ABSTRACT_LINE__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE__FROM = ABSTRACT_LINE__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE__TO = ABSTRACT_LINE__TO;

	/**
	 * The number of structural features of the '<em>Arrow Solid Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE_FEATURE_COUNT = ABSTRACT_LINE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Arrow Solid Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_SOLID_LINE_OPERATION_COUNT = ABSTRACT_LINE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.PDM.impl.ArrowDashedLineImpl <em>Arrow Dashed Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.PDM.impl.ArrowDashedLineImpl
	 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getArrowDashedLine()
	 * @generated
	 */
	int ARROW_DASHED_LINE = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE__NAME = ABSTRACT_LINE__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE__FROM = ABSTRACT_LINE__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE__TO = ABSTRACT_LINE__TO;

	/**
	 * The number of structural features of the '<em>Arrow Dashed Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE_FEATURE_COUNT = ABSTRACT_LINE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Arrow Dashed Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ARROW_DASHED_LINE_OPERATION_COUNT = ABSTRACT_LINE_OPERATION_COUNT + 0;


	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.BasePanel <em>Base Panel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Base Panel</em>'.
	 * @see org.eclipse.myTest.PDM.BasePanel
	 * @generated
	 */
	EClass getBasePanel();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.myTest.PDM.BasePanel#getHaveShapes <em>Have Shapes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Have Shapes</em>'.
	 * @see org.eclipse.myTest.PDM.BasePanel#getHaveShapes()
	 * @see #getBasePanel()
	 * @generated
	 */
	EReference getBasePanel_HaveShapes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.myTest.PDM.BasePanel#getHaveLines <em>Have Lines</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Have Lines</em>'.
	 * @see org.eclipse.myTest.PDM.BasePanel#getHaveLines()
	 * @see #getBasePanel()
	 * @generated
	 */
	EReference getBasePanel_HaveLines();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.AbstractShapes <em>Abstract Shapes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Shapes</em>'.
	 * @see org.eclipse.myTest.PDM.AbstractShapes
	 * @generated
	 */
	EClass getAbstractShapes();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.myTest.PDM.AbstractShapes#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.myTest.PDM.AbstractShapes#getName()
	 * @see #getAbstractShapes()
	 * @generated
	 */
	EAttribute getAbstractShapes_Name();
	
	/***********************�޸�***********************/
	EAttribute getAbstractShapes_Value();
	/************************�޸�**********************/

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.myTest.PDM.AbstractShapes#getSources <em>Sources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sources</em>'.
	 * @see org.eclipse.myTest.PDM.AbstractShapes#getSources()
	 * @see #getAbstractShapes()
	 * @generated
	 */
	EReference getAbstractShapes_Sources();

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.myTest.PDM.AbstractShapes#getTargets <em>Targets</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Targets</em>'.
	 * @see org.eclipse.myTest.PDM.AbstractShapes#getTargets()
	 * @see #getAbstractShapes()
	 * @generated
	 */
	EReference getAbstractShapes_Targets();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.AbstractLine <em>Abstract Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Line</em>'.
	 * @see org.eclipse.myTest.PDM.AbstractLine
	 * @generated
	 */
	EClass getAbstractLine();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.myTest.PDM.AbstractLine#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.myTest.PDM.AbstractLine#getName()
	 * @see #getAbstractLine()
	 * @generated
	 */
	EAttribute getAbstractLine_Name();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.myTest.PDM.AbstractLine#getFrom <em>From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>From</em>'.
	 * @see org.eclipse.myTest.PDM.AbstractLine#getFrom()
	 * @see #getAbstractLine()
	 * @generated
	 */
	EReference getAbstractLine_From();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.myTest.PDM.AbstractLine#getTo <em>To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>To</em>'.
	 * @see org.eclipse.myTest.PDM.AbstractLine#getTo()
	 * @see #getAbstractLine()
	 * @generated
	 */
	EReference getAbstractLine_To();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.PDM <em>PDM</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>PDM</em>'.
	 * @see org.eclipse.myTest.PDM.PDM
	 * @generated
	 */
	EClass getPDM();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.PlatformView <em>Platform View</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Platform View</em>'.
	 * @see org.eclipse.myTest.PDM.PlatformView
	 * @generated
	 */
	EClass getPlatformView();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.PlatformAssociation <em>Platform Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Platform Association</em>'.
	 * @see org.eclipse.myTest.PDM.PlatformAssociation
	 * @generated
	 */
	EClass getPlatformAssociation();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.PlatformEntity <em>Platform Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Platform Entity</em>'.
	 * @see org.eclipse.myTest.PDM.PlatformEntity
	 * @generated
	 */
	EClass getPlatformEntity();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.SolidLine <em>Solid Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Solid Line</em>'.
	 * @see org.eclipse.myTest.PDM.SolidLine
	 * @generated
	 */
	EClass getSolidLine();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.DashedLine <em>Dashed Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dashed Line</em>'.
	 * @see org.eclipse.myTest.PDM.DashedLine
	 * @generated
	 */
	EClass getDashedLine();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.ArrowSolidLine <em>Arrow Solid Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Arrow Solid Line</em>'.
	 * @see org.eclipse.myTest.PDM.ArrowSolidLine
	 * @generated
	 */
	EClass getArrowSolidLine();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.PDM.ArrowDashedLine <em>Arrow Dashed Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Arrow Dashed Line</em>'.
	 * @see org.eclipse.myTest.PDM.ArrowDashedLine
	 * @generated
	 */
	EClass getArrowDashedLine();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PDMFactory getPDMFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.BasePanelImpl <em>Base Panel</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.BasePanelImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getBasePanel()
		 * @generated
		 */
		EClass BASE_PANEL = eINSTANCE.getBasePanel();

		/**
		 * The meta object literal for the '<em><b>Have Shapes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASE_PANEL__HAVE_SHAPES = eINSTANCE.getBasePanel_HaveShapes();

		/**
		 * The meta object literal for the '<em><b>Have Lines</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASE_PANEL__HAVE_LINES = eINSTANCE.getBasePanel_HaveLines();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.AbstractShapesImpl <em>Abstract Shapes</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.AbstractShapesImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getAbstractShapes()
		 * @generated
		 */
		EClass ABSTRACT_SHAPES = eINSTANCE.getAbstractShapes();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_SHAPES__NAME = eINSTANCE.getAbstractShapes_Name();
		
		/********************************�޸�*********************************/
		EAttribute ABSTRACT_SHAPES__VALUE = eINSTANCE.getAbstractShapes_Value();
		/********************************�޸�*********************************/

		/**
		 * The meta object literal for the '<em><b>Sources</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_SHAPES__SOURCES = eINSTANCE.getAbstractShapes_Sources();

		/**
		 * The meta object literal for the '<em><b>Targets</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_SHAPES__TARGETS = eINSTANCE.getAbstractShapes_Targets();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.AbstractLineImpl <em>Abstract Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.AbstractLineImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getAbstractLine()
		 * @generated
		 */
		EClass ABSTRACT_LINE = eINSTANCE.getAbstractLine();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_LINE__NAME = eINSTANCE.getAbstractLine_Name();

		/**
		 * The meta object literal for the '<em><b>From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_LINE__FROM = eINSTANCE.getAbstractLine_From();

		/**
		 * The meta object literal for the '<em><b>To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_LINE__TO = eINSTANCE.getAbstractLine_To();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.PDMImpl <em>PDM</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.PDMImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getPDM()
		 * @generated
		 */
		EClass PDM = eINSTANCE.getPDM();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.PlatformViewImpl <em>Platform View</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.PlatformViewImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getPlatformView()
		 * @generated
		 */
		EClass PLATFORM_VIEW = eINSTANCE.getPlatformView();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.PlatformAssociationImpl <em>Platform Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.PlatformAssociationImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getPlatformAssociation()
		 * @generated
		 */
		EClass PLATFORM_ASSOCIATION = eINSTANCE.getPlatformAssociation();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.PlatformEntityImpl <em>Platform Entity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.PlatformEntityImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getPlatformEntity()
		 * @generated
		 */
		EClass PLATFORM_ENTITY = eINSTANCE.getPlatformEntity();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.SolidLineImpl <em>Solid Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.SolidLineImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getSolidLine()
		 * @generated
		 */
		EClass SOLID_LINE = eINSTANCE.getSolidLine();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.DashedLineImpl <em>Dashed Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.DashedLineImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getDashedLine()
		 * @generated
		 */
		EClass DASHED_LINE = eINSTANCE.getDashedLine();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.ArrowSolidLineImpl <em>Arrow Solid Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.ArrowSolidLineImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getArrowSolidLine()
		 * @generated
		 */
		EClass ARROW_SOLID_LINE = eINSTANCE.getArrowSolidLine();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.PDM.impl.ArrowDashedLineImpl <em>Arrow Dashed Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.PDM.impl.ArrowDashedLineImpl
		 * @see org.eclipse.myTest.PDM.impl.PDMPackageImpl#getArrowDashedLine()
		 * @generated
		 */
		EClass ARROW_DASHED_LINE = eINSTANCE.getArrowDashedLine();

	}

} //PDMPackage
