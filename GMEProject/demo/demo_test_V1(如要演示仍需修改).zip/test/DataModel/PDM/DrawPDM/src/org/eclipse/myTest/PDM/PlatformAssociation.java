/**
 */
package org.eclipse.myTest.PDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Platform Association</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.PDM.PDMPackage#getPlatformAssociation()
 * @model
 * @generated
 */
public interface PlatformAssociation extends AbstractShapes {
} // PlatformAssociation
