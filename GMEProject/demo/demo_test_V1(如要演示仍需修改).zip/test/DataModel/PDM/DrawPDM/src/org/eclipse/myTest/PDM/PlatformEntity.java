/**
 */
package org.eclipse.myTest.PDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Platform Entity</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.PDM.PDMPackage#getPlatformEntity()
 * @model
 * @generated
 */
public interface PlatformEntity extends AbstractShapes {
} // PlatformEntity
