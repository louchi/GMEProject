/**
 */
package org.eclipse.myTest.PDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Platform View</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.PDM.PDMPackage#getPlatformView()
 * @model
 * @generated
 */
public interface PlatformView extends AbstractShapes {
} // PlatformView
