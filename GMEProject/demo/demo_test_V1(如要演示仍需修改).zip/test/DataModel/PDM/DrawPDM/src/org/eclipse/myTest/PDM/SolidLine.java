/**
 */
package org.eclipse.myTest.PDM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Solid Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.PDM.PDMPackage#getSolidLine()
 * @model
 * @generated
 */
public interface SolidLine extends AbstractLine {
} // SolidLine
