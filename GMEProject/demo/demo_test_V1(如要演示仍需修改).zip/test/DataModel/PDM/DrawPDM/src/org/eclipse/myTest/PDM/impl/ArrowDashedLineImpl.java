/**
 */
package org.eclipse.myTest.PDM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.PDM.ArrowDashedLine;
import org.eclipse.myTest.PDM.PDMPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arrow Dashed Line</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ArrowDashedLineImpl extends AbstractLineImpl implements ArrowDashedLine {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArrowDashedLineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PDMPackage.Literals.ARROW_DASHED_LINE;
	}

} //ArrowDashedLineImpl
