/**
 */
package org.eclipse.myTest.PDM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.PDM.ArrowSolidLine;
import org.eclipse.myTest.PDM.PDMPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arrow Solid Line</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ArrowSolidLineImpl extends AbstractLineImpl implements ArrowSolidLine {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArrowSolidLineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PDMPackage.Literals.ARROW_SOLID_LINE;
	}

} //ArrowSolidLineImpl
