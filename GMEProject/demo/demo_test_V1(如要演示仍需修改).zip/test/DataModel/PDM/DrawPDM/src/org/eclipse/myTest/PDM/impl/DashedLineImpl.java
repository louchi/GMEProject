/**
 */
package org.eclipse.myTest.PDM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.PDM.DashedLine;
import org.eclipse.myTest.PDM.PDMPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dashed Line</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class DashedLineImpl extends AbstractLineImpl implements DashedLine {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DashedLineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PDMPackage.Literals.DASHED_LINE;
	}

} //DashedLineImpl
