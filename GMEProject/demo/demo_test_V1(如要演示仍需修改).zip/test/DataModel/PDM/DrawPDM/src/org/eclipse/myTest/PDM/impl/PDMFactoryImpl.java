/**
 */
package org.eclipse.myTest.PDM.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.myTest.PDM.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PDMFactoryImpl extends EFactoryImpl implements PDMFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PDMFactory init() {
		try {
			PDMFactory thePDMFactory = (PDMFactory)EPackage.Registry.INSTANCE.getEFactory(PDMPackage.eNS_URI);
			if (thePDMFactory != null) {
				return thePDMFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new PDMFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PDMFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case PDMPackage.BASE_PANEL: return createBasePanel();
			case PDMPackage.ABSTRACT_SHAPES: return createAbstractShapes();
			case PDMPackage.ABSTRACT_LINE: return createAbstractLine();
			case PDMPackage.PDM: return createPDM();
			case PDMPackage.PLATFORM_VIEW: return createPlatformView();
			case PDMPackage.PLATFORM_ASSOCIATION: return createPlatformAssociation();
			case PDMPackage.PLATFORM_ENTITY: return createPlatformEntity();
			case PDMPackage.SOLID_LINE: return createSolidLine();
			case PDMPackage.DASHED_LINE: return createDashedLine();
			case PDMPackage.ARROW_SOLID_LINE: return createArrowSolidLine();
			case PDMPackage.ARROW_DASHED_LINE: return createArrowDashedLine();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BasePanel createBasePanel() {
		BasePanelImpl basePanel = new BasePanelImpl();
		return basePanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractShapes createAbstractShapes() {
		AbstractShapesImpl abstractShapes = new AbstractShapesImpl();
		return abstractShapes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractLine createAbstractLine() {
		AbstractLineImpl abstractLine = new AbstractLineImpl();
		return abstractLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PDM createPDM() {
		PDMImpl pdm = new PDMImpl();
		return pdm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlatformView createPlatformView() {
		PlatformViewImpl platformView = new PlatformViewImpl();
		return platformView;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlatformAssociation createPlatformAssociation() {
		PlatformAssociationImpl platformAssociation = new PlatformAssociationImpl();
		return platformAssociation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlatformEntity createPlatformEntity() {
		PlatformEntityImpl platformEntity = new PlatformEntityImpl();
		return platformEntity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SolidLine createSolidLine() {
		SolidLineImpl solidLine = new SolidLineImpl();
		return solidLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DashedLine createDashedLine() {
		DashedLineImpl dashedLine = new DashedLineImpl();
		return dashedLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ArrowSolidLine createArrowSolidLine() {
		ArrowSolidLineImpl arrowSolidLine = new ArrowSolidLineImpl();
		return arrowSolidLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ArrowDashedLine createArrowDashedLine() {
		ArrowDashedLineImpl arrowDashedLine = new ArrowDashedLineImpl();
		return arrowDashedLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PDMPackage getPDMPackage() {
		return (PDMPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static PDMPackage getPackage() {
		return PDMPackage.eINSTANCE;
	}

} //PDMFactoryImpl
