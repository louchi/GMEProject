/**
 */
package org.eclipse.myTest.PDM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.PDM.PDM;
import org.eclipse.myTest.PDM.PDMPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PDM</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class PDMImpl extends AbstractShapesImpl implements PDM {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PDMImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PDMPackage.Literals.PDM;
	}

} //PDMImpl
