/**
 */
package org.eclipse.myTest.PDM.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.myTest.PDM.AbstractLine;
import org.eclipse.myTest.PDM.AbstractShapes;
import org.eclipse.myTest.PDM.ArrowDashedLine;
import org.eclipse.myTest.PDM.ArrowSolidLine;
import org.eclipse.myTest.PDM.BasePanel;
import org.eclipse.myTest.PDM.DashedLine;
import org.eclipse.myTest.PDM.PDMFactory;
import org.eclipse.myTest.PDM.PDMPackage;
import org.eclipse.myTest.PDM.PlatformAssociation;
import org.eclipse.myTest.PDM.PlatformEntity;
import org.eclipse.myTest.PDM.PlatformView;
import org.eclipse.myTest.PDM.SolidLine;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PDMPackageImpl extends EPackageImpl implements PDMPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass basePanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractShapesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pdmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass platformViewEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass platformAssociationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass platformEntityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass solidLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dashedLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass arrowSolidLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass arrowDashedLineEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eclipse.myTest.PDM.PDMPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private PDMPackageImpl() {
		super(eNS_URI, PDMFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link PDMPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static PDMPackage init() {
		if (isInited) return (PDMPackage)EPackage.Registry.INSTANCE.getEPackage(PDMPackage.eNS_URI);

		// Obtain or create and register package
		PDMPackageImpl thePDMPackage = (PDMPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof PDMPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new PDMPackageImpl());

		isInited = true;

		// Create package meta-data objects
		thePDMPackage.createPackageContents();

		// Initialize created meta-data
		thePDMPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		thePDMPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(PDMPackage.eNS_URI, thePDMPackage);
		return thePDMPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBasePanel() {
		return basePanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBasePanel_HaveShapes() {
		return (EReference)basePanelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBasePanel_HaveLines() {
		return (EReference)basePanelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractShapes() {
		return abstractShapesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractShapes_Name() {
		return (EAttribute)abstractShapesEClass.getEStructuralFeatures().get(0);
	}
	
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractShapes_Sources() {
		return (EReference)abstractShapesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractShapes_Targets() {
		return (EReference)abstractShapesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractLine() {
		return abstractLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractLine_Name() {
		return (EAttribute)abstractLineEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractLine_From() {
		return (EReference)abstractLineEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractLine_To() {
		return (EReference)abstractLineEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPDM() {
		return pdmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlatformView() {
		return platformViewEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlatformAssociation() {
		return platformAssociationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlatformEntity() {
		return platformEntityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSolidLine() {
		return solidLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDashedLine() {
		return dashedLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getArrowSolidLine() {
		return arrowSolidLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getArrowDashedLine() {
		return arrowDashedLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PDMFactory getPDMFactory() {
		return (PDMFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		basePanelEClass = createEClass(BASE_PANEL);
		createEReference(basePanelEClass, BASE_PANEL__HAVE_SHAPES);
		createEReference(basePanelEClass, BASE_PANEL__HAVE_LINES);

		abstractShapesEClass = createEClass(ABSTRACT_SHAPES);
		createEAttribute(abstractShapesEClass, ABSTRACT_SHAPES__NAME);
		createEReference(abstractShapesEClass, ABSTRACT_SHAPES__SOURCES);
		createEReference(abstractShapesEClass, ABSTRACT_SHAPES__TARGETS);
		/***************************/
		createEAttribute(abstractShapesEClass, ABSTRACT_SHAPES__VALUE);
		/**************************/

		abstractLineEClass = createEClass(ABSTRACT_LINE);
		createEAttribute(abstractLineEClass, ABSTRACT_LINE__NAME);
		createEReference(abstractLineEClass, ABSTRACT_LINE__FROM);
		createEReference(abstractLineEClass, ABSTRACT_LINE__TO);

		pdmEClass = createEClass(PDM);

		platformViewEClass = createEClass(PLATFORM_VIEW);

		platformAssociationEClass = createEClass(PLATFORM_ASSOCIATION);

		platformEntityEClass = createEClass(PLATFORM_ENTITY);

		solidLineEClass = createEClass(SOLID_LINE);

		dashedLineEClass = createEClass(DASHED_LINE);

		arrowSolidLineEClass = createEClass(ARROW_SOLID_LINE);

		arrowDashedLineEClass = createEClass(ARROW_DASHED_LINE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		pdmEClass.getESuperTypes().add(this.getAbstractShapes());
		platformViewEClass.getESuperTypes().add(this.getAbstractShapes());
		platformAssociationEClass.getESuperTypes().add(this.getAbstractShapes());
		platformEntityEClass.getESuperTypes().add(this.getAbstractShapes());
		solidLineEClass.getESuperTypes().add(this.getAbstractLine());
		dashedLineEClass.getESuperTypes().add(this.getAbstractLine());
		arrowSolidLineEClass.getESuperTypes().add(this.getAbstractLine());
		arrowDashedLineEClass.getESuperTypes().add(this.getAbstractLine());

		// Initialize classes, features, and operations; add parameters
		initEClass(basePanelEClass, BasePanel.class, "BasePanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBasePanel_HaveShapes(), this.getAbstractShapes(), null, "haveShapes", null, 0, -1, BasePanel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBasePanel_HaveLines(), this.getAbstractLine(), null, "haveLines", null, 0, -1, BasePanel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractShapesEClass, AbstractShapes.class, "AbstractShapes", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractShapes_Name(), ecorePackage.getEString(), "name", null, 0, 1, AbstractShapes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractShapes_Sources(), this.getAbstractLine(), null, "sources", null, 0, -1, AbstractShapes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractShapes_Targets(), this.getAbstractLine(), null, "targets", null, 0, -1, AbstractShapes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		/*************************/
		initEAttribute(getAbstractShapes_Value(), ecorePackage.getEString(), "value", null, 0, 1, AbstractShapes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		/**************************/
		
		initEClass(abstractLineEClass, AbstractLine.class, "AbstractLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractLine_Name(), ecorePackage.getEString(), "name", null, 0, 1, AbstractLine.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractLine_From(), this.getAbstractShapes(), null, "from", null, 0, 1, AbstractLine.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractLine_To(), this.getAbstractShapes(), null, "to", null, 0, 1, AbstractLine.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(pdmEClass, org.eclipse.myTest.PDM.PDM.class, "PDM", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(platformViewEClass, PlatformView.class, "PlatformView", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(platformAssociationEClass, PlatformAssociation.class, "PlatformAssociation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(platformEntityEClass, PlatformEntity.class, "PlatformEntity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(solidLineEClass, SolidLine.class, "SolidLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(dashedLineEClass, DashedLine.class, "DashedLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(arrowSolidLineEClass, ArrowSolidLine.class, "ArrowSolidLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(arrowDashedLineEClass, ArrowDashedLine.class, "ArrowDashedLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}
	/**********************************************/
	@Override
	public EAttribute getAbstractShapes_Value() {
		// TODO Auto-generated method stub
		return (EAttribute)abstractShapesEClass.getEStructuralFeatures().get(3);
	}
	/************************************************/

} //PDMPackageImpl
