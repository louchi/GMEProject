/**
 */
package org.eclipse.myTest.PDM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.PDM.PDMPackage;
import org.eclipse.myTest.PDM.PlatformAssociation;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Platform Association</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class PlatformAssociationImpl extends AbstractShapesImpl implements PlatformAssociation {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlatformAssociationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PDMPackage.Literals.PLATFORM_ASSOCIATION;
	}

} //PlatformAssociationImpl
