/**
 */
package org.eclipse.myTest.PDM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.PDM.PDMPackage;
import org.eclipse.myTest.PDM.PlatformEntity;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Platform Entity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class PlatformEntityImpl extends AbstractShapesImpl implements PlatformEntity {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlatformEntityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PDMPackage.Literals.PLATFORM_ENTITY;
	}

} //PlatformEntityImpl
