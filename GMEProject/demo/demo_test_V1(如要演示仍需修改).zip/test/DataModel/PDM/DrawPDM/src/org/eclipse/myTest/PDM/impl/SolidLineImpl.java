/**
 */
package org.eclipse.myTest.PDM.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.PDM.PDMPackage;
import org.eclipse.myTest.PDM.SolidLine;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Solid Line</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class SolidLineImpl extends AbstractLineImpl implements SolidLine {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SolidLineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PDMPackage.Literals.SOLID_LINE;
	}

} //SolidLineImpl
