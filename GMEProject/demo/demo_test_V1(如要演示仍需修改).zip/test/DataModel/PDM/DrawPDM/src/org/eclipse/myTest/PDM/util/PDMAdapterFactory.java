/**
 */
package org.eclipse.myTest.PDM.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import org.eclipse.myTest.PDM.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.myTest.PDM.PDMPackage
 * @generated
 */
public class PDMAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static PDMPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PDMAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = PDMPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PDMSwitch<Adapter> modelSwitch =
		new PDMSwitch<Adapter>() {
			@Override
			public Adapter caseBasePanel(BasePanel object) {
				return createBasePanelAdapter();
			}
			@Override
			public Adapter caseAbstractShapes(AbstractShapes object) {
				return createAbstractShapesAdapter();
			}
			@Override
			public Adapter caseAbstractLine(AbstractLine object) {
				return createAbstractLineAdapter();
			}
			@Override
			public Adapter casePDM(PDM object) {
				return createPDMAdapter();
			}
			@Override
			public Adapter casePlatformView(PlatformView object) {
				return createPlatformViewAdapter();
			}
			@Override
			public Adapter casePlatformAssociation(PlatformAssociation object) {
				return createPlatformAssociationAdapter();
			}
			@Override
			public Adapter casePlatformEntity(PlatformEntity object) {
				return createPlatformEntityAdapter();
			}
			@Override
			public Adapter caseSolidLine(SolidLine object) {
				return createSolidLineAdapter();
			}
			@Override
			public Adapter caseDashedLine(DashedLine object) {
				return createDashedLineAdapter();
			}
			@Override
			public Adapter caseArrowSolidLine(ArrowSolidLine object) {
				return createArrowSolidLineAdapter();
			}
			@Override
			public Adapter caseArrowDashedLine(ArrowDashedLine object) {
				return createArrowDashedLineAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.BasePanel <em>Base Panel</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.BasePanel
	 * @generated
	 */
	public Adapter createBasePanelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.AbstractShapes <em>Abstract Shapes</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.AbstractShapes
	 * @generated
	 */
	public Adapter createAbstractShapesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.AbstractLine <em>Abstract Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.AbstractLine
	 * @generated
	 */
	public Adapter createAbstractLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.PDM <em>PDM</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.PDM
	 * @generated
	 */
	public Adapter createPDMAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.PlatformView <em>Platform View</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.PlatformView
	 * @generated
	 */
	public Adapter createPlatformViewAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.PlatformAssociation <em>Platform Association</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.PlatformAssociation
	 * @generated
	 */
	public Adapter createPlatformAssociationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.PlatformEntity <em>Platform Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.PlatformEntity
	 * @generated
	 */
	public Adapter createPlatformEntityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.SolidLine <em>Solid Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.SolidLine
	 * @generated
	 */
	public Adapter createSolidLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.DashedLine <em>Dashed Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.DashedLine
	 * @generated
	 */
	public Adapter createDashedLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.ArrowSolidLine <em>Arrow Solid Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.ArrowSolidLine
	 * @generated
	 */
	public Adapter createArrowSolidLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.eclipse.myTest.PDM.ArrowDashedLine <em>Arrow Dashed Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.eclipse.myTest.PDM.ArrowDashedLine
	 * @generated
	 */
	public Adapter createArrowDashedLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //PDMAdapterFactory
