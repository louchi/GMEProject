/**
 */
package org.eclipse.myTest.PDM.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import org.eclipse.myTest.PDM.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see org.eclipse.myTest.PDM.PDMPackage
 * @generated
 */
public class PDMSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static PDMPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PDMSwitch() {
		if (modelPackage == null) {
			modelPackage = PDMPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @parameter ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case PDMPackage.BASE_PANEL: {
				BasePanel basePanel = (BasePanel)theEObject;
				T result = caseBasePanel(basePanel);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.ABSTRACT_SHAPES: {
				AbstractShapes abstractShapes = (AbstractShapes)theEObject;
				T result = caseAbstractShapes(abstractShapes);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.ABSTRACT_LINE: {
				AbstractLine abstractLine = (AbstractLine)theEObject;
				T result = caseAbstractLine(abstractLine);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.PDM: {
				PDM pdm = (PDM)theEObject;
				T result = casePDM(pdm);
				if (result == null) result = caseAbstractShapes(pdm);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.PLATFORM_VIEW: {
				PlatformView platformView = (PlatformView)theEObject;
				T result = casePlatformView(platformView);
				if (result == null) result = caseAbstractShapes(platformView);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.PLATFORM_ASSOCIATION: {
				PlatformAssociation platformAssociation = (PlatformAssociation)theEObject;
				T result = casePlatformAssociation(platformAssociation);
				if (result == null) result = caseAbstractShapes(platformAssociation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.PLATFORM_ENTITY: {
				PlatformEntity platformEntity = (PlatformEntity)theEObject;
				T result = casePlatformEntity(platformEntity);
				if (result == null) result = caseAbstractShapes(platformEntity);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.SOLID_LINE: {
				SolidLine solidLine = (SolidLine)theEObject;
				T result = caseSolidLine(solidLine);
				if (result == null) result = caseAbstractLine(solidLine);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.DASHED_LINE: {
				DashedLine dashedLine = (DashedLine)theEObject;
				T result = caseDashedLine(dashedLine);
				if (result == null) result = caseAbstractLine(dashedLine);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.ARROW_SOLID_LINE: {
				ArrowSolidLine arrowSolidLine = (ArrowSolidLine)theEObject;
				T result = caseArrowSolidLine(arrowSolidLine);
				if (result == null) result = caseAbstractLine(arrowSolidLine);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PDMPackage.ARROW_DASHED_LINE: {
				ArrowDashedLine arrowDashedLine = (ArrowDashedLine)theEObject;
				T result = caseArrowDashedLine(arrowDashedLine);
				if (result == null) result = caseAbstractLine(arrowDashedLine);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Base Panel</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Base Panel</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBasePanel(BasePanel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Abstract Shapes</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Abstract Shapes</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAbstractShapes(AbstractShapes object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Abstract Line</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Abstract Line</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAbstractLine(AbstractLine object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>PDM</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>PDM</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePDM(PDM object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Platform View</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Platform View</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlatformView(PlatformView object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Platform Association</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Platform Association</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlatformAssociation(PlatformAssociation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Platform Entity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Platform Entity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlatformEntity(PlatformEntity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Solid Line</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Solid Line</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSolidLine(SolidLine object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Dashed Line</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Dashed Line</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDashedLine(DashedLine object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Arrow Solid Line</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Arrow Solid Line</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseArrowSolidLine(ArrowSolidLine object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Arrow Dashed Line</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Arrow Dashed Line</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseArrowDashedLine(ArrowDashedLine object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //PDMSwitch
