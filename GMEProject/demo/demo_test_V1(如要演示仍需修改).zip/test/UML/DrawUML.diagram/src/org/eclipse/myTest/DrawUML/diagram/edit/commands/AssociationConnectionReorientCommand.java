package org.eclipse.myTest.DrawUML.diagram.edit.commands;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.command.CommandResult;
import org.eclipse.gmf.runtime.emf.type.core.commands.EditElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.ReorientRelationshipRequest;

/**
 * @generated
 */
public class AssociationConnectionReorientCommand extends EditElementCommand {

	/**
	 * @generated
	 */
	private final int reorientDirection;

	/**
	 * @generated
	 */
	private final EObject oldEnd;

	/**
	 * @generated
	 */
	private final EObject newEnd;

	/**
	 * @generated
	 */
	public AssociationConnectionReorientCommand(
			ReorientRelationshipRequest request) {
		super(request.getLabel(), request.getRelationship(), request);
		reorientDirection = request.getDirection();
		oldEnd = request.getOldRelationshipEnd();
		newEnd = request.getNewRelationshipEnd();
	}

	/**
	 * @generated
	 */
	public boolean canExecute() {
		if (false == getElementToEdit() instanceof org.eclipse.myTest.DrawUML.AssociationConnection) {
			return false;
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return canReorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return canReorientTarget();
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected boolean canReorientSource() {
		if (!(oldEnd instanceof org.eclipse.myTest.DrawUML.AbstractShape && newEnd instanceof org.eclipse.myTest.DrawUML.AbstractShape)) {
			return false;
		}
		org.eclipse.myTest.DrawUML.AbstractShape target = getLink().getTo();
		if (!(getLink().eContainer() instanceof org.eclipse.myTest.DrawUML.BasePanel)) {
			return false;
		}
		org.eclipse.myTest.DrawUML.BasePanel container = (org.eclipse.myTest.DrawUML.BasePanel) getLink()
				.eContainer();
		return org.eclipse.myTest.DrawUML.diagram.edit.policies.MyUMLBaseItemSemanticEditPolicy
				.getLinkConstraints().canExistAssociationConnection_4003(
						container, getLink(), getNewSource(), target);
	}

	/**
	 * @generated
	 */
	protected boolean canReorientTarget() {
		if (!(oldEnd instanceof org.eclipse.myTest.DrawUML.AbstractShape && newEnd instanceof org.eclipse.myTest.DrawUML.AbstractShape)) {
			return false;
		}
		org.eclipse.myTest.DrawUML.AbstractShape source = getLink().getFrom();
		if (!(getLink().eContainer() instanceof org.eclipse.myTest.DrawUML.BasePanel)) {
			return false;
		}
		org.eclipse.myTest.DrawUML.BasePanel container = (org.eclipse.myTest.DrawUML.BasePanel) getLink()
				.eContainer();
		return org.eclipse.myTest.DrawUML.diagram.edit.policies.MyUMLBaseItemSemanticEditPolicy
				.getLinkConstraints().canExistAssociationConnection_4003(
						container, getLink(), source, getNewTarget());
	}

	/**
	 * @generated
	 */
	protected CommandResult doExecuteWithResult(IProgressMonitor monitor,
			IAdaptable info) throws ExecutionException {
		if (!canExecute()) {
			throw new ExecutionException(
					"Invalid arguments in reorient link command"); //$NON-NLS-1$
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return reorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return reorientTarget();
		}
		throw new IllegalStateException();
	}

	/**
	 * @generated
	 */
	protected CommandResult reorientSource() throws ExecutionException {
		getLink().setFrom(getNewSource());
		return CommandResult.newOKCommandResult(getLink());
	}

	/**
	 * @generated
	 */
	protected CommandResult reorientTarget() throws ExecutionException {
		getLink().setTo(getNewTarget());
		return CommandResult.newOKCommandResult(getLink());
	}

	/**
	 * @generated
	 */
	protected org.eclipse.myTest.DrawUML.AssociationConnection getLink() {
		return (org.eclipse.myTest.DrawUML.AssociationConnection) getElementToEdit();
	}

	/**
	 * @generated
	 */
	protected org.eclipse.myTest.DrawUML.AbstractShape getOldSource() {
		return (org.eclipse.myTest.DrawUML.AbstractShape) oldEnd;
	}

	/**
	 * @generated
	 */
	protected org.eclipse.myTest.DrawUML.AbstractShape getNewSource() {
		return (org.eclipse.myTest.DrawUML.AbstractShape) newEnd;
	}

	/**
	 * @generated
	 */
	protected org.eclipse.myTest.DrawUML.AbstractShape getOldTarget() {
		return (org.eclipse.myTest.DrawUML.AbstractShape) oldEnd;
	}

	/**
	 * @generated
	 */
	protected org.eclipse.myTest.DrawUML.AbstractShape getNewTarget() {
		return (org.eclipse.myTest.DrawUML.AbstractShape) newEnd;
	}
}
