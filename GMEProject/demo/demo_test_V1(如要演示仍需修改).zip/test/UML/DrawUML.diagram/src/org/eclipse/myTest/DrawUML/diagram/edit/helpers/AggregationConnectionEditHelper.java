package org.eclipse.myTest.DrawUML.diagram.edit.helpers;

/**
 * @generated
 */
public class AggregationConnectionEditHelper extends
		org.eclipse.myTest.DrawUML.diagram.edit.helpers.MyUMLBaseEditHelper {
}
