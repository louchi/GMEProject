package org.eclipse.myTest.DrawUML.diagram.edit.helpers;

/**
 * @generated
 */
public class AssociationConnectionEditHelper extends
		org.eclipse.myTest.DrawUML.diagram.edit.helpers.MyUMLBaseEditHelper {
}
