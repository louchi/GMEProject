package org.eclipse.myTest.DrawUML.diagram.edit.helpers;

/**
 * @generated
 */
public class BasePanelEditHelper extends
		org.eclipse.myTest.DrawUML.diagram.edit.helpers.MyUMLBaseEditHelper {
}
