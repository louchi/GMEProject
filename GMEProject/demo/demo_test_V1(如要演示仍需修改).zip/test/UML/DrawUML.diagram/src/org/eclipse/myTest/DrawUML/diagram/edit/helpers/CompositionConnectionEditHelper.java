package org.eclipse.myTest.DrawUML.diagram.edit.helpers;

/**
 * @generated
 */
public class CompositionConnectionEditHelper extends
		org.eclipse.myTest.DrawUML.diagram.edit.helpers.MyUMLBaseEditHelper {
}
