package org.eclipse.myTest.DrawUML.diagram.edit.helpers;

/**
 * @generated
 */
public class ConstraintDefinitionEditHelper extends
		org.eclipse.myTest.DrawUML.diagram.edit.helpers.MyUMLBaseEditHelper {
}
