package org.eclipse.myTest.DrawUML.diagram.edit.parts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

/**
 * @generated
 */
public class MyUMLEditPartFactory implements EditPartFactory {

	/**
	 * @generated
	 */
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getVisualID(view)) {

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.BasePanelEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassDiagramEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassDiagramEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassDiagramNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassDiagramNameEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassCopyEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassCopyEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassCopyNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassCopyNameEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.InheritanceEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.InheritanceEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.InheritanceNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.InheritanceNameEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintNameEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintDefinitionEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintDefinitionEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintDefinitionNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintDefinitionNameEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassNameEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConnectorNodeEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ConnectorNodeEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConnectorNodeNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ConnectorNodeNameEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassAttributesEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassAttributesEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionNameEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionNameEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart(
						view);

			case org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionNameEditPart.VISUAL_ID:
				return new org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionNameEditPart(
						view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	 * @generated
	 */
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	 * @generated
	 */
	public static CellEditorLocator getTextCellEditorLocator(
			ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE
				.getTextCellEditorLocator(source);
	}

}
