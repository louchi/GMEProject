package org.eclipse.myTest.DrawUML.diagram.edit.policies;

/**
 * @generated
 */
public class ClassAttributesItemSemanticEditPolicy
		extends
		org.eclipse.myTest.DrawUML.diagram.edit.policies.MyUMLBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public ClassAttributesItemSemanticEditPolicy() {
		super(
				org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.Class_2006);
	}

}
