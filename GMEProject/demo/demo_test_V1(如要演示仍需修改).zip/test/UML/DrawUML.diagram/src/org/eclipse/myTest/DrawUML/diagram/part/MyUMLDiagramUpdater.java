package org.eclipse.myTest.DrawUML.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

/**
 * @generated
 */
public class MyUMLDiagramUpdater {

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor> getSemanticChildren(
			View view) {
		switch (org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
			return getBasePanel_1000SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor> getBasePanel_1000SemanticChildren(
			View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		org.eclipse.myTest.DrawUML.BasePanel modelElement = (org.eclipse.myTest.DrawUML.BasePanel) view
				.getElement();
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor>();
		for (Iterator<?> it = modelElement.getHaveShapes().iterator(); it
				.hasNext();) {
			org.eclipse.myTest.DrawUML.AbstractShape childElement = (org.eclipse.myTest.DrawUML.AbstractShape) it
					.next();
			int visualID = org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getNodeVisualID(view, childElement);
			if (visualID == org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassDiagramEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor(
						childElement, visualID));
				continue;
			}
			if (visualID == org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassCopyEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor(
						childElement, visualID));
				continue;
			}
			if (visualID == org.eclipse.myTest.DrawUML.diagram.edit.parts.InheritanceEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor(
						childElement, visualID));
				continue;
			}
			if (visualID == org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor(
						childElement, visualID));
				continue;
			}
			if (visualID == org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintDefinitionEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor(
						childElement, visualID));
				continue;
			}
			if (visualID == org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor(
						childElement, visualID));
				continue;
			}
			if (visualID == org.eclipse.myTest.DrawUML.diagram.edit.parts.ConnectorNodeEditPart.VISUAL_ID) {
				result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor(
						childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getContainedLinks(
			View view) {
		switch (org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.BasePanelEditPart.VISUAL_ID:
			return getBasePanel_1000ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassDiagramEditPart.VISUAL_ID:
			return getClassDiagram_2001ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassCopyEditPart.VISUAL_ID:
			return getClassCopy_2002ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.InheritanceEditPart.VISUAL_ID:
			return getInheritance_2003ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintEditPart.VISUAL_ID:
			return getConstraint_2004ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintDefinitionEditPart.VISUAL_ID:
			return getConstraintDefinition_2005ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassEditPart.VISUAL_ID:
			return getClass_2006ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConnectorNodeEditPart.VISUAL_ID:
			return getConnectorNode_2007ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID:
			return getCompositionConnection_4001ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID:
			return getAggregationConnection_4002ContainedLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID:
			return getAssociationConnection_4003ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getIncomingLinks(
			View view) {
		switch (org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassDiagramEditPart.VISUAL_ID:
			return getClassDiagram_2001IncomingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassCopyEditPart.VISUAL_ID:
			return getClassCopy_2002IncomingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.InheritanceEditPart.VISUAL_ID:
			return getInheritance_2003IncomingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintEditPart.VISUAL_ID:
			return getConstraint_2004IncomingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintDefinitionEditPart.VISUAL_ID:
			return getConstraintDefinition_2005IncomingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassEditPart.VISUAL_ID:
			return getClass_2006IncomingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConnectorNodeEditPart.VISUAL_ID:
			return getConnectorNode_2007IncomingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID:
			return getCompositionConnection_4001IncomingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID:
			return getAggregationConnection_4002IncomingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID:
			return getAssociationConnection_4003IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getOutgoingLinks(
			View view) {
		switch (org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
				.getVisualID(view)) {
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassDiagramEditPart.VISUAL_ID:
			return getClassDiagram_2001OutgoingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassCopyEditPart.VISUAL_ID:
			return getClassCopy_2002OutgoingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.InheritanceEditPart.VISUAL_ID:
			return getInheritance_2003OutgoingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintEditPart.VISUAL_ID:
			return getConstraint_2004OutgoingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConstraintDefinitionEditPart.VISUAL_ID:
			return getConstraintDefinition_2005OutgoingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ClassEditPart.VISUAL_ID:
			return getClass_2006OutgoingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.ConnectorNodeEditPart.VISUAL_ID:
			return getConnectorNode_2007OutgoingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID:
			return getCompositionConnection_4001OutgoingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID:
			return getAggregationConnection_4002OutgoingLinks(view);
		case org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID:
			return getAssociationConnection_4003OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getBasePanel_1000ContainedLinks(
			View view) {
		org.eclipse.myTest.DrawUML.BasePanel modelElement = (org.eclipse.myTest.DrawUML.BasePanel) view
				.getElement();
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getContainedTypeModelFacetLinks_CompositionConnection_4001(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_AggregationConnection_4002(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_AssociationConnection_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getClassDiagram_2001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getClassCopy_2002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getInheritance_2003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getConstraint_2004ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getConstraintDefinition_2005ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getClass_2006ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getConnectorNode_2007ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getCompositionConnection_4001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getAggregationConnection_4002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getAssociationConnection_4003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getClassDiagram_2001IncomingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.ClassDiagram modelElement = (org.eclipse.myTest.DrawUML.ClassDiagram) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_CompositionConnection_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AggregationConnection_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AssociationConnection_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getClassCopy_2002IncomingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.ClassCopy modelElement = (org.eclipse.myTest.DrawUML.ClassCopy) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_CompositionConnection_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AggregationConnection_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AssociationConnection_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getInheritance_2003IncomingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.Inheritance modelElement = (org.eclipse.myTest.DrawUML.Inheritance) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_CompositionConnection_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AggregationConnection_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AssociationConnection_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getConstraint_2004IncomingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.Constraint modelElement = (org.eclipse.myTest.DrawUML.Constraint) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_CompositionConnection_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AggregationConnection_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AssociationConnection_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getConstraintDefinition_2005IncomingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.ConstraintDefinition modelElement = (org.eclipse.myTest.DrawUML.ConstraintDefinition) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_CompositionConnection_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AggregationConnection_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AssociationConnection_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getClass_2006IncomingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.Class modelElement = (org.eclipse.myTest.DrawUML.Class) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_CompositionConnection_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AggregationConnection_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AssociationConnection_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getConnectorNode_2007IncomingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.ConnectorNode modelElement = (org.eclipse.myTest.DrawUML.ConnectorNode) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_CompositionConnection_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AggregationConnection_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_AssociationConnection_4003(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getCompositionConnection_4001IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getAggregationConnection_4002IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getAssociationConnection_4003IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getClassDiagram_2001OutgoingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.ClassDiagram modelElement = (org.eclipse.myTest.DrawUML.ClassDiagram) view
				.getElement();
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_CompositionConnection_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AggregationConnection_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AssociationConnection_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getClassCopy_2002OutgoingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.ClassCopy modelElement = (org.eclipse.myTest.DrawUML.ClassCopy) view
				.getElement();
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_CompositionConnection_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AggregationConnection_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AssociationConnection_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getInheritance_2003OutgoingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.Inheritance modelElement = (org.eclipse.myTest.DrawUML.Inheritance) view
				.getElement();
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_CompositionConnection_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AggregationConnection_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AssociationConnection_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getConstraint_2004OutgoingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.Constraint modelElement = (org.eclipse.myTest.DrawUML.Constraint) view
				.getElement();
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_CompositionConnection_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AggregationConnection_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AssociationConnection_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getConstraintDefinition_2005OutgoingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.ConstraintDefinition modelElement = (org.eclipse.myTest.DrawUML.ConstraintDefinition) view
				.getElement();
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_CompositionConnection_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AggregationConnection_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AssociationConnection_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getClass_2006OutgoingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.Class modelElement = (org.eclipse.myTest.DrawUML.Class) view
				.getElement();
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_CompositionConnection_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AggregationConnection_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AssociationConnection_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getConnectorNode_2007OutgoingLinks(
			View view) {
		org.eclipse.myTest.DrawUML.ConnectorNode modelElement = (org.eclipse.myTest.DrawUML.ConnectorNode) view
				.getElement();
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_CompositionConnection_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AggregationConnection_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_AssociationConnection_4003(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getCompositionConnection_4001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getAggregationConnection_4002OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getAssociationConnection_4003OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getContainedTypeModelFacetLinks_CompositionConnection_4001(
			org.eclipse.myTest.DrawUML.BasePanel container) {
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		for (Iterator<?> links = container.getHaveConnections().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.DrawUML.CompositionConnection) {
				continue;
			}
			org.eclipse.myTest.DrawUML.CompositionConnection link = (org.eclipse.myTest.DrawUML.CompositionConnection) linkObject;
			if (org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID != org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AbstractShape dst = link.getTo();
			org.eclipse.myTest.DrawUML.AbstractShape src = link.getFrom();
			result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.CompositionConnection_4001,
					org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getContainedTypeModelFacetLinks_AggregationConnection_4002(
			org.eclipse.myTest.DrawUML.BasePanel container) {
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		for (Iterator<?> links = container.getHaveConnections().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.DrawUML.AggregationConnection) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AggregationConnection link = (org.eclipse.myTest.DrawUML.AggregationConnection) linkObject;
			if (org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID != org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AbstractShape dst = link.getTo();
			org.eclipse.myTest.DrawUML.AbstractShape src = link.getFrom();
			result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.AggregationConnection_4002,
					org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getContainedTypeModelFacetLinks_AssociationConnection_4003(
			org.eclipse.myTest.DrawUML.BasePanel container) {
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		for (Iterator<?> links = container.getHaveConnections().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.DrawUML.AssociationConnection) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AssociationConnection link = (org.eclipse.myTest.DrawUML.AssociationConnection) linkObject;
			if (org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID != org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AbstractShape dst = link.getTo();
			org.eclipse.myTest.DrawUML.AbstractShape src = link.getFrom();
			result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.AssociationConnection_4003,
					org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getIncomingTypeModelFacetLinks_CompositionConnection_4001(
			org.eclipse.myTest.DrawUML.AbstractShape target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != org.eclipse.myTest.DrawUML.DrawUMLPackage.eINSTANCE
					.getAbstractConnection_To()
					|| false == setting.getEObject() instanceof org.eclipse.myTest.DrawUML.CompositionConnection) {
				continue;
			}
			org.eclipse.myTest.DrawUML.CompositionConnection link = (org.eclipse.myTest.DrawUML.CompositionConnection) setting
					.getEObject();
			if (org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID != org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AbstractShape src = link.getFrom();
			result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor(
					src,
					target,
					link,
					org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.CompositionConnection_4001,
					org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getIncomingTypeModelFacetLinks_AggregationConnection_4002(
			org.eclipse.myTest.DrawUML.AbstractShape target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != org.eclipse.myTest.DrawUML.DrawUMLPackage.eINSTANCE
					.getAbstractConnection_To()
					|| false == setting.getEObject() instanceof org.eclipse.myTest.DrawUML.AggregationConnection) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AggregationConnection link = (org.eclipse.myTest.DrawUML.AggregationConnection) setting
					.getEObject();
			if (org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID != org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AbstractShape src = link.getFrom();
			result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor(
					src,
					target,
					link,
					org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.AggregationConnection_4002,
					org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getIncomingTypeModelFacetLinks_AssociationConnection_4003(
			org.eclipse.myTest.DrawUML.AbstractShape target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != org.eclipse.myTest.DrawUML.DrawUMLPackage.eINSTANCE
					.getAbstractConnection_To()
					|| false == setting.getEObject() instanceof org.eclipse.myTest.DrawUML.AssociationConnection) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AssociationConnection link = (org.eclipse.myTest.DrawUML.AssociationConnection) setting
					.getEObject();
			if (org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID != org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AbstractShape src = link.getFrom();
			result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor(
					src,
					target,
					link,
					org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.AssociationConnection_4003,
					org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getOutgoingTypeModelFacetLinks_CompositionConnection_4001(
			org.eclipse.myTest.DrawUML.AbstractShape source) {
		org.eclipse.myTest.DrawUML.BasePanel container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof org.eclipse.myTest.DrawUML.BasePanel) {
				container = (org.eclipse.myTest.DrawUML.BasePanel) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		for (Iterator<?> links = container.getHaveConnections().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.DrawUML.CompositionConnection) {
				continue;
			}
			org.eclipse.myTest.DrawUML.CompositionConnection link = (org.eclipse.myTest.DrawUML.CompositionConnection) linkObject;
			if (org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID != org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AbstractShape dst = link.getTo();
			org.eclipse.myTest.DrawUML.AbstractShape src = link.getFrom();
			if (src != source) {
				continue;
			}
			result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.CompositionConnection_4001,
					org.eclipse.myTest.DrawUML.diagram.edit.parts.CompositionConnectionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getOutgoingTypeModelFacetLinks_AggregationConnection_4002(
			org.eclipse.myTest.DrawUML.AbstractShape source) {
		org.eclipse.myTest.DrawUML.BasePanel container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof org.eclipse.myTest.DrawUML.BasePanel) {
				container = (org.eclipse.myTest.DrawUML.BasePanel) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		for (Iterator<?> links = container.getHaveConnections().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.DrawUML.AggregationConnection) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AggregationConnection link = (org.eclipse.myTest.DrawUML.AggregationConnection) linkObject;
			if (org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID != org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AbstractShape dst = link.getTo();
			org.eclipse.myTest.DrawUML.AbstractShape src = link.getFrom();
			if (src != source) {
				continue;
			}
			result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.AggregationConnection_4002,
					org.eclipse.myTest.DrawUML.diagram.edit.parts.AggregationConnectionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getOutgoingTypeModelFacetLinks_AssociationConnection_4003(
			org.eclipse.myTest.DrawUML.AbstractShape source) {
		org.eclipse.myTest.DrawUML.BasePanel container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof org.eclipse.myTest.DrawUML.BasePanel) {
				container = (org.eclipse.myTest.DrawUML.BasePanel) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> result = new LinkedList<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor>();
		for (Iterator<?> links = container.getHaveConnections().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof org.eclipse.myTest.DrawUML.AssociationConnection) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AssociationConnection link = (org.eclipse.myTest.DrawUML.AssociationConnection) linkObject;
			if (org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID != org.eclipse.myTest.DrawUML.diagram.part.MyUMLVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			org.eclipse.myTest.DrawUML.AbstractShape dst = link.getTo();
			org.eclipse.myTest.DrawUML.AbstractShape src = link.getFrom();
			if (src != source) {
				continue;
			}
			result.add(new org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor(
					src,
					dst,
					link,
					org.eclipse.myTest.DrawUML.diagram.providers.MyUMLElementTypes.AssociationConnection_4003,
					org.eclipse.myTest.DrawUML.diagram.edit.parts.AssociationConnectionEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		 * @generated
		 */

		public List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLNodeDescriptor> getSemanticChildren(
				View view) {
			return MyUMLDiagramUpdater.getSemanticChildren(view);
		}

		/**
		 * @generated
		 */

		public List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getContainedLinks(
				View view) {
			return MyUMLDiagramUpdater.getContainedLinks(view);
		}

		/**
		 * @generated
		 */

		public List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getIncomingLinks(
				View view) {
			return MyUMLDiagramUpdater.getIncomingLinks(view);
		}

		/**
		 * @generated
		 */

		public List<org.eclipse.myTest.DrawUML.diagram.part.MyUMLLinkDescriptor> getOutgoingLinks(
				View view) {
			return MyUMLDiagramUpdater.getOutgoingLinks(view);
		}
	};

}
