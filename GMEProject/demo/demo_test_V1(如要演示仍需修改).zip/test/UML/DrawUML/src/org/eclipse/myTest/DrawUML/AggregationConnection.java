/**
 */
package org.eclipse.myTest.DrawUML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Aggregation Connection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getAggregationConnection()
 * @model
 * @generated
 */
public interface AggregationConnection extends AbstractConnection {
} // AggregationConnection
