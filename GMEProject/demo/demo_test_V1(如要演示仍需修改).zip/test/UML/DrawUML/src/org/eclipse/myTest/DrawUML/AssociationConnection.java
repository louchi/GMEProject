/**
 */
package org.eclipse.myTest.DrawUML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Association Connection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getAssociationConnection()
 * @model
 * @generated
 */
public interface AssociationConnection extends AbstractConnection {
} // AssociationConnection
