/**
 */
package org.eclipse.myTest.DrawUML;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attributes</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getAttributes()
 * @model
 * @generated
 */
public interface Attributes extends EObject {
} // Attributes
