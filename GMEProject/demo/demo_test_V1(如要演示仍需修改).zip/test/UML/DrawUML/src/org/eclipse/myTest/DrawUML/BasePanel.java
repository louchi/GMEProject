/**
 */
package org.eclipse.myTest.DrawUML;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Base Panel</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.myTest.DrawUML.BasePanel#getHaveShapes <em>Have Shapes</em>}</li>
 *   <li>{@link org.eclipse.myTest.DrawUML.BasePanel#getHaveConnections <em>Have Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getBasePanel()
 * @model
 * @generated
 */
public interface BasePanel extends EObject {
	/**
	 * Returns the value of the '<em><b>Have Shapes</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.myTest.DrawUML.AbstractShape}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Have Shapes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Have Shapes</em>' containment reference list.
	 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getBasePanel_HaveShapes()
	 * @model containment="true"
	 * @generated
	 */
	EList<AbstractShape> getHaveShapes();

	/**
	 * Returns the value of the '<em><b>Have Connections</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.myTest.DrawUML.AbstractConnection}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Have Connections</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Have Connections</em>' containment reference list.
	 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getBasePanel_HaveConnections()
	 * @model containment="true"
	 * @generated
	 */
	EList<AbstractConnection> getHaveConnections();

} // BasePanel
