/**
 */
package org.eclipse.myTest.DrawUML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.myTest.DrawUML.Class#getInclude <em>Include</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getClass_()
 * @model
 * @generated
 */
public interface Class extends AbstractShape {

	/**
	 * Returns the value of the '<em><b>Include</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Include</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Include</em>' containment reference.
	 * @see #setInclude(Attributes)
	 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getClass_Include()
	 * @model containment="true"
	 * @generated
	 */
	Attributes getInclude();

	/**
	 * Sets the value of the '{@link org.eclipse.myTest.DrawUML.Class#getInclude <em>Include</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Include</em>' containment reference.
	 * @see #getInclude()
	 * @generated
	 */
	void setInclude(Attributes value);
} // Class
