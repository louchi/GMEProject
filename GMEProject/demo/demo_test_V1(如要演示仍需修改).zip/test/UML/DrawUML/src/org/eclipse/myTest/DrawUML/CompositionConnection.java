/**
 */
package org.eclipse.myTest.DrawUML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Composition Connection</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getCompositionConnection()
 * @model
 * @generated
 */
public interface CompositionConnection extends AbstractConnection {
} // CompositionConnection
