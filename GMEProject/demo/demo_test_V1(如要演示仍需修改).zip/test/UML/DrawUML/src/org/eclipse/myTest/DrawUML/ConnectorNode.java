/**
 */
package org.eclipse.myTest.DrawUML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connector Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getConnectorNode()
 * @model
 * @generated
 */
public interface ConnectorNode extends AbstractShape {
} // ConnectorNode
