/**
 */
package org.eclipse.myTest.DrawUML;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#getConstraint()
 * @model
 * @generated
 */
public interface Constraint extends AbstractShape {
} // Constraint
