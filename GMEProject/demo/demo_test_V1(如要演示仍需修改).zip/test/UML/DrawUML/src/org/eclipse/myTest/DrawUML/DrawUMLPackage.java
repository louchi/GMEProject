/**
 */
package org.eclipse.myTest.DrawUML;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.myTest.DrawUML.DrawUMLFactory
 * @model kind="package"
 * @generated
 */
public interface DrawUMLPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "DrawUML";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "DrawUML.myTest.eclipse.org";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "org.eclipse.myTest";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DrawUMLPackage eINSTANCE = org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.AbstractShapeImpl <em>Abstract Shape</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.AbstractShapeImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAbstractShape()
	 * @generated
	 */
	int ABSTRACT_SHAPE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPE__SOURCES = 1;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPE__TARGETS = 2;

	/**
	 * The number of structural features of the '<em>Abstract Shape</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Abstract Shape</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_SHAPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.ClassImpl <em>Class</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.ClassImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getClass_()
	 * @generated
	 */
	int CLASS = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__NAME = ABSTRACT_SHAPE__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__SOURCES = ABSTRACT_SHAPE__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__TARGETS = ABSTRACT_SHAPE__TARGETS;

	/**
	 * The feature id for the '<em><b>Include</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS__INCLUDE = ABSTRACT_SHAPE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_FEATURE_COUNT = ABSTRACT_SHAPE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_OPERATION_COUNT = ABSTRACT_SHAPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.ClassCopyImpl <em>Class Copy</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.ClassCopyImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getClassCopy()
	 * @generated
	 */
	int CLASS_COPY = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_COPY__NAME = ABSTRACT_SHAPE__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_COPY__SOURCES = ABSTRACT_SHAPE__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_COPY__TARGETS = ABSTRACT_SHAPE__TARGETS;

	/**
	 * The number of structural features of the '<em>Class Copy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_COPY_FEATURE_COUNT = ABSTRACT_SHAPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Class Copy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_COPY_OPERATION_COUNT = ABSTRACT_SHAPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.ClassDiagramImpl <em>Class Diagram</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.ClassDiagramImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getClassDiagram()
	 * @generated
	 */
	int CLASS_DIAGRAM = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_DIAGRAM__NAME = ABSTRACT_SHAPE__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_DIAGRAM__SOURCES = ABSTRACT_SHAPE__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_DIAGRAM__TARGETS = ABSTRACT_SHAPE__TARGETS;

	/**
	 * The number of structural features of the '<em>Class Diagram</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_DIAGRAM_FEATURE_COUNT = ABSTRACT_SHAPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Class Diagram</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_DIAGRAM_OPERATION_COUNT = ABSTRACT_SHAPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.ConnectorNodeImpl <em>Connector Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.ConnectorNodeImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getConnectorNode()
	 * @generated
	 */
	int CONNECTOR_NODE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTOR_NODE__NAME = ABSTRACT_SHAPE__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTOR_NODE__SOURCES = ABSTRACT_SHAPE__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTOR_NODE__TARGETS = ABSTRACT_SHAPE__TARGETS;

	/**
	 * The number of structural features of the '<em>Connector Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTOR_NODE_FEATURE_COUNT = ABSTRACT_SHAPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Connector Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTOR_NODE_OPERATION_COUNT = ABSTRACT_SHAPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.InheritanceImpl <em>Inheritance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.InheritanceImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getInheritance()
	 * @generated
	 */
	int INHERITANCE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INHERITANCE__NAME = ABSTRACT_SHAPE__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INHERITANCE__SOURCES = ABSTRACT_SHAPE__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INHERITANCE__TARGETS = ABSTRACT_SHAPE__TARGETS;

	/**
	 * The number of structural features of the '<em>Inheritance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INHERITANCE_FEATURE_COUNT = ABSTRACT_SHAPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Inheritance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INHERITANCE_OPERATION_COUNT = ABSTRACT_SHAPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.AbstractConnectionImpl <em>Abstract Connection</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.AbstractConnectionImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAbstractConnection()
	 * @generated
	 */
	int ABSTRACT_CONNECTION = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_CONNECTION__NAME = 0;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_CONNECTION__FROM = 1;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_CONNECTION__TO = 2;

	/**
	 * The number of structural features of the '<em>Abstract Connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_CONNECTION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Abstract Connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_CONNECTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.AssociationConnectionImpl <em>Association Connection</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.AssociationConnectionImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAssociationConnection()
	 * @generated
	 */
	int ASSOCIATION_CONNECTION = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_CONNECTION__NAME = ABSTRACT_CONNECTION__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_CONNECTION__FROM = ABSTRACT_CONNECTION__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_CONNECTION__TO = ABSTRACT_CONNECTION__TO;

	/**
	 * The number of structural features of the '<em>Association Connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_CONNECTION_FEATURE_COUNT = ABSTRACT_CONNECTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Association Connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_CONNECTION_OPERATION_COUNT = ABSTRACT_CONNECTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.CompositionConnectionImpl <em>Composition Connection</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.CompositionConnectionImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getCompositionConnection()
	 * @generated
	 */
	int COMPOSITION_CONNECTION = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION_CONNECTION__NAME = ABSTRACT_CONNECTION__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION_CONNECTION__FROM = ABSTRACT_CONNECTION__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION_CONNECTION__TO = ABSTRACT_CONNECTION__TO;

	/**
	 * The number of structural features of the '<em>Composition Connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION_CONNECTION_FEATURE_COUNT = ABSTRACT_CONNECTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Composition Connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSITION_CONNECTION_OPERATION_COUNT = ABSTRACT_CONNECTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.AggregationConnectionImpl <em>Aggregation Connection</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.AggregationConnectionImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAggregationConnection()
	 * @generated
	 */
	int AGGREGATION_CONNECTION = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION_CONNECTION__NAME = ABSTRACT_CONNECTION__NAME;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION_CONNECTION__FROM = ABSTRACT_CONNECTION__FROM;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION_CONNECTION__TO = ABSTRACT_CONNECTION__TO;

	/**
	 * The number of structural features of the '<em>Aggregation Connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION_CONNECTION_FEATURE_COUNT = ABSTRACT_CONNECTION_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Aggregation Connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION_CONNECTION_OPERATION_COUNT = ABSTRACT_CONNECTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.BasePanelImpl <em>Base Panel</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.BasePanelImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getBasePanel()
	 * @generated
	 */
	int BASE_PANEL = 10;

	/**
	 * The feature id for the '<em><b>Have Shapes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL__HAVE_SHAPES = 0;

	/**
	 * The feature id for the '<em><b>Have Connections</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL__HAVE_CONNECTIONS = 1;

	/**
	 * The number of structural features of the '<em>Base Panel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Base Panel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_PANEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.ConstraintImpl <em>Constraint</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.ConstraintImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getConstraint()
	 * @generated
	 */
	int CONSTRAINT = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT__NAME = ABSTRACT_SHAPE__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT__SOURCES = ABSTRACT_SHAPE__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT__TARGETS = ABSTRACT_SHAPE__TARGETS;

	/**
	 * The number of structural features of the '<em>Constraint</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_FEATURE_COUNT = ABSTRACT_SHAPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Constraint</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_OPERATION_COUNT = ABSTRACT_SHAPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.ConstraintDefinitionImpl <em>Constraint Definition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.ConstraintDefinitionImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getConstraintDefinition()
	 * @generated
	 */
	int CONSTRAINT_DEFINITION = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_DEFINITION__NAME = ABSTRACT_SHAPE__NAME;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_DEFINITION__SOURCES = ABSTRACT_SHAPE__SOURCES;

	/**
	 * The feature id for the '<em><b>Targets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_DEFINITION__TARGETS = ABSTRACT_SHAPE__TARGETS;

	/**
	 * The number of structural features of the '<em>Constraint Definition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_DEFINITION_FEATURE_COUNT = ABSTRACT_SHAPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Constraint Definition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_DEFINITION_OPERATION_COUNT = ABSTRACT_SHAPE_OPERATION_COUNT + 0;


	/**
	 * The meta object id for the '{@link org.eclipse.myTest.DrawUML.impl.AttributesImpl <em>Attributes</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.myTest.DrawUML.impl.AttributesImpl
	 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAttributes()
	 * @generated
	 */
	int ATTRIBUTES = 13;

	/**
	 * The number of structural features of the '<em>Attributes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTES_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Attributes</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTES_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.Class <em>Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Class</em>'.
	 * @see org.eclipse.myTest.DrawUML.Class
	 * @generated
	 */
	EClass getClass_();

	/**
	 * Returns the meta object for the containment reference '{@link org.eclipse.myTest.DrawUML.Class#getInclude <em>Include</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Include</em>'.
	 * @see org.eclipse.myTest.DrawUML.Class#getInclude()
	 * @see #getClass_()
	 * @generated
	 */
	EReference getClass_Include();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.ClassCopy <em>Class Copy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Class Copy</em>'.
	 * @see org.eclipse.myTest.DrawUML.ClassCopy
	 * @generated
	 */
	EClass getClassCopy();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.ClassDiagram <em>Class Diagram</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Class Diagram</em>'.
	 * @see org.eclipse.myTest.DrawUML.ClassDiagram
	 * @generated
	 */
	EClass getClassDiagram();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.ConnectorNode <em>Connector Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connector Node</em>'.
	 * @see org.eclipse.myTest.DrawUML.ConnectorNode
	 * @generated
	 */
	EClass getConnectorNode();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.Inheritance <em>Inheritance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Inheritance</em>'.
	 * @see org.eclipse.myTest.DrawUML.Inheritance
	 * @generated
	 */
	EClass getInheritance();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.AbstractShape <em>Abstract Shape</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Shape</em>'.
	 * @see org.eclipse.myTest.DrawUML.AbstractShape
	 * @generated
	 */
	EClass getAbstractShape();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.myTest.DrawUML.AbstractShape#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.myTest.DrawUML.AbstractShape#getName()
	 * @see #getAbstractShape()
	 * @generated
	 */
	EAttribute getAbstractShape_Name();

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.myTest.DrawUML.AbstractShape#getSources <em>Sources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Sources</em>'.
	 * @see org.eclipse.myTest.DrawUML.AbstractShape#getSources()
	 * @see #getAbstractShape()
	 * @generated
	 */
	EReference getAbstractShape_Sources();

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.myTest.DrawUML.AbstractShape#getTargets <em>Targets</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Targets</em>'.
	 * @see org.eclipse.myTest.DrawUML.AbstractShape#getTargets()
	 * @see #getAbstractShape()
	 * @generated
	 */
	EReference getAbstractShape_Targets();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.AbstractConnection <em>Abstract Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Connection</em>'.
	 * @see org.eclipse.myTest.DrawUML.AbstractConnection
	 * @generated
	 */
	EClass getAbstractConnection();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.myTest.DrawUML.AbstractConnection#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.myTest.DrawUML.AbstractConnection#getName()
	 * @see #getAbstractConnection()
	 * @generated
	 */
	EAttribute getAbstractConnection_Name();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.myTest.DrawUML.AbstractConnection#getFrom <em>From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>From</em>'.
	 * @see org.eclipse.myTest.DrawUML.AbstractConnection#getFrom()
	 * @see #getAbstractConnection()
	 * @generated
	 */
	EReference getAbstractConnection_From();

	/**
	 * Returns the meta object for the reference '{@link org.eclipse.myTest.DrawUML.AbstractConnection#getTo <em>To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>To</em>'.
	 * @see org.eclipse.myTest.DrawUML.AbstractConnection#getTo()
	 * @see #getAbstractConnection()
	 * @generated
	 */
	EReference getAbstractConnection_To();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.AssociationConnection <em>Association Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Association Connection</em>'.
	 * @see org.eclipse.myTest.DrawUML.AssociationConnection
	 * @generated
	 */
	EClass getAssociationConnection();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.CompositionConnection <em>Composition Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Composition Connection</em>'.
	 * @see org.eclipse.myTest.DrawUML.CompositionConnection
	 * @generated
	 */
	EClass getCompositionConnection();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.AggregationConnection <em>Aggregation Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aggregation Connection</em>'.
	 * @see org.eclipse.myTest.DrawUML.AggregationConnection
	 * @generated
	 */
	EClass getAggregationConnection();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.BasePanel <em>Base Panel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Base Panel</em>'.
	 * @see org.eclipse.myTest.DrawUML.BasePanel
	 * @generated
	 */
	EClass getBasePanel();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.myTest.DrawUML.BasePanel#getHaveShapes <em>Have Shapes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Have Shapes</em>'.
	 * @see org.eclipse.myTest.DrawUML.BasePanel#getHaveShapes()
	 * @see #getBasePanel()
	 * @generated
	 */
	EReference getBasePanel_HaveShapes();

	/**
	 * Returns the meta object for the containment reference list '{@link org.eclipse.myTest.DrawUML.BasePanel#getHaveConnections <em>Have Connections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Have Connections</em>'.
	 * @see org.eclipse.myTest.DrawUML.BasePanel#getHaveConnections()
	 * @see #getBasePanel()
	 * @generated
	 */
	EReference getBasePanel_HaveConnections();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.Constraint <em>Constraint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Constraint</em>'.
	 * @see org.eclipse.myTest.DrawUML.Constraint
	 * @generated
	 */
	EClass getConstraint();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.ConstraintDefinition <em>Constraint Definition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Constraint Definition</em>'.
	 * @see org.eclipse.myTest.DrawUML.ConstraintDefinition
	 * @generated
	 */
	EClass getConstraintDefinition();

	/**
	 * Returns the meta object for class '{@link org.eclipse.myTest.DrawUML.Attributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attributes</em>'.
	 * @see org.eclipse.myTest.DrawUML.Attributes
	 * @generated
	 */
	EClass getAttributes();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DrawUMLFactory getDrawUMLFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.ClassImpl <em>Class</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.ClassImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getClass_()
		 * @generated
		 */
		EClass CLASS = eINSTANCE.getClass_();

		/**
		 * The meta object literal for the '<em><b>Include</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLASS__INCLUDE = eINSTANCE.getClass_Include();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.ClassCopyImpl <em>Class Copy</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.ClassCopyImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getClassCopy()
		 * @generated
		 */
		EClass CLASS_COPY = eINSTANCE.getClassCopy();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.ClassDiagramImpl <em>Class Diagram</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.ClassDiagramImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getClassDiagram()
		 * @generated
		 */
		EClass CLASS_DIAGRAM = eINSTANCE.getClassDiagram();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.ConnectorNodeImpl <em>Connector Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.ConnectorNodeImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getConnectorNode()
		 * @generated
		 */
		EClass CONNECTOR_NODE = eINSTANCE.getConnectorNode();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.InheritanceImpl <em>Inheritance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.InheritanceImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getInheritance()
		 * @generated
		 */
		EClass INHERITANCE = eINSTANCE.getInheritance();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.AbstractShapeImpl <em>Abstract Shape</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.AbstractShapeImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAbstractShape()
		 * @generated
		 */
		EClass ABSTRACT_SHAPE = eINSTANCE.getAbstractShape();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_SHAPE__NAME = eINSTANCE.getAbstractShape_Name();

		/**
		 * The meta object literal for the '<em><b>Sources</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_SHAPE__SOURCES = eINSTANCE.getAbstractShape_Sources();

		/**
		 * The meta object literal for the '<em><b>Targets</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_SHAPE__TARGETS = eINSTANCE.getAbstractShape_Targets();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.AbstractConnectionImpl <em>Abstract Connection</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.AbstractConnectionImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAbstractConnection()
		 * @generated
		 */
		EClass ABSTRACT_CONNECTION = eINSTANCE.getAbstractConnection();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_CONNECTION__NAME = eINSTANCE.getAbstractConnection_Name();

		/**
		 * The meta object literal for the '<em><b>From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_CONNECTION__FROM = eINSTANCE.getAbstractConnection_From();

		/**
		 * The meta object literal for the '<em><b>To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_CONNECTION__TO = eINSTANCE.getAbstractConnection_To();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.AssociationConnectionImpl <em>Association Connection</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.AssociationConnectionImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAssociationConnection()
		 * @generated
		 */
		EClass ASSOCIATION_CONNECTION = eINSTANCE.getAssociationConnection();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.CompositionConnectionImpl <em>Composition Connection</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.CompositionConnectionImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getCompositionConnection()
		 * @generated
		 */
		EClass COMPOSITION_CONNECTION = eINSTANCE.getCompositionConnection();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.AggregationConnectionImpl <em>Aggregation Connection</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.AggregationConnectionImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAggregationConnection()
		 * @generated
		 */
		EClass AGGREGATION_CONNECTION = eINSTANCE.getAggregationConnection();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.BasePanelImpl <em>Base Panel</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.BasePanelImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getBasePanel()
		 * @generated
		 */
		EClass BASE_PANEL = eINSTANCE.getBasePanel();

		/**
		 * The meta object literal for the '<em><b>Have Shapes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASE_PANEL__HAVE_SHAPES = eINSTANCE.getBasePanel_HaveShapes();

		/**
		 * The meta object literal for the '<em><b>Have Connections</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASE_PANEL__HAVE_CONNECTIONS = eINSTANCE.getBasePanel_HaveConnections();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.ConstraintImpl <em>Constraint</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.ConstraintImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getConstraint()
		 * @generated
		 */
		EClass CONSTRAINT = eINSTANCE.getConstraint();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.ConstraintDefinitionImpl <em>Constraint Definition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.ConstraintDefinitionImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getConstraintDefinition()
		 * @generated
		 */
		EClass CONSTRAINT_DEFINITION = eINSTANCE.getConstraintDefinition();

		/**
		 * The meta object literal for the '{@link org.eclipse.myTest.DrawUML.impl.AttributesImpl <em>Attributes</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.myTest.DrawUML.impl.AttributesImpl
		 * @see org.eclipse.myTest.DrawUML.impl.DrawUMLPackageImpl#getAttributes()
		 * @generated
		 */
		EClass ATTRIBUTES = eINSTANCE.getAttributes();

	}

} //DrawUMLPackage
