/**
 */
package org.eclipse.myTest.DrawUML.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.DrawUML.AssociationConnection;
import org.eclipse.myTest.DrawUML.DrawUMLPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Association Connection</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class AssociationConnectionImpl extends AbstractConnectionImpl implements AssociationConnection {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AssociationConnectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DrawUMLPackage.Literals.ASSOCIATION_CONNECTION;
	}

} //AssociationConnectionImpl
