/**
 */
package org.eclipse.myTest.DrawUML.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.myTest.DrawUML.AbstractConnection;
import org.eclipse.myTest.DrawUML.AbstractShape;
import org.eclipse.myTest.DrawUML.BasePanel;
import org.eclipse.myTest.DrawUML.DrawUMLPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Base Panel</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.myTest.DrawUML.impl.BasePanelImpl#getHaveShapes <em>Have Shapes</em>}</li>
 *   <li>{@link org.eclipse.myTest.DrawUML.impl.BasePanelImpl#getHaveConnections <em>Have Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BasePanelImpl extends MinimalEObjectImpl.Container implements BasePanel {
	/**
	 * The cached value of the '{@link #getHaveShapes() <em>Have Shapes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHaveShapes()
	 * @generated
	 * @ordered
	 */
	protected EList<AbstractShape> haveShapes;

	/**
	 * The cached value of the '{@link #getHaveConnections() <em>Have Connections</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHaveConnections()
	 * @generated
	 * @ordered
	 */
	protected EList<AbstractConnection> haveConnections;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BasePanelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DrawUMLPackage.Literals.BASE_PANEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AbstractShape> getHaveShapes() {
		if (haveShapes == null) {
			haveShapes = new EObjectContainmentEList<AbstractShape>(AbstractShape.class, this, DrawUMLPackage.BASE_PANEL__HAVE_SHAPES);
		}
		return haveShapes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AbstractConnection> getHaveConnections() {
		if (haveConnections == null) {
			haveConnections = new EObjectContainmentEList<AbstractConnection>(AbstractConnection.class, this, DrawUMLPackage.BASE_PANEL__HAVE_CONNECTIONS);
		}
		return haveConnections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case DrawUMLPackage.BASE_PANEL__HAVE_SHAPES:
				return ((InternalEList<?>)getHaveShapes()).basicRemove(otherEnd, msgs);
			case DrawUMLPackage.BASE_PANEL__HAVE_CONNECTIONS:
				return ((InternalEList<?>)getHaveConnections()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case DrawUMLPackage.BASE_PANEL__HAVE_SHAPES:
				return getHaveShapes();
			case DrawUMLPackage.BASE_PANEL__HAVE_CONNECTIONS:
				return getHaveConnections();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case DrawUMLPackage.BASE_PANEL__HAVE_SHAPES:
				getHaveShapes().clear();
				getHaveShapes().addAll((Collection<? extends AbstractShape>)newValue);
				return;
			case DrawUMLPackage.BASE_PANEL__HAVE_CONNECTIONS:
				getHaveConnections().clear();
				getHaveConnections().addAll((Collection<? extends AbstractConnection>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case DrawUMLPackage.BASE_PANEL__HAVE_SHAPES:
				getHaveShapes().clear();
				return;
			case DrawUMLPackage.BASE_PANEL__HAVE_CONNECTIONS:
				getHaveConnections().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case DrawUMLPackage.BASE_PANEL__HAVE_SHAPES:
				return haveShapes != null && !haveShapes.isEmpty();
			case DrawUMLPackage.BASE_PANEL__HAVE_CONNECTIONS:
				return haveConnections != null && !haveConnections.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //BasePanelImpl
