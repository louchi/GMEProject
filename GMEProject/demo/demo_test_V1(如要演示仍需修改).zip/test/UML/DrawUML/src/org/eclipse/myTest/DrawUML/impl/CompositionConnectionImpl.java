/**
 */
package org.eclipse.myTest.DrawUML.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.DrawUML.CompositionConnection;
import org.eclipse.myTest.DrawUML.DrawUMLPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Composition Connection</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class CompositionConnectionImpl extends AbstractConnectionImpl implements CompositionConnection {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CompositionConnectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DrawUMLPackage.Literals.COMPOSITION_CONNECTION;
	}

} //CompositionConnectionImpl
