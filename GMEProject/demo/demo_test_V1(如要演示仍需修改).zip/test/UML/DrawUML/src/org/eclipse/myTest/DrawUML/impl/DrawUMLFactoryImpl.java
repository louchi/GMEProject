/**
 */
package org.eclipse.myTest.DrawUML.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.eclipse.myTest.DrawUML.AbstractConnection;
import org.eclipse.myTest.DrawUML.AbstractShape;
import org.eclipse.myTest.DrawUML.AggregationConnection;
import org.eclipse.myTest.DrawUML.AssociationConnection;
import org.eclipse.myTest.DrawUML.Attributes;
import org.eclipse.myTest.DrawUML.BasePanel;
import org.eclipse.myTest.DrawUML.ClassCopy;
import org.eclipse.myTest.DrawUML.ClassDiagram;
import org.eclipse.myTest.DrawUML.CompositionConnection;
import org.eclipse.myTest.DrawUML.ConnectorNode;
import org.eclipse.myTest.DrawUML.Constraint;
import org.eclipse.myTest.DrawUML.ConstraintDefinition;
import org.eclipse.myTest.DrawUML.DrawUMLFactory;
import org.eclipse.myTest.DrawUML.DrawUMLPackage;
import org.eclipse.myTest.DrawUML.Inheritance;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DrawUMLFactoryImpl extends EFactoryImpl implements DrawUMLFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DrawUMLFactory init() {
		try {
			DrawUMLFactory theDrawUMLFactory = (DrawUMLFactory)EPackage.Registry.INSTANCE.getEFactory(DrawUMLPackage.eNS_URI);
			if (theDrawUMLFactory != null) {
				return theDrawUMLFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new DrawUMLFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DrawUMLFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case DrawUMLPackage.CLASS: return createClass();
			case DrawUMLPackage.CLASS_COPY: return createClassCopy();
			case DrawUMLPackage.CLASS_DIAGRAM: return createClassDiagram();
			case DrawUMLPackage.CONNECTOR_NODE: return createConnectorNode();
			case DrawUMLPackage.INHERITANCE: return createInheritance();
			case DrawUMLPackage.ABSTRACT_SHAPE: return createAbstractShape();
			case DrawUMLPackage.ABSTRACT_CONNECTION: return createAbstractConnection();
			case DrawUMLPackage.ASSOCIATION_CONNECTION: return createAssociationConnection();
			case DrawUMLPackage.COMPOSITION_CONNECTION: return createCompositionConnection();
			case DrawUMLPackage.AGGREGATION_CONNECTION: return createAggregationConnection();
			case DrawUMLPackage.BASE_PANEL: return createBasePanel();
			case DrawUMLPackage.CONSTRAINT: return createConstraint();
			case DrawUMLPackage.CONSTRAINT_DEFINITION: return createConstraintDefinition();
			case DrawUMLPackage.ATTRIBUTES: return createAttributes();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public org.eclipse.myTest.DrawUML.Class createClass() {
		ClassImpl class_ = new ClassImpl();
		return class_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassCopy createClassCopy() {
		ClassCopyImpl classCopy = new ClassCopyImpl();
		return classCopy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassDiagram createClassDiagram() {
		ClassDiagramImpl classDiagram = new ClassDiagramImpl();
		return classDiagram;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConnectorNode createConnectorNode() {
		ConnectorNodeImpl connectorNode = new ConnectorNodeImpl();
		return connectorNode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Inheritance createInheritance() {
		InheritanceImpl inheritance = new InheritanceImpl();
		return inheritance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractShape createAbstractShape() {
		AbstractShapeImpl abstractShape = new AbstractShapeImpl();
		return abstractShape;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractConnection createAbstractConnection() {
		AbstractConnectionImpl abstractConnection = new AbstractConnectionImpl();
		return abstractConnection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AssociationConnection createAssociationConnection() {
		AssociationConnectionImpl associationConnection = new AssociationConnectionImpl();
		return associationConnection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CompositionConnection createCompositionConnection() {
		CompositionConnectionImpl compositionConnection = new CompositionConnectionImpl();
		return compositionConnection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AggregationConnection createAggregationConnection() {
		AggregationConnectionImpl aggregationConnection = new AggregationConnectionImpl();
		return aggregationConnection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BasePanel createBasePanel() {
		BasePanelImpl basePanel = new BasePanelImpl();
		return basePanel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Constraint createConstraint() {
		ConstraintImpl constraint = new ConstraintImpl();
		return constraint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConstraintDefinition createConstraintDefinition() {
		ConstraintDefinitionImpl constraintDefinition = new ConstraintDefinitionImpl();
		return constraintDefinition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Attributes createAttributes() {
		AttributesImpl attributes = new AttributesImpl();
		return attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DrawUMLPackage getDrawUMLPackage() {
		return (DrawUMLPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static DrawUMLPackage getPackage() {
		return DrawUMLPackage.eINSTANCE;
	}

} //DrawUMLFactoryImpl
