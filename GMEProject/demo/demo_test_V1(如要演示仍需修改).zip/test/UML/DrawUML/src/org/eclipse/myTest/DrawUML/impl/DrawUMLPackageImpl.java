/**
 */
package org.eclipse.myTest.DrawUML.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.myTest.DrawUML.AbstractConnection;
import org.eclipse.myTest.DrawUML.AbstractShape;
import org.eclipse.myTest.DrawUML.AggregationConnection;
import org.eclipse.myTest.DrawUML.AssociationConnection;
import org.eclipse.myTest.DrawUML.Attributes;
import org.eclipse.myTest.DrawUML.BasePanel;
import org.eclipse.myTest.DrawUML.ClassCopy;
import org.eclipse.myTest.DrawUML.ClassDiagram;
import org.eclipse.myTest.DrawUML.CompositionConnection;
import org.eclipse.myTest.DrawUML.ConnectorNode;
import org.eclipse.myTest.DrawUML.Constraint;
import org.eclipse.myTest.DrawUML.ConstraintDefinition;
import org.eclipse.myTest.DrawUML.DrawUMLFactory;
import org.eclipse.myTest.DrawUML.DrawUMLPackage;
import org.eclipse.myTest.DrawUML.Inheritance;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DrawUMLPackageImpl extends EPackageImpl implements DrawUMLPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass classEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass classCopyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass classDiagramEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass connectorNodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inheritanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractShapeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractConnectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass associationConnectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass compositionConnectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aggregationConnectionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass basePanelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass constraintEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass constraintDefinitionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributesEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private DrawUMLPackageImpl() {
		super(eNS_URI, DrawUMLFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link DrawUMLPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static DrawUMLPackage init() {
		if (isInited) return (DrawUMLPackage)EPackage.Registry.INSTANCE.getEPackage(DrawUMLPackage.eNS_URI);

		// Obtain or create and register package
		DrawUMLPackageImpl theDrawUMLPackage = (DrawUMLPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof DrawUMLPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new DrawUMLPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theDrawUMLPackage.createPackageContents();

		// Initialize created meta-data
		theDrawUMLPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theDrawUMLPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(DrawUMLPackage.eNS_URI, theDrawUMLPackage);
		return theDrawUMLPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClass_() {
		return classEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getClass_Include() {
		return (EReference)classEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClassCopy() {
		return classCopyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClassDiagram() {
		return classDiagramEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConnectorNode() {
		return connectorNodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInheritance() {
		return inheritanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractShape() {
		return abstractShapeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractShape_Name() {
		return (EAttribute)abstractShapeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractShape_Sources() {
		return (EReference)abstractShapeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractShape_Targets() {
		return (EReference)abstractShapeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractConnection() {
		return abstractConnectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractConnection_Name() {
		return (EAttribute)abstractConnectionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractConnection_From() {
		return (EReference)abstractConnectionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractConnection_To() {
		return (EReference)abstractConnectionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAssociationConnection() {
		return associationConnectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCompositionConnection() {
		return compositionConnectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAggregationConnection() {
		return aggregationConnectionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBasePanel() {
		return basePanelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBasePanel_HaveShapes() {
		return (EReference)basePanelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBasePanel_HaveConnections() {
		return (EReference)basePanelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConstraint() {
		return constraintEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConstraintDefinition() {
		return constraintDefinitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttributes() {
		return attributesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DrawUMLFactory getDrawUMLFactory() {
		return (DrawUMLFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		classEClass = createEClass(CLASS);
		createEReference(classEClass, CLASS__INCLUDE);

		classCopyEClass = createEClass(CLASS_COPY);

		classDiagramEClass = createEClass(CLASS_DIAGRAM);

		connectorNodeEClass = createEClass(CONNECTOR_NODE);

		inheritanceEClass = createEClass(INHERITANCE);

		abstractShapeEClass = createEClass(ABSTRACT_SHAPE);
		createEAttribute(abstractShapeEClass, ABSTRACT_SHAPE__NAME);
		createEReference(abstractShapeEClass, ABSTRACT_SHAPE__SOURCES);
		createEReference(abstractShapeEClass, ABSTRACT_SHAPE__TARGETS);

		abstractConnectionEClass = createEClass(ABSTRACT_CONNECTION);
		createEAttribute(abstractConnectionEClass, ABSTRACT_CONNECTION__NAME);
		createEReference(abstractConnectionEClass, ABSTRACT_CONNECTION__FROM);
		createEReference(abstractConnectionEClass, ABSTRACT_CONNECTION__TO);

		associationConnectionEClass = createEClass(ASSOCIATION_CONNECTION);

		compositionConnectionEClass = createEClass(COMPOSITION_CONNECTION);

		aggregationConnectionEClass = createEClass(AGGREGATION_CONNECTION);

		basePanelEClass = createEClass(BASE_PANEL);
		createEReference(basePanelEClass, BASE_PANEL__HAVE_SHAPES);
		createEReference(basePanelEClass, BASE_PANEL__HAVE_CONNECTIONS);

		constraintEClass = createEClass(CONSTRAINT);

		constraintDefinitionEClass = createEClass(CONSTRAINT_DEFINITION);

		attributesEClass = createEClass(ATTRIBUTES);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		classEClass.getESuperTypes().add(this.getAbstractShape());
		classCopyEClass.getESuperTypes().add(this.getAbstractShape());
		classDiagramEClass.getESuperTypes().add(this.getAbstractShape());
		connectorNodeEClass.getESuperTypes().add(this.getAbstractShape());
		inheritanceEClass.getESuperTypes().add(this.getAbstractShape());
		associationConnectionEClass.getESuperTypes().add(this.getAbstractConnection());
		compositionConnectionEClass.getESuperTypes().add(this.getAbstractConnection());
		aggregationConnectionEClass.getESuperTypes().add(this.getAbstractConnection());
		constraintEClass.getESuperTypes().add(this.getAbstractShape());
		constraintDefinitionEClass.getESuperTypes().add(this.getAbstractShape());

		// Initialize classes, features, and operations; add parameters
		initEClass(classEClass, org.eclipse.myTest.DrawUML.Class.class, "Class", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getClass_Include(), this.getAttributes(), null, "include", null, 0, 1, org.eclipse.myTest.DrawUML.Class.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(classCopyEClass, ClassCopy.class, "ClassCopy", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(classDiagramEClass, ClassDiagram.class, "ClassDiagram", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(connectorNodeEClass, ConnectorNode.class, "ConnectorNode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(inheritanceEClass, Inheritance.class, "Inheritance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(abstractShapeEClass, AbstractShape.class, "AbstractShape", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractShape_Name(), ecorePackage.getEString(), "name", null, 0, 1, AbstractShape.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractShape_Sources(), this.getAbstractConnection(), null, "sources", null, 0, -1, AbstractShape.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractShape_Targets(), this.getAbstractConnection(), null, "targets", null, 0, -1, AbstractShape.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractConnectionEClass, AbstractConnection.class, "AbstractConnection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractConnection_Name(), ecorePackage.getEString(), "name", null, 0, 1, AbstractConnection.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractConnection_From(), this.getAbstractShape(), null, "from", null, 0, 1, AbstractConnection.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractConnection_To(), this.getAbstractShape(), null, "to", null, 0, 1, AbstractConnection.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(associationConnectionEClass, AssociationConnection.class, "AssociationConnection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(compositionConnectionEClass, CompositionConnection.class, "CompositionConnection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(aggregationConnectionEClass, AggregationConnection.class, "AggregationConnection", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(basePanelEClass, BasePanel.class, "BasePanel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBasePanel_HaveShapes(), this.getAbstractShape(), null, "haveShapes", null, 0, -1, BasePanel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBasePanel_HaveConnections(), this.getAbstractConnection(), null, "haveConnections", null, 0, -1, BasePanel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(constraintEClass, Constraint.class, "Constraint", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(constraintDefinitionEClass, ConstraintDefinition.class, "ConstraintDefinition", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(attributesEClass, Attributes.class, "Attributes", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}

} //DrawUMLPackageImpl
