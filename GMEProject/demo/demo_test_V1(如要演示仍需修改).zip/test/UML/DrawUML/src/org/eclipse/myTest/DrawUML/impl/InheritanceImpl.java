/**
 */
package org.eclipse.myTest.DrawUML.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.myTest.DrawUML.DrawUMLPackage;
import org.eclipse.myTest.DrawUML.Inheritance;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Inheritance</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class InheritanceImpl extends AbstractShapeImpl implements Inheritance {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InheritanceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DrawUMLPackage.Literals.INHERITANCE;
	}

} //InheritanceImpl
