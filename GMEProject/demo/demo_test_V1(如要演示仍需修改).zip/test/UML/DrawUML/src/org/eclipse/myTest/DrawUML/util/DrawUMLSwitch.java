/**
 */
package org.eclipse.myTest.DrawUML.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import org.eclipse.myTest.DrawUML.AbstractConnection;
import org.eclipse.myTest.DrawUML.AbstractShape;
import org.eclipse.myTest.DrawUML.AggregationConnection;
import org.eclipse.myTest.DrawUML.AssociationConnection;
import org.eclipse.myTest.DrawUML.Attributes;
import org.eclipse.myTest.DrawUML.BasePanel;
import org.eclipse.myTest.DrawUML.ClassCopy;
import org.eclipse.myTest.DrawUML.ClassDiagram;
import org.eclipse.myTest.DrawUML.CompositionConnection;
import org.eclipse.myTest.DrawUML.ConnectorNode;
import org.eclipse.myTest.DrawUML.Constraint;
import org.eclipse.myTest.DrawUML.ConstraintDefinition;
import org.eclipse.myTest.DrawUML.DrawUMLPackage;
import org.eclipse.myTest.DrawUML.Inheritance;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see org.eclipse.myTest.DrawUML.DrawUMLPackage
 * @generated
 */
public class DrawUMLSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static DrawUMLPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DrawUMLSwitch() {
		if (modelPackage == null) {
			modelPackage = DrawUMLPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @parameter ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case DrawUMLPackage.CLASS: {
				org.eclipse.myTest.DrawUML.Class class_ = (org.eclipse.myTest.DrawUML.Class)theEObject;
				T result = caseClass(class_);
				if (result == null) result = caseAbstractShape(class_);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.CLASS_COPY: {
				ClassCopy classCopy = (ClassCopy)theEObject;
				T result = caseClassCopy(classCopy);
				if (result == null) result = caseAbstractShape(classCopy);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.CLASS_DIAGRAM: {
				ClassDiagram classDiagram = (ClassDiagram)theEObject;
				T result = caseClassDiagram(classDiagram);
				if (result == null) result = caseAbstractShape(classDiagram);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.CONNECTOR_NODE: {
				ConnectorNode connectorNode = (ConnectorNode)theEObject;
				T result = caseConnectorNode(connectorNode);
				if (result == null) result = caseAbstractShape(connectorNode);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.INHERITANCE: {
				Inheritance inheritance = (Inheritance)theEObject;
				T result = caseInheritance(inheritance);
				if (result == null) result = caseAbstractShape(inheritance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.ABSTRACT_SHAPE: {
				AbstractShape abstractShape = (AbstractShape)theEObject;
				T result = caseAbstractShape(abstractShape);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.ABSTRACT_CONNECTION: {
				AbstractConnection abstractConnection = (AbstractConnection)theEObject;
				T result = caseAbstractConnection(abstractConnection);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.ASSOCIATION_CONNECTION: {
				AssociationConnection associationConnection = (AssociationConnection)theEObject;
				T result = caseAssociationConnection(associationConnection);
				if (result == null) result = caseAbstractConnection(associationConnection);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.COMPOSITION_CONNECTION: {
				CompositionConnection compositionConnection = (CompositionConnection)theEObject;
				T result = caseCompositionConnection(compositionConnection);
				if (result == null) result = caseAbstractConnection(compositionConnection);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.AGGREGATION_CONNECTION: {
				AggregationConnection aggregationConnection = (AggregationConnection)theEObject;
				T result = caseAggregationConnection(aggregationConnection);
				if (result == null) result = caseAbstractConnection(aggregationConnection);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.BASE_PANEL: {
				BasePanel basePanel = (BasePanel)theEObject;
				T result = caseBasePanel(basePanel);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.CONSTRAINT: {
				Constraint constraint = (Constraint)theEObject;
				T result = caseConstraint(constraint);
				if (result == null) result = caseAbstractShape(constraint);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.CONSTRAINT_DEFINITION: {
				ConstraintDefinition constraintDefinition = (ConstraintDefinition)theEObject;
				T result = caseConstraintDefinition(constraintDefinition);
				if (result == null) result = caseAbstractShape(constraintDefinition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case DrawUMLPackage.ATTRIBUTES: {
				Attributes attributes = (Attributes)theEObject;
				T result = caseAttributes(attributes);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Class</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Class</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseClass(org.eclipse.myTest.DrawUML.Class object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Class Copy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Class Copy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseClassCopy(ClassCopy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Class Diagram</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Class Diagram</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseClassDiagram(ClassDiagram object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connector Node</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connector Node</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnectorNode(ConnectorNode object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Inheritance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Inheritance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInheritance(Inheritance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Abstract Shape</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Abstract Shape</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAbstractShape(AbstractShape object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Abstract Connection</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Abstract Connection</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAbstractConnection(AbstractConnection object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Association Connection</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Association Connection</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAssociationConnection(AssociationConnection object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Composition Connection</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Composition Connection</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCompositionConnection(CompositionConnection object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Aggregation Connection</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Aggregation Connection</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAggregationConnection(AggregationConnection object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Base Panel</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Base Panel</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBasePanel(BasePanel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Constraint</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Constraint</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConstraint(Constraint object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Constraint Definition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Constraint Definition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConstraintDefinition(ConstraintDefinition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attributes</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attributes</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttributes(Attributes object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //DrawUMLSwitch
