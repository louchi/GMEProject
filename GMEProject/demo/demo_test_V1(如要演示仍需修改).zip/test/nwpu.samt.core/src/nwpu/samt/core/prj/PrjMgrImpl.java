package nwpu.samt.core.prj;

import nwpu.samt.db.dao.PrjDao;
import nwpu.samt.db.dao.PrjDaoImpl;
import nwpu.samt.db.entity.Project;

public class PrjMgrImpl implements PrjMgr{
	
	PrjDao dao = new PrjDaoImpl();

	@Override
	public Project getCurrentPrj() {
		// TODO Auto-generated method stub
		return dao.readCurrentPrj();
	}

	@Override
	public void setCurrentPrj(Project prj) {
		// TODO Auto-generated method stub
		dao.saveCurrentPrj(prj);
	}

}
