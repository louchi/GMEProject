package nwpu.samt.db.dao;

import nwpu.samt.db.entity.Project;

public class PrjDaoImpl implements PrjDao {

	@Override
	public Project readCurrentPrj() {
		// TODO Auto-generated method stub
		return StaticObjectDb.getPrj();
	}

	@Override
	public void saveCurrentPrj(Project prj) {
		// TODO Auto-generated method stub
		StaticObjectDb.setPrj(prj);
	}

}
