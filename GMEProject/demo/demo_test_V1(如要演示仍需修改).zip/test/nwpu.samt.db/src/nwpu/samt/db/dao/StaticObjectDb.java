package nwpu.samt.db.dao;

import nwpu.samt.db.entity.Project;

/**
 * ��̬��
 * @author ��贳�
 * @version 1.0 2017-06-29
 *
 */
public class StaticObjectDb {
	/**
	 * ��ǰ�����ռ��е���Ŀ
	 */
	private static Project prj = null;

	/**
	 * @return the prj
	 */
	public static Project getPrj() {
		return prj;
	}

	/**
	 * @param prj the prj to set
	 */
	public static void setPrj(Project prj) {
		StaticObjectDb.prj = prj;
	}
	
	

}
