package nwpu.samt.db.entity;

/**
 * ��Ŀ
 * @author LLC
 *
 */
public class Project {
	/**
	 * ��Ŀ����
	 */
	private String name;
	
	/**
	 * ��Ŀ����
	 */
	private String desc;
	
	/**
	 * ��Ŀ·��
	 */
	private String path;
	
	/**
	 * ����
	 */
	private String author;
	
	/**
	 * �汾
	 */
	private String version;
	
	/**
	 * ����ʱ��
	 */
	private String createDate;
	
	/**
	 * �޸�ʱ��
	 */
	private String modifyDate;
	
	/**
	 * ��ʽ
	 */
	private String paradigm;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the modifyDate
	 */
	public String getModifyDate() {
		return modifyDate;
	}

	/**
	 * @param modifyDate the modifyDate to set
	 */
	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	/**
	 * @return the paradigm
	 */
	public String getParadigm() {
		return paradigm;
	}

	/**
	 * @param paradigm the paradigm to set
	 */
	public void setParadigm(String paradigm) {
		this.paradigm = paradigm;
	}
	
}
