package nwpu.samt.launcher.intro;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import nwpu.samt.core.prj.PrjMgr;
import nwpu.samt.core.prj.PrjMgrImpl;
import nwpu.samt.db.entity.Project;
import nwpu.samt.launcher.Activator;
import nwpu.samt.ui.common.perspectives.InitPerspective;
import nwpu.samt.ui.face.dlgs.NewFaceDialog;
import nwpu.samt.ui.uml.dlgs.NewUmlDialog;
import nwpu.samt.util.general.Util;
import nwpu.samt.util.i18n.I18nManager;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IPerspectiveDescriptor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.WorkbenchException;
import org.eclipse.ui.part.IntroPart;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;

import swing2swt.layout.BorderLayout;

public class WelcomeIntro extends IntroPart {
	/**
	 * shell
	 */
	private Shell shell;

	/**
	 * ���ʻ�
	 */
	I18nManager manager = I18nManager.getInstance(Activator.PLUGIN_ID);
	/**
	 * ��ӭҳ�����
	 */
	private Label titleLabel;
	private Label prjTypeLabel;
	private Button umlBtn;

	@Override
	public void standbyStateChanged(boolean standby) {
		// TODO Auto-generated method stub

	}

	/**
	 * @wbp.parser.entryPoint
	 */
	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new BorderLayout(0, 0));

		Composite leftComp = new Composite(container, SWT.NONE);
		leftComp.setLayoutData(BorderLayout.WEST);
		leftComp.setLayout(new GridLayout(2, false));

		Label label_3 = new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);

		Button button = new Button(leftComp, SWT.NONE);
		GridData gd_button = new GridData(SWT.LEFT, SWT.CENTER, false, false,
				1, 1);
		gd_button.heightHint = 120;
		gd_button.widthHint = 160;
		button.setLayoutData(gd_button);
		button.setImage(ResourceManager.getPluginImage("nwpu.samt.launcher",
				"icons/welcome/logo.jpg"));
		new Label(leftComp, SWT.NONE);

		Label label_1 = new Label(leftComp, SWT.NONE);
		GridData gd_label_1 = new GridData(SWT.FILL, SWT.CENTER, false, false,
				1, 1);
		gd_label_1.widthHint = 189;
		label_1.setLayoutData(gd_label_1);
		label_1.setText("\u6700\u8FD1\u6253\u5F00\u9879\u76EE");
		label_1.setFont(SWTResourceManager.getFont("΢���ź�", 13, SWT.BOLD));
		new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);

		Label lblEcewcwcewcwsound = new Label(leftComp, SWT.NONE);
		lblEcewcwcewcwsound.setLayoutData(new GridData(SWT.LEFT, SWT.TOP,
				false, false, 1, 1));
		lblEcewcwcewcwsound.setText("\u6A21\u578B1");
		lblEcewcwcewcwsound.setFont(SWTResourceManager.getFont("΢���ź�", 12,
				SWT.NORMAL));
		new Label(leftComp, SWT.NONE);

		Label lblEcewcwcewcwsound_1 = new Label(leftComp, SWT.NONE);
		lblEcewcwcewcwsound_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER,
				true, false, 1, 1));
		lblEcewcwcewcwsound_1
				.setText("E:\\\u8C37\u6B4C\u4E0B\u8F7D\\cewcw\\cewcw\\sound\\test1");
		new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);

		Label label_4 = new Label(leftComp, SWT.NONE);
		label_4.setText("\u6A21\u578B2");
		label_4.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		new Label(leftComp, SWT.NONE);

		Label label_5 = new Label(leftComp, SWT.NONE);
		label_5.setText("E:\\\u8C37\u6B4C\u4E0B\u8F7D\\cewcw\\cewcw\\sound\\test1");
		new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);

		Label label_6 = new Label(leftComp, SWT.NONE);
		label_6.setText("\u6A21\u578B3");
		label_6.setFont(SWTResourceManager.getFont("΢���ź�", 12, SWT.NORMAL));
		new Label(leftComp, SWT.NONE);

		Label label_7 = new Label(leftComp, SWT.NONE);
		label_7.setText("E:\\\u8C37\u6B4C\u4E0B\u8F7D\\cewcw\\cewcw\\sound\\test1");
		new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);
		new Label(leftComp, SWT.NONE);

		Label label_2 = new Label(leftComp, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_2.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false,
				1, 1));
		new Label(leftComp, SWT.NONE);

		Composite composite = new Composite(leftComp, SWT.NONE);
		GridData gd_composite = new GridData(SWT.FILL, SWT.CENTER, true, false,
				1, 1);
		gd_composite.widthHint = 170;
		composite.setLayoutData(gd_composite);

		Button openOtherBtn = new Button(composite, SWT.NONE);
		openOtherBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				openOtherBtnWidgetSelected(evt);
			}
		});
		openOtherBtn.setFont(SWTResourceManager.getFont("΢���ź�", 11, SWT.BOLD));
		openOtherBtn.setAlignment(SWT.LEFT);
		openOtherBtn.setImage(ResourceManager.getPluginImage(
				"nwpu.samt.launcher", "icons/welcome/file.png"));
		openOtherBtn.setBounds(0, 0, 169, 27);

		Composite centerComp = new Composite(container, SWT.NONE);
		centerComp.setLayoutData(BorderLayout.CENTER);
		centerComp.setLayout(new GridLayout(2, false));
		new Label(centerComp, SWT.NONE);

		Label label = new Label(centerComp, SWT.NONE);

		Label lblNewLabel = new Label(centerComp, SWT.NONE);
		GridData gd_lblNewLabel = new GridData(SWT.LEFT, SWT.CENTER, false,
				false, 1, 1);
		gd_lblNewLabel.widthHint = 36;
		lblNewLabel.setLayoutData(gd_lblNewLabel);

		titleLabel = new Label(centerComp, SWT.WRAP);
		titleLabel.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true,
				false, 1, 1));
		titleLabel.setFont(SWTResourceManager.getFont("����", 25, SWT.BOLD
				| SWT.ITALIC));
		titleLabel
				.setText("\u6B22\u8FCE\u4F7F\u7528\u6EE1\u8DB3\u5F00\u653E\u5F0F\u67B6\u6784\u7684\u8F6F\u4EF6\u67B6\u6784\u5EFA\u6A21\u5DE5\u5177");
		new Label(centerComp, SWT.NONE);
		new Label(centerComp, SWT.NONE);
		new Label(centerComp, SWT.NONE);

		prjTypeLabel = new Label(centerComp, SWT.NONE);
		prjTypeLabel
				.setFont(SWTResourceManager.getFont("΢���ź�", 15, SWT.NORMAL));
		prjTypeLabel.setText("\u9879\u76EE\u7C7B\u522B");
		new Label(centerComp, SWT.NONE);

		Composite prjTypeListComp = new Composite(centerComp, SWT.NONE);
		prjTypeListComp.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true,
				true, 1, 1));

		umlBtn = new Button(prjTypeListComp, SWT.NONE);
		umlBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				umlBtnWidgetSelected(evt);
			}
		});
		umlBtn.setLocation(0, 10);
		umlBtn.setImage(ResourceManager.getPluginImage("nwpu.samt.launcher",
				"icons/welcome/uml-start.png"));
		umlBtn.setSize(200, 167);

		Button faceBtn = new Button(prjTypeListComp, SWT.NONE);
		faceBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				faceBtnWidgetSelected(evt);
			}
		});
		faceBtn.setImage(ResourceManager.getPluginImage("nwpu.samt.launcher",
				"icons/welcome/uml-start.png"));
		faceBtn.setBounds(235, 10, 200, 167);

		Label umlLabel = new Label(prjTypeListComp, SWT.NONE);
		umlLabel.setFont(SWTResourceManager.getFont("΢���ź�", 15, SWT.BOLD));
		umlLabel.setBounds(76, 183, 61, 36);
		umlLabel.setText("UML");

		Label lblFace = new Label(prjTypeListComp, SWT.NONE);
		lblFace.setText("FACE");
		lblFace.setFont(SWTResourceManager.getFont("΢���ź�", 15, SWT.BOLD));
		lblFace.setBounds(314, 183, 61, 36);

		init();
		initI18n();
	}

	/**
	 * ��ʼ��
	 */
	private void init() {
		shell = nwpu.samt.util.general.Util.getShell();
	}

	/**
	 * ���ʻ�
	 */
	private void initI18n() {
		// TODO
	}

	/**
	 * ����������
	 * 
	 * @param evt
	 *            ����¼�
	 */
	protected void openOtherBtnWidgetSelected(SelectionEvent evt) {
		// TODO Auto-generated method stub
		FileDialog fileDialog = new FileDialog(shell, SWT.OPEN);
		String s = fileDialog.open();
		System.out.println("��������Ŀ��" + s);
		if (!s.equals("") && s != null) {
			
			Project prj = new Project();
			prj.setName("��Ŀ1");
			prj.setPath("E:\\������Ŀ yu ����\\1��GME���߿���\\�ĵ�");		
			
			Calendar ca = Calendar.getInstance();
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
			System.out.println(df.format(ca.getTime()));// new Date()Ϊ��ȡ��ǰϵͳʱ��
			prj.setCreateDate(df.format(ca.getTime()));
			prj.setParadigm("face");
			
			PrjMgr prjMgr = new PrjMgrImpl();
			prjMgr .setCurrentPrj(prj);
			
			IWorkbench workbench = Util.getWorkbench();
			IWorkbenchPage iworkbenchPage = workbench.getActiveWorkbenchWindow()
					.getActivePage();
			IPerspectiveDescriptor perspective = workbench.getPerspectiveRegistry()
					.findPerspectiveWithId(InitPerspective.ID); // perspective ��id
			iworkbenchPage.closeAllPerspectives(false, true);
			iworkbenchPage.setPerspective(perspective);
		}
	}

	protected void umlBtnWidgetSelected(SelectionEvent evt) {
		// TODO Auto-generated method stub
		NewUmlDialog newUmlDialog = new NewUmlDialog(shell, SWT.NONE);
		newUmlDialog.open();
	}

	protected void faceBtnWidgetSelected(SelectionEvent evt) {
		// TODO Auto-generated method stub
		NewFaceDialog newFaceDialog = new NewFaceDialog(shell, SWT.NONE);
		newFaceDialog.open();
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

	@Override
	public String getTitle() {
		return manager.getString("welcome");
	}

	@Override
	public Image getTitleImage() {
		// TODO Auto-generated method stub
		return super.getTitleImage();
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		openPerspective(InitPerspective.ID);
		super.dispose();
	}

	private void openPerspective(String id) {
//		IWorkbench workbench = PlatformUI.getWorkbench();
////		IWorkbenchPage iworkbenchPage = workbench.getActiveWorkbenchWindow()
////				.getActivePage();
////		IPerspectiveDescriptor perspective = workbench.getPerspectiveRegistry()
////				.findPerspectiveWithId(id); // perspective ��id
////		iworkbenchPage.closeAllPerspectives(false, true);
////		iworkbenchPage.setPerspective(perspective);
//		try {
//			workbench.showPerspective(id, workbench.getActiveWorkbenchWindow());
//		} catch (WorkbenchException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
	}
}
