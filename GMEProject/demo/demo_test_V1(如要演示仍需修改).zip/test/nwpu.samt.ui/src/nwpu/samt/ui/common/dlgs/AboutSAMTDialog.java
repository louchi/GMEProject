package nwpu.samt.ui.common.dlgs;

import nwpu.samt.util.general.Util;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.swt.widgets.Label;

/**
 * ���ڱ����ٶԻ�����ʵ��
 * @author ��贳�
 *
 */
public class AboutSAMTDialog extends Dialog {

	protected Object result;
	protected Shell shell;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public AboutSAMTDialog(Shell parent, int style) {
		super(parent, style);
		setText("���ڱ�����");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
		shell.setSize(450, 235);
		shell.setText(getText());
		
		Button button = new Button(shell, SWT.NONE);
		button.setImage(ResourceManager.getPluginImage("nwpu.samt.ui", "images/logo.jpg"));
		button.setBounds(129, 27, 168, 123);
		
		Label label = new Label(shell, SWT.NONE);
		label.setBounds(150, 168, 168, 17);
		label.setText("\u7248\u6743\u6240\u6709@\u897F\u5317\u5DE5\u4E1A\u5927\u5B66");
		
		Util.setShellMiddle(shell);

	}
}
