package nwpu.samt.ui.common.dlgs;

import nwpu.samt.core.prj.PrjMgr;
import nwpu.samt.core.prj.PrjMgrImpl;
import nwpu.samt.util.general.Util;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class PrjPropertyDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text prjNameText;
	private Text prjPathText;
	private Text versionText;
	private Text createTimeText;
	private Text modifyTiemText;
	private Text templeteText;
	private Label prjNameLabel;
	private Label prjPathLabel;
	private Label authorLabel;
	private Text authorText;
	private Label versionLabel;
	private Label createTimeLabel;
	private Label modifyTimeLabel;
	private Label templeteLabel;
	private Button okBtn;
	private Button cancelBtn;
	
	private PrjMgr prjMgr = new PrjMgrImpl();

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public PrjPropertyDialog(Shell parent, int style) {
		super(parent, style);
		setText("��Ŀ��������");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
		shell.setSize(530, 460);
		shell.setText(getText());
		shell.setLayout(new GridLayout(5, false));
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		prjNameLabel = new Label(shell, SWT.NONE);
		prjNameLabel.setText("\u9879\u76EE\u540D\u79F0");
		new Label(shell, SWT.NONE);
		
		prjNameText = new Text(shell, SWT.BORDER);
		prjNameText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Label label = new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		prjPathLabel = new Label(shell, SWT.NONE);
		prjPathLabel.setText("\u9879\u76EE\u8DEF\u5F84");
		new Label(shell, SWT.NONE);
		
		prjPathText = new Text(shell, SWT.BORDER);
		prjPathText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		authorLabel = new Label(shell, SWT.NONE);
		authorLabel.setText("\u4F5C\u8005");
		new Label(shell, SWT.NONE);
		
		authorText = new Text(shell, SWT.BORDER);
		authorText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		versionLabel = new Label(shell, SWT.NONE);
		versionLabel.setText("\u7248\u672C");
		new Label(shell, SWT.NONE);
		
		versionText = new Text(shell, SWT.BORDER);
		versionText.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, true, 1, 1));
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		createTimeLabel = new Label(shell, SWT.NONE);
		createTimeLabel.setText("\u521B\u5EFA\u65F6\u95F4");
		new Label(shell, SWT.NONE);
		
		createTimeText = new Text(shell, SWT.BORDER);
		createTimeText.setEnabled(false);
		createTimeText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		modifyTimeLabel = new Label(shell, SWT.NONE);
		modifyTimeLabel.setText("\u4FEE\u6539\u65F6\u95F4");
		new Label(shell, SWT.NONE);
		
		modifyTiemText = new Text(shell, SWT.BORDER);
		modifyTiemText.setEnabled(false);
		modifyTiemText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		templeteLabel = new Label(shell, SWT.NONE);
		templeteLabel.setText("\u8303\u5F0F");
		new Label(shell, SWT.NONE);
		
		templeteText = new Text(shell, SWT.BORDER);
		templeteText.setEnabled(false);
		templeteText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		Composite composite = new Composite(shell, SWT.NONE);
		
		okBtn = new Button(composite, SWT.NONE);
		okBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				okBtnWidgetSelected(evt);
			}
		});
		okBtn.setBounds(200, 0, 80, 27);
		okBtn.setText("\u786E\u5B9A");
		
		cancelBtn = new Button(composite, SWT.NONE);
		cancelBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				cancelBtnWidgetSelected(evt);
			}
		});
		cancelBtn.setBounds(300, 0, 80, 27);
		cancelBtn.setText("\u53D6\u6D88");
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		Label label_5 = new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		Util.setShellMiddle(shell);
		init();
	}
	
	private void init() {
		if (prjMgr.getCurrentPrj() != null) {
			createTimeText.setText(prjMgr.getCurrentPrj().getCreateDate());
			prjNameText.setText(prjMgr.getCurrentPrj().getName());
			prjPathText.setText(prjMgr.getCurrentPrj().getPath());
			templeteText.setText(prjMgr.getCurrentPrj().getParadigm());
		}
	}

	protected void okBtnWidgetSelected(SelectionEvent evt) {
		// TODO Auto-generated method stub
		MessageDialog.openInformation(shell, "��ʾ", "������Ϣ�ɹ�");
		shell.dispose();
	}

	protected void cancelBtnWidgetSelected(SelectionEvent evt) {
		// TODO Auto-generated method stub
		shell.dispose();
	}
}
