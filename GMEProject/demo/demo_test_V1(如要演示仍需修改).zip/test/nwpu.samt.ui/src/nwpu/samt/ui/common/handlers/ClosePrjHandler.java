package nwpu.samt.ui.common.handlers;

import nwpu.samt.core.prj.PrjMgr;
import nwpu.samt.core.prj.PrjMgrImpl;
import nwpu.samt.ui.common.perspectives.InitPerspective;
import nwpu.samt.util.general.Util;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.ui.IPerspectiveDescriptor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;

public class ClosePrjHandler implements IHandler {
	PrjMgr prjMgr = new PrjMgrImpl();

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		
		// TODO Auto-generated method stub
		System.out.println("�ر���Ŀ-------");
		prjMgr.setCurrentPrj(null);
		
		IWorkbench workbench = Util.getWorkbench();
		IWorkbenchPage iworkbenchPage = workbench.getActiveWorkbenchWindow()
				.getActivePage();
		IPerspectiveDescriptor perspective = workbench.getPerspectiveRegistry()
				.findPerspectiveWithId(InitPerspective.ID); // perspective ��id
		iworkbenchPage.closeAllPerspectives(false, true);
		iworkbenchPage.setPerspective(perspective);
		return null;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isHandled() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

}
