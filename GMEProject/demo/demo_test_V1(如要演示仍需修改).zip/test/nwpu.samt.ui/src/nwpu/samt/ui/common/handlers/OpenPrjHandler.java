package nwpu.samt.ui.common.handlers;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import nwpu.samt.core.prj.PrjMgr;
import nwpu.samt.core.prj.PrjMgrImpl;
import nwpu.samt.db.entity.Project;
import nwpu.samt.ui.common.perspectives.InitPerspective;
import nwpu.samt.util.general.Util;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IPerspectiveDescriptor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;

public class OpenPrjHandler implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		// TODO Auto-generated method stub
		FileDialog dialog = new FileDialog(Util.getShell(), SWT.OPEN);
		String s = dialog.open();
		System.out.println("��������Ŀ��" + s);
		if (!s.equals("") && s!= null) {
			
			Project prj = new Project();
			prj.setName("��Ŀ2");
			prj.setPath("E:\\������Ŀ yu ����\\1��GME���߿���\\�ĵ�");		
			
			Calendar ca = Calendar.getInstance();
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
			System.out.println(df.format(ca.getTime()));// new Date()Ϊ��ȡ��ǰϵͳʱ��
			prj.setCreateDate(df.format(ca.getTime()));
			prj.setParadigm("face");
			
			PrjMgr prjMgr = new PrjMgrImpl();
			prjMgr.setCurrentPrj(prj);
			
			IWorkbench workbench = Util.getWorkbench();
			IWorkbenchPage iworkbenchPage = workbench.getActiveWorkbenchWindow()
					.getActivePage();
			IPerspectiveDescriptor perspective = workbench.getPerspectiveRegistry()
					.findPerspectiveWithId(InitPerspective.ID); // perspective ��id
			iworkbenchPage.closeAllPerspectives(false, true);
			iworkbenchPage.setPerspective(perspective);
		}
		return null;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isHandled() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

}
