package nwpu.samt.ui.common.perspectives;

import nwpu.samt.ui.common.views.ConsoleView;
import nwpu.samt.ui.common.views.PropertyView;
import nwpu.samt.ui.common.views.ResourceManagerView;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;
import org.eclipse.ui.console.IConsoleConstants;

public class InitPerspective implements IPerspectiveFactory {
	public static final String ID = "nwpu.samt.ui.common.perspectives.initPerspective";

	/**
	 * Creates the initial layout for a page.
	 */
	public void createInitialLayout(IPageLayout layout) {
		String editorArea = layout.getEditorArea();
		addFastViews(layout);
		addViewShortcuts(layout);
		addPerspectiveShortcuts(layout);
	}

	/**
	 * Add fast views to the perspective.
	 */
	private void addFastViews(IPageLayout layout) {
		// �༭����
		String editorArea = layout.getEditorArea();
		layout.addView(ResourceManagerView.ID, IPageLayout.LEFT, 0.2f, editorArea);		
//		layout.addView(GraphicElementView.ID, IPageLayout.RIGHT, 0.8f, editorArea);
		
		IFolderLayout leftBottomFolder = layout.createFolder("leftBottomInfoFolder", IPageLayout.BOTTOM, 0.6f, ResourceManagerView.ID);
		leftBottomFolder.addView(IPageLayout.ID_OUTLINE);
		
		IFolderLayout bottomFolder = layout.createFolder("bottomInfoFolder", IPageLayout.BOTTOM, 0.8f, editorArea);
		bottomFolder.addView(ConsoleView.ID);
//		bottomFolder.addView(IConsoleConstants.ID_CONSOLE_VIEW);
		bottomFolder.addView(IPageLayout.ID_PROP_SHEET);
		bottomFolder.addView(PropertyView.ID);
	}

	/**
	 * Add view shortcuts to the perspective.
	 */
	private void addViewShortcuts(IPageLayout layout) {
	}

	/**
	 * Add perspective shortcuts to the perspective.
	 */
	private void addPerspectiveShortcuts(IPageLayout layout) {
	}

}
