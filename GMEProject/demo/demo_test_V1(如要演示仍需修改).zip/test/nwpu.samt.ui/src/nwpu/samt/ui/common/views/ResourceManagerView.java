package nwpu.samt.ui.common.views;

import java.io.File;
import java.lang.reflect.InvocationTargetException;

import nwpu.samt.core.prj.PrjMgr;
import nwpu.samt.core.prj.PrjMgrImpl;
import nwpu.samt.ui.util.TreeContentProvider;
import nwpu.samt.ui.util.TreeLabelProvider;
import nwpu.samt.ui.util.TreeNode;
import nwpu.samt.ui.util.TreeRightclickActionGroup;
import nwpu.samt.util.general.Util;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.common.ui.URIEditorInput;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.myTest.PDM.diagram.part.MyPDMCreationWizard;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.part.ViewPart;

public class ResourceManagerView extends ViewPart {

	public static final String ID = "nwpu.samt.ui.common.views.ResourceManagerView"; //$NON-NLS-1$

	TreeViewer treeViewer;

	Tree tree;

	PrjMgr prjMgr = new PrjMgrImpl();

	public Shell shell = Util.getShell();

	protected Resource diagram;

	int i = 0;

	public ResourceManagerView() {
	}

	/**
	 * Create contents of the view part.
	 * 
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new FillLayout(SWT.HORIZONTAL));

		treeViewer = new TreeViewer(container, SWT.BORDER);
		treeViewer.setContentProvider(new TreeContentProvider());
		treeViewer.setLabelProvider(new TreeLabelProvider());

		if (prjMgr.getCurrentPrj() != null) {
			if (prjMgr.getCurrentPrj().getParadigm().equals("uml")) {
				initUML();
			} else {
				initFACE();
			}
		}

		initMouseClick();

		createActions();
		initializeToolBar();
		initializeMenu();

	}

	private void initMouseClick() {
		// TODO Auto-generated method stub
		tree = treeViewer.getTree();
		tree.addMouseListener(new MouseListener() {

			@Override
			public void mouseUp(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseDown(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseDoubleClick(MouseEvent e) {
				// TODO Auto-generated method stub
				TreeNode node = null;

				Object o = e.getSource();
				if (o instanceof Tree) {
					Tree tree = (Tree) o;
					node = (TreeNode) tree.getSelection()[0].getData();
				}

//				 if (node!=null&&node.getKind().equals("DataModel")) {
//					 if (prjMgr.getCurrentPrj() != null
//					 && prjMgr.getCurrentPrj().getParadigm().equals("face")) {
//					 MyPDMCreationWizard wizard = new MyPDMCreationWizard();
//					 wizard.init(Util.getWorkbench(), StructuredSelection.EMPTY);
//					 WizardDialog wizardDialog = new WizardDialog(Util
//					 .getShell(), wizard);
//					 wizardDialog.open();
//				 }}

				// openEditor();
				
				if (!node.getType().equals("Model")) {  // �ڵ����Ͳ�λModel�����ô򿪱༭��
					return;
				}
				
				String filePath = node.getSubnodefilepath();
				if(filePath.equals("") || filePath==null) {
					filePath = prjMgr.getCurrentPrj().getPath()
							+ File.separator + prjMgr.getCurrentPrj().getName()
							+ File.separator + "default" + (++i)
							+ ".pdm_diagram";
				}
				// String filePath = "C:\\Users\\LLC\\Desktop\\default"+ (++i)
				// +".drawuml_diagram";
				File file = new File(filePath);
				if (file.exists()) {
					// �ļ����ڣ��򿪶�Ӧ�ļ�
					openEditorByURI(URI.createFileURI(filePath));
				} else {
					// �ļ������ڣ�������Ӧ���ļ�
					openEditor(filePath);
				}

			}
		});

	}

	/**
	 * @generated
	 */
	private boolean openNewlyCreatedDiagramEditor = true;

	/**
	 * @generated
	 */
	public final boolean isOpenNewlyCreatedDiagramEditor() {
		return openNewlyCreatedDiagramEditor;
	}

	/**
	 * @generated
	 */
	public void setOpenNewlyCreatedDiagramEditor(
			boolean openNewlyCreatedDiagramEditor) {
		this.openNewlyCreatedDiagramEditor = openNewlyCreatedDiagramEditor;
	}

	private boolean openEditor(final String filePath) {
		IRunnableWithProgress op = new WorkspaceModifyOperation(null) {

			protected void execute(IProgressMonitor monitor)
					throws CoreException, InterruptedException {
				diagram = org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorUtil
						.createDiagram(URI.createFileURI(filePath),
								URI.createFileURI(filePath.replace("_diagram",
										"")), monitor);
				if (isOpenNewlyCreatedDiagramEditor() && diagram != null) {
					try {
						org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorUtil
								.openDiagram(diagram);
					} catch (PartInitException e) {
						ErrorDialog
								.openError(
										shell,
										org.eclipse.myTest.PDM.diagram.part.Messages.MyPDMCreationWizardOpenEditorError,
										null, e.getStatus());
					}
				}
			}
		};
		try {
			new ProgressMonitorDialog(shell).run(false, true, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			if (e.getTargetException() instanceof CoreException) {
				ErrorDialog
						.openError(
								shell,
								org.eclipse.myTest.PDM.diagram.part.Messages.MyPDMCreationWizardCreationError,
								null, ((CoreException) e.getTargetException())
										.getStatus());
			} else {
				org.eclipse.myTest.PDM.diagram.part.MyPDMDiagramEditorPlugin
						.getInstance()
						.logError(
								"Error creating diagram", e.getTargetException()); //$NON-NLS-1$
			}
			return false;
		}
		return diagram != null;
	}

	private static boolean openEditorByURI(URI fileURI) {
		IWorkbench workbench = Util.getWorkbench();
		IWorkbenchWindow workbenchWindow = workbench.getActiveWorkbenchWindow();
		IWorkbenchPage page = workbenchWindow.getActivePage();
		IEditorDescriptor editorDescriptor = workbench.getEditorRegistry()
				.getDefaultEditor(fileURI.toFileString());
		if (editorDescriptor == null) {
			MessageDialog
					.openError(
							workbenchWindow.getShell(),
							org.eclipse.myTest.PDM.diagram.part.Messages.DiagramEditorActionBarAdvisor_DefaultFileEditorTitle,
							NLS.bind(
									org.eclipse.myTest.PDM.diagram.part.Messages.DiagramEditorActionBarAdvisor_DefaultFileEditorMessage,
									fileURI.toFileString()));
			return false;
		} else {
			try {
				page.openEditor(new URIEditorInput(fileURI),
						editorDescriptor.getId());
			} catch (PartInitException exception) {
				MessageDialog
						.openError(
								workbenchWindow.getShell(),
								org.eclipse.myTest.PDM.diagram.part.Messages.DiagramEditorActionBarAdvisor_DefaultEditorOpenErrorTitle,
								exception.getMessage());
				return false;
			}
		}
		return true;
	}

	private void initUML() {
		TreeNode nn = new TreeNode();
		nn.setName("geng");

		TreeNode root = new TreeNode();
		root.setName(prjMgr.getCurrentPrj().getName() + "_UML");
		root.setKind("root");

		nn.addChild(root);
		treeViewer.setInput(nn);

		treeViewer.addSelectionChangedListener(new ISelectionChangedListener() {

			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				// TODO Auto-generated method stub
				TreeRightclickActionGroup actionGroup = new TreeRightclickActionGroup(
						treeViewer);// ����һ��ActionGroup����
				actionGroup.fillContextMenu(new MenuManager());// ����ťע�뵽�˵�������
			}
		});
		treeViewer.expandAll();
		treeViewer.refresh();
	}

	private void initFACE() {

		if (prjMgr.getCurrentPrj() == null
				|| prjMgr.getCurrentPrj().equals(null)) {
			System.out.println("--------------------");
			return;
		}
		// TODO Auto-generated method stub
		TreeNode nn = new TreeNode();
		nn.setName("geng");

		TreeNode root = new TreeNode();
		root.setName(prjMgr.getCurrentPrj().getName() + "_FACE");
		root.setType("Folder");
		root.setKind("RootFolder");

		TreeNode c1 = new TreeNode();
		c1.setName("COPʾ��ϵͳ");
		c1.setType("Model");
		c1.setKind("ARINC653OperatingSystem");
		c1.setSubnodefilepath("C:\\Users\\llc\\Desktop\\copdemo\\COPDemoSystem.pdm_diagram");
		TreeNode c11 = new TreeNode();
		c11.setName("COP����");
		c11.setType("Model");
		c11.setKind("ARINC653Partition");
		TreeNode c12 = new TreeNode();
		c12.setName("GPS����");
		c12.setType("Model");
		c12.setKind("ARINC653Partition");
		TreeNode c13 = new TreeNode();
		c13.setName("MapServer����");
		c13.setType("Model");
		c13.setKind("ARINC653Partition");
		TreeNode c14 = new TreeNode();
		c14.setName("Ownship����");
		c14.setType("Model");
		c14.setKind("ARINC653Partition");
		TreeNode c15 = new TreeNode();
		c15.setName("����ͨ��A");
		c15.setType("Atom");
		c15.setKind("QueuingChannel");
		TreeNode c16 = new TreeNode();
		c16.setName("����ͨ��B");
		c16.setType("Atom");
		c16.setKind("QueuingChannel");
		TreeNode c17 = new TreeNode();
		c17.setName("����ͨ��C");
		c17.setType("Atom");
		c17.setKind("QueuingChannel");
		c1.addChild(c11);
		c1.addChild(c12);
		c1.addChild(c13);
		c1.addChild(c14);
		c1.addChild(c15);
		c1.addChild(c16);
		c1.addChild(c17);

		TreeNode c2 = new TreeNode();
		c2.setName("COPʾ������ģ��");
		c2.setType("Model");
		c2.setKind("DataModel");
		c2.setSubnodefilepath("C:\\Users\\llc\\Desktop\\copdemo\\defaultDataModel.pdm_diagram");
		TreeNode c21 = new TreeNode();
		c21.setFatherNode(c2);
		c21.setName("��������ģ��");
		c21.setType("Model");
		c21.setKind("ConceptualDataModel");
		TreeNode c22 = new TreeNode();
		c22.setFatherNode(c2);
		c22.setName("�߼�����ģ��");
		c22.setType("Model");
		c22.setKind("LogicalDataModel");
		TreeNode c23 = new TreeNode();
		c23.setFatherNode(c2);
		c23.setName("ƽ̨����ģ��");
		c23.setType("Model");
		c23.setKind("PlatformDataModel");
		TreeNode c24 = new TreeNode();
		c24.setFatherNode(c2);
		c24.setName("����ֲ����ģ��");
		c24.setType("Model");
		c24.setKind("UoPModel");
		c2.addChild(c21);
		c2.addChild(c22);
		c2.addChild(c23);
		c2.addChild(c24);

		TreeNode c3 = new TreeNode();
		c3.setName("����ʾ��ϵͳMQ");
		c3.setType("Model");
		c3.setKind("POSIXOperatingSystem");
		c3.setSubnodefilepath("C:\\Users\\llc\\Desktop\\copdemo\\GuidanceDemoMQ.pdm_diagram");

		TreeNode c4 = new TreeNode();
		c4.setName("����ʾ��ϵͳSHM");
		c4.setType("Model");
		c4.setKind("POSIXOperatingSystem");
		c4.setSubnodefilepath("C:\\Users\\llc\\Desktop\\copdemo\\GuidanceDemoSHM.pdm_diagram");
		
		TreeNode c5 = new TreeNode();
		c5.setName("����ʾ��ϵͳTCP");
		c5.setType("Model");
		c5.setKind("POSIXOperatingSystem");
		c5.setSubnodefilepath("C:\\Users\\llc\\Desktop\\copdemo\\GuidanceDemoTCP.pdm_diagram");
		
		TreeNode c6 = new TreeNode();
		c6.setName("����ʾ��ϵͳUDP");
		c6.setType("Model");
		c6.setKind("POSIXOperatingSystem");
		c6.setSubnodefilepath("C:\\Users\\llc\\Desktop\\copdemo\\GuidanceDemoUDP.pdm_diagram");

		root.addChild(c1);
		root.addChild(c2);
		root.addChild(c3);
		root.addChild(c4);
		root.addChild(c5);
		root.addChild(c6);

		nn.addChild(root);

		treeViewer.setInput(nn);
		treeViewer.expandAll();
		treeViewer.addSelectionChangedListener(new ISelectionChangedListener() {

			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				// TODO Auto-generated method stub
				TreeRightclickActionGroup actionGroup = new TreeRightclickActionGroup(
						treeViewer);// ����һ��ActionGroup����
				actionGroup.fillContextMenu(new MenuManager());// ����ťע�뵽�˵�������
			}
		});
	}

	/**
	 * Create the actions.
	 */
	private void createActions() {
		// Create the actions
	}

	/**
	 * Initialize the toolbar.
	 */
	private void initializeToolBar() {
		IToolBarManager toolbarManager = getViewSite().getActionBars()
				.getToolBarManager();
	}

	/**
	 * Initialize the menu.
	 */
	private void initializeMenu() {
		IMenuManager menuManager = getViewSite().getActionBars()
				.getMenuManager();
	}

	@Override
	public void setFocus() {
		// Set the focus
	}
}
