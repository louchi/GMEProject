package nwpu.samt.ui.face.dlgs;

import nwpu.samt.util.general.Util;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class DataTypeGenDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text pathText;
	private Label label_1;
	private Label label_2;
	private Combo combo;
	private Button button;
	private Button button_1;
	private Label label;
	private Button selectBtn;

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public DataTypeGenDialog(Shell parent, int style) {
		super(parent, style);
		setText("��������ģ��");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
		shell.setSize(618, 210);
		shell.setText(getText());
		shell.setLayout(new GridLayout(7, false));
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		label = new Label(shell, SWT.NONE);
		label.setText("\u8F93\u51FA\u8DEF\u5F84");
		new Label(shell, SWT.NONE);
		
		pathText = new Text(shell, SWT.BORDER);
		pathText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		new Label(shell, SWT.NONE);
		
		selectBtn = new Button(shell, SWT.NONE);
		selectBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				selectBtnWidgetSelected(evt);
			}
		});
		GridData gd_selectBtn = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_selectBtn.widthHint = 80;
		selectBtn.setLayoutData(gd_selectBtn);
		selectBtn.setText("\u9009\u62E9");
		
		label_1 = new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		label_2 = new Label(shell, SWT.NONE);
		label_2.setText("\u8BED\u8A00");
		new Label(shell, SWT.NONE);
		
		combo = new Combo(shell, SWT.READ_ONLY);
		combo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		combo.setText("\u9009\u62E9");
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		new Label(shell, SWT.NONE);
		
		button = new Button(shell, SWT.NONE);
		GridData gd_button = new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1);
		gd_button.widthHint = 80;
		button.setLayoutData(gd_button);
		button.setText("\u786E\u8BA4");
		new Label(shell, SWT.NONE);
		
		button_1 = new Button(shell, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.dispose();
			}
		});
		GridData gd_button_1 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_button_1.widthHint = 79;
		button_1.setLayoutData(gd_button_1);
		button_1.setText("\u53D6\u6D88");
		new Label(shell, SWT.NONE);
		
		
		init();

	}

	private void init() {
		// TODO Auto-generated method stub
		Util.setShellMiddle(shell);
		combo.add("C����ģ��");
		combo.add("C++����ģ��");
		combo.select(0);
	}
	protected void selectBtnWidgetSelected(SelectionEvent evt) {
		// TODO Auto-generated method stub
		DirectoryDialog dialog = new DirectoryDialog(shell);
		String path = dialog.open();
		if (path != null) {
			pathText.setText(path);
		}
	}
}
