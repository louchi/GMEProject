package nwpu.samt.ui.face.dlgs;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import nwpu.samt.core.prj.PrjMgr;
import nwpu.samt.core.prj.PrjMgrImpl;
import nwpu.samt.db.entity.Project;
import nwpu.samt.ui.Activator;
import nwpu.samt.ui.common.perspectives.InitPerspective;
import nwpu.samt.util.general.Util;
import nwpu.samt.util.i18n.I18nManager;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IPerspectiveDescriptor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;

public class NewFaceDialog extends Dialog {
	/**
	 * ���ʻ�
	 */
	I18nManager manager = I18nManager.getInstance(Activator.PLUGIN_ID);

	protected Object result;
	protected Shell shell;
	private Label facePrjLabel;
	private Label facePrjDescLabel;
	private Label prjNameLabel;
	private Label prjPathLabel;
	private Text prjNameText;
	private Text prjPathText;
	private Button selectBtn;
	private Button okBtn;
	private Button cancelBtn;

	private PrjMgr prjMgr = new PrjMgrImpl();

	/**
	 * Create the dialog.
	 * 
	 * @param parent
	 * @param style
	 */
	public NewFaceDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * 
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL);
		shell.setSize(531, 336);
		shell.setText(manager.getString("face.dialog.newFace"));

		Button btnNewButton = new Button(shell, SWT.NONE);
		btnNewButton.setImage(ResourceManager.getPluginImage("nwpu.samt.ui",
				"images/uml-start.png"));
		btnNewButton.setBounds(10, 10, 200, 167);

		facePrjLabel = new Label(shell, SWT.NONE);
		facePrjLabel.setFont(SWTResourceManager.getFont("΢���ź�", 15, SWT.BOLD));
		facePrjLabel.setBounds(243, 10, 111, 32);
		facePrjLabel.setText("FACE\u5DE5\u7A0B");

		facePrjDescLabel = new Label(shell, SWT.WRAP);
		facePrjDescLabel.setBounds(243, 48, 263, 129);
		facePrjDescLabel
				.setText("    FACE\u7684\u6280\u672F\u6807\u51C6\u5B9A\u4E49\u4E86\u8BA1\u7B97\u73AF\u5883\u548C\u63A5\u53E3\uFF0C\u4EE5\u534F\u52A9\u5F00\u53D1\u4FBF\u643A\u5F0F\u7EC4\u4EF6\u3002\u5BF9\u4E8E\u6B63\u5F0F\u53D1\u5E03\u7684\u6280\u672F\u6807\u51C6\u7684\u6BCF\u4E2A\u7248\u672C\uFF0C\u53EF\u4EE5\u4F7F\u7528FACE\u4E00\u81F4\u6027\u5DE5\u5177\u96C6\u6765\u786E\u5B9A\u7279\u5B9A\u7EC4\u4EF6\u662F\u5426\u6EE1\u8DB3FACE\u6280\u672F\u6807\u51C6\u3002\u4E00\u65E6\u8F6F\u4EF6\u4F9B\u5E94\u5546\u786E\u4FE1\u8F6F\u4EF6\u7EC4\u4EF6\u7B26\u5408\u8981\u6C42\uFF0C\u5219\u5C06\u4E00\u4E2A\u9A8C\u8BC1\u5305\u63D0\u4F9B\u7ED9\u72EC\u7ACB\u7684\u9A8C\u8BC1\u673A\u6784\u8FDB\u884C\u4E00\u81F4\u6027\u6D4B\u8BD5\u3002");

		prjNameLabel = new Label(shell, SWT.NONE);
		prjNameLabel.setBounds(10, 196, 61, 17);
		prjNameLabel.setText("\u9879\u76EE\u540D\u79F0\uFF1A");

		prjPathLabel = new Label(shell, SWT.NONE);
		prjPathLabel.setText("\u9879\u76EE\u8DEF\u5F84\uFF1A");
		prjPathLabel.setBounds(10, 232, 61, 17);

		prjNameText = new Text(shell, SWT.BORDER);
		prjNameText.setBounds(107, 190, 399, 23);

		prjPathText = new Text(shell, SWT.BORDER);
		prjPathText.setBounds(107, 226, 313, 23);

		selectBtn = new Button(shell, SWT.NONE);
		selectBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				selectBtnWidgetSelected(evt);
			}
		});
		selectBtn.setBounds(426, 222, 80, 27);
		selectBtn.setText("\u9009\u62E9");

		okBtn = new Button(shell, SWT.NONE);
		okBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				okBtnWidgetSelected(evt);
			}
		});
		okBtn.setText("\u786E\u5B9A");
		okBtn.setBounds(340, 271, 80, 27);

		cancelBtn = new Button(shell, SWT.NONE);
		cancelBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				cancelBtnWidgetSelected(evt);
			}
		});
		cancelBtn.setText("\u53D6\u6D88");
		cancelBtn.setBounds(426, 271, 80, 27);

		Util.setShellMiddle(shell);
		// ���ʻ�
		initI18N();
		// ��ʼ�����볤��
		initMaxInputLength();
		// ��ʼ����ʾ��Ϣ
		initToolTips();
		// ��ʼ��������Ϣ
		initDefault();

	}

	private void initI18N() {
		// TODO Auto-generated method stub

	}

	private void initMaxInputLength() {
		// TODO Auto-generated method stub

	}

	private void initToolTips() {
		// TODO Auto-generated method stub

	}

	private void initDefault() {
		// TODO Auto-generated method stub

	}

	/**
	 * ѡ����Ŀ����·��
	 * 
	 * @param evt
	 *            �û�����¼�
	 */
	protected void selectBtnWidgetSelected(SelectionEvent evt) {
		DirectoryDialog directoryDialog = new DirectoryDialog(shell);
		String path = directoryDialog.open();
		if (path != null) {
			prjPathText.setText(path);
		}
	}

	protected void okBtnWidgetSelected(SelectionEvent evt) {
		// TODO Auto-generated method stub
		if (!inputValidate()) {
			return;
		}
		// ��������Ϸ�
		Project prj = new Project();
		prj.setName(prjNameText.getText());
		prj.setPath(prjPathText.getText());

		Calendar ca = Calendar.getInstance();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// �������ڸ�ʽ
		System.out.println(df.format(ca.getTime()));// new Date()Ϊ��ȡ��ǰϵͳʱ��
		prj.setCreateDate(df.format(ca.getTime()));
		prj.setParadigm("face");

		prjMgr .setCurrentPrj(prj);
		
		IWorkbench workbench = Util.getWorkbench();
		IWorkbenchPage iworkbenchPage = workbench.getActiveWorkbenchWindow()
				.getActivePage();
		IPerspectiveDescriptor perspective = workbench.getPerspectiveRegistry()
				.findPerspectiveWithId(InitPerspective.ID); // perspective ��id
//		if (perspective != null) {
		iworkbenchPage.closeAllPerspectives(false, true);
		iworkbenchPage.setPerspective(perspective);
		
		// �����洴����Ŀ�ļ���
		Util.createDir(prj.getParadigm() + File.separator + prj.getName());
		
		shell.dispose();
	}

	/**
	 * ��֤���������Ƿ�Ϸ�
	 */
	private boolean inputValidate() {
		// TODO Auto-generated method stub
		String erroeMessage = "";
		int i = 0;
		if (prjNameText.getText() == null || prjNameText.getText().equals("")) {
			// ��Ŀ����Ϊ��
			i++;
			erroeMessage += i + "����Ŀ���Ʋ���Ϊ��" + "\r\n";
		} else if (!isPrjNameValid(prjNameText.getText())) {
			// ��Ŀ�������벻�Ϸ�
			i++;
			erroeMessage += i + "����Ŀ�������벻�Ϸ�����Ŀ����ֻ��Ϊ��ĸ���ֺ����Լ��»��ߣ��Ҳ��ܳ���50���ַ�"
					+ "\r\n";
		}

		if (prjPathText.getText() == null || prjPathText.getText().equals("")) {
			// ��Ŀ·��Ϊ��
			i++;
			erroeMessage += i + "����Ŀ·������Ϊ��" + "\r\n";
		} else if (!isPrjPathValid(prjPathText.getText())) {
			// ��Ŀ·�����벻�Ϸ�
			i++;
			erroeMessage += i + "����Ŀ·�����벻�Ϸ�����Ŀ·�����Ȳ�����500" + "\r\n";
		}

		if (!erroeMessage.equals("")) {
			MessageDialog.openError(shell, "����", erroeMessage);
			return false;
		}
		return true;
	}

	/**
	 * ��֤�������Ŀ�����Ƿ���ϱ�׼
	 * 
	 * @param prjName
	 * @return
	 */
	private boolean isPrjNameValid(String prjName) {
		String regEx = "[a-zA-Z0-9_\u4e00-\u9fa5]{0,50}"; // ��Ŀ����ֻ��Ϊ��ĸ���ֺ��֣��Ҳ��ܳ���50���ַ�
		Pattern pattern = Pattern.compile(regEx);
		Matcher matcher = pattern.matcher(prjName);
		return matcher.matches();
	}

	/**
	 * ��֤�������Ŀ·���Ƿ���ϱ�׼
	 * 
	 * @param prjPath
	 *            ��Ŀ·��
	 * @return
	 */
	private boolean isPrjPathValid(String prjPath) {
		String regEx = "[\\s\\S]*{0,500}";
		Pattern pattern = Pattern.compile(regEx);
		Matcher matcher = pattern.matcher(prjPath);
		return matcher.matches();
	}

	/**
	 * ȡ���½�face��Ŀ���رնԻ���
	 * 
	 * @param evt
	 */
	protected void cancelBtnWidgetSelected(SelectionEvent evt) {
		shell.dispose();
	}

}
