package nwpu.samt.ui.util;

import java.util.ArrayList;

import org.eclipse.ui.IActionFilter;

/**
 * ���ڵ�
 * @author ��贳�
 *
 */
public class TreeNode implements IActionFilter{
	private String name;
	
	private String type;
	
	private String kind;
	
	private TreeNode fatherNode;
	
	private ArrayList<TreeNode> childList = new ArrayList<TreeNode>();
	
	private String subnodefilepath;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the kind
	 */
	public String getKind() {
		return kind;
	}

	/**
	 * @param kind the kind to set
	 */
	public void setKind(String kind) {
		this.kind = kind;
	}

	/**
	 * @return the childList
	 */
	public ArrayList<TreeNode> getChildList() {
		return childList;
	}

	/**
	 * @param childList the childList to set
	 */
	public void setChildList(ArrayList<TreeNode> childList) {
		this.childList = childList;
	}
	
	public void addChild(TreeNode node) {
		childList.add(node);
	}
	
	public void removeChild(TreeNode node) {
		childList.remove(node);
	}

	public TreeNode getFatherNode() {
		return fatherNode;
	}

	public void setFatherNode(TreeNode fatherNode) {
		this.fatherNode = fatherNode;
	}

	@Override
	public boolean testAttribute(Object target, String name, String value) {
		// TODO Auto-generated method stub
		if (target instanceof TreeNode) {
			TreeNode node = (TreeNode)target;
			if (name.equals("kind") && value.equals(node.getKind())) {
				return true;
			}
		}
		
		
		return false;
	}

	/**
	 * @return the subnodefilepath
	 */
	public String getSubnodefilepath() {
		return subnodefilepath;
	}

	/**
	 * @param subnodefilepath the subnodefilepath to set
	 */
	public void setSubnodefilepath(String subnodefilepath) {
		this.subnodefilepath = subnodefilepath;
	}
	
	

}
