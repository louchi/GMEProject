package nwpu.samt.ui.util;

import nwpu.samt.core.prj.PrjMgr;
import nwpu.samt.core.prj.PrjMgrImpl;
import nwpu.samt.util.general.Util;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IContributionManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.CoolBar;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.Tree;

public class TreeRightclickActionGroup {
	private TreeViewer tv;
	
	private PrjMgr prjMgr = new PrjMgrImpl();

	public TreeRightclickActionGroup(TreeViewer treeViewer) {
		this.tv = treeViewer;
	}

	// ���ɲ˵�Menu����������Action����
	public void fillContextMenu(IMenuManager mgr) {
		// ��������Action���󵽲˵�������
		MenuManager menuManager = (MenuManager) mgr; // ����ת��
		
		
		if (prjMgr.getCurrentPrj()==null) {
			return;
		}
		// UML
		if (prjMgr.getCurrentPrj().getParadigm().equals("uml")) {
			fillUMLManager(menuManager);
		}
		
		// FACE
		if (prjMgr.getCurrentPrj().getParadigm().equals("face")) {
			fillFACEManager(menuManager);
		}
		
		// ����Menu��������Tree��
		Tree tree = tv.getTree();
		Menu menu = menuManager.createContextMenu(tree);
		tree.setMenu(menu);
	}
	
	private void fillUMLManager(MenuManager menuManager) {
		// TODO Auto-generated method stub
		menuManager.add(new NewUMLClassGraphic(tv));
		menuManager.add(new DeleteNode(tv));
		
	}

	private void fillFACEManager(MenuManager menuManager) {
		// TODO Auto-generated method stub
		TreeNode selectedNode = getSelectTreeNode();
		if (selectedNode == null) {
			return;
		}
		IMenuManager menuFolder = new MenuManager("Folder");
		IMenuManager menuAtom = new MenuManager("Atom");
		IMenuManager menuModel = new MenuManager("Model");
		IMenuManager menuReference = new MenuManager("Reference");
		
		// ���ڵ�
		if (selectedNode.getKind().equals("RootFolder")) {
			menuFolder.add(new NewFaceTreeNodeAction(tv, "Library"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "ARINC653OperatingSystem"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "POSIXOperatingSystem"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "DataModel"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "StandaloneTSS"));
		}
		// �ļ��нڵ�
		if (selectedNode.getKind().equals("Library")) {
			menuModel.add(new NewFaceTreeNodeAction(tv, "ARINC653OperatingSystem"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "POSIXOperatingSystem"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "DataModel"));
		}
		// ARINC653OperatingSystem�ڵ�
		if (selectedNode.getKind().equals("ARINC653OperatingSystem")) {
			menuAtom.add(new NewFaceTreeNodeAction(tv, "SamplingChannel"));
			menuAtom.add(new NewFaceTreeNodeAction(tv, "QueuingChannel"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "POSIXPartition"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "ARINC653Partition"));			
		}
		
			// POSIXPartition
			if (selectedNode.getKind().equals("POSIXPartition")) {
				menuAtom.add(new NewFaceTreeNodeAction(tv, "QueuingPort"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "SamplingPort"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "IOPortConfiguration"));
				menuReference.add(new NewFaceTreeNodeAction(tv, "StandaloneTSS_ref"));
				menuReference.add(new NewFaceTreeNodeAction(tv, "UoPSpace"));
			}
			// ARINC653Partition
			if (selectedNode.getKind().equals("ARINC653Partition")) {
				menuAtom.add(new NewFaceTreeNodeAction(tv, "MessageQueue"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "QueuingPort"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "SamplingPort"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "SharedMemory"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "TCPSocket"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "UDPSocket"));				
				menuModel.add(new NewFaceTreeNodeAction(tv, "IOPortConfiguration"));
				menuReference.add(new NewFaceTreeNodeAction(tv, "StandaloneTSS_ref"));
				menuReference.add(new NewFaceTreeNodeAction(tv, "UoPSpace"));
			}
				// IOPortConfiguration
				if (selectedNode.getKind().equals("IOPortConfiguration")) {
					menuAtom.add(new NewFaceTreeNodeAction(tv, "IOConfiguration_ARINC429"));
					menuAtom.add(new NewFaceTreeNodeAction(tv, "IOConfiguration_Analog"));
					menuAtom.add(new NewFaceTreeNodeAction(tv, "IOConfiguration_Discrete"));
					menuAtom.add(new NewFaceTreeNodeAction(tv, "IOConfiguration_MIL1553"));
					menuAtom.add(new NewFaceTreeNodeAction(tv, "IOConfiguration_Serial"));
					menuAtom.add(new NewFaceTreeNodeAction(tv, "IOThread"));
				}
			
		
		// POSIXOperatingSystem�ڵ�
		if (selectedNode.getKind().equals("POSIXOperatingSystem")) {
			menuAtom.add(new NewFaceTreeNodeAction(tv, "UDPSocket"));
			menuAtom.add(new NewFaceTreeNodeAction(tv, "TCPSocket"));
			menuAtom.add(new NewFaceTreeNodeAction(tv, "SharedMemory"));
			menuAtom.add(new NewFaceTreeNodeAction(tv, "MessageQueue"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "IOPortConfiguration"));
			menuReference.add(new NewFaceTreeNodeAction(tv, "StandaloneTSS_ref"));
			menuReference.add(new NewFaceTreeNodeAction(tv, "UopSpace"));
		}
		// DateModel�ڵ�
		if (selectedNode.getKind().equals("DataModel")) {
			menuModel.add(new NewFaceTreeNodeAction(tv, "ConceptualDateModel"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "LogicalDateModel"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "PlatformDateModel"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "UoPModel"));
		}
		
			// ConceptualDateModel
			if (selectedNode.getKind().equals("ConceptualDataModel")) {
				menuAtom.add(new NewFaceTreeNodeAction(tv, "Observable"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "Association"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "Entity"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "View"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "ConceptualDataModel"));
				menuReference.add(new NewFaceTreeNodeAction(tv, "Generalized_Entity"));
			}
			if (selectedNode.getKind().equals("Association")) {
				menuReference.add(new NewFaceTreeNodeAction(tv, "AssociatedEntity"));
				menuReference.add(new NewFaceTreeNodeAction(tv, "Composition"));
			}
			if (selectedNode.getKind().equals("Entity")) {
				menuReference.add(new NewFaceTreeNodeAction(tv, "Composition"));
			}
			if (selectedNode.getKind().equals("View")) {
				menuReference.add(new NewFaceTreeNodeAction(tv, "CharacteristicProjection"));
			}
			// LogicalDataModel
			if (selectedNode.getKind().equals("LogicalDataModel")) {
				menuAtom.add(new NewFaceTreeNodeAction(tv, "Boolean"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "Character"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "CoordinateSystemAxis"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "Integer"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "Landmark"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "Natural"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "NonNegativeReal"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "Real"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "String"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "Unit"));
				
				menuModel.add(new NewFaceTreeNodeAction(tv, "AffineConversion"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "Conversion"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "CoordinateSystem"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "Enumerated"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "Association"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "Entity"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "View"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "LogicalDataModel"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "Measurement"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "MeasurementAxis"));
				
				menuReference.add(new NewFaceTreeNodeAction(tv, "ConceptualEntity"));
				menuReference.add(new NewFaceTreeNodeAction(tv, "ConceptualObservable"));
				menuReference.add(new NewFaceTreeNodeAction(tv, "ConceptualView"));
				menuReference.add(new NewFaceTreeNodeAction(tv, "Conceptual_Entity"));
			}
			// PlatformDataModel
						if (selectedNode.getKind().equals("PlatformDataModel")) {
							menuAtom.add(new NewFaceTreeNodeAction(tv, "IDL_Boolean"));
							menuAtom.add(new NewFaceTreeNodeAction(tv, "IDL_Char"));
							menuAtom.add(new NewFaceTreeNodeAction(tv, "IDL_Double"));
							
							menuModel.add(new NewFaceTreeNodeAction(tv, "IDLStruct"));
							menuModel.add(new NewFaceTreeNodeAction(tv, "IDL_Enumeration"));
							menuModel.add(new NewFaceTreeNodeAction(tv, "Association"));
							menuModel.add(new NewFaceTreeNodeAction(tv, "Entity"));
							menuModel.add(new NewFaceTreeNodeAction(tv, "P_View"));
							menuModel.add(new NewFaceTreeNodeAction(tv, "PlatformDateModel"));
							
							menuReference.add(new NewFaceTreeNodeAction(tv, "LogicalAbstractMeasurement"));
							menuReference.add(new NewFaceTreeNodeAction(tv, "LogicalEntity"));
							menuReference.add(new NewFaceTreeNodeAction(tv, "LogicalView"));
							menuReference.add(new NewFaceTreeNodeAction(tv, "Generalized_Entity"));
						}
			// UoPModel
			if (selectedNode.getKind().equals("UoPModel")) {
				menuAtom.add(new NewFaceTreeNodeAction(tv, "ApplicationFramework"));
				menuAtom.add(new NewFaceTreeNodeAction(tv, "LanguageRunTime"));
				
				menuModel.add(new NewFaceTreeNodeAction(tv, "PlatformSpecificComponent"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "PortableComponent"));
				menuModel.add(new NewFaceTreeNodeAction(tv, "UoPModel"));
			}
		
		// StandaloneTSS�ڵ�
		if (selectedNode.getKind().equals("StandaloneTSS")) {
			menuAtom.add(new NewFaceTreeNodeAction(tv, "Mux"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "Demux"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "STSS_InboundPort"));
			menuModel.add(new NewFaceTreeNodeAction(tv, "STSS_OutboundPort"));
		}
		
		menuManager.add(menuFolder);
		menuManager.add(menuAtom);
		menuManager.add(menuModel);
		menuManager.add(menuReference);
		
		menuManager.add(new DeleteNode(tv));
	}
	
	
	private class NewFaceTreeNodeAction extends Action {
		TreeViewer tv;
		String nodeKind;
		public NewFaceTreeNodeAction(TreeViewer tv, String nodeKind) {
			this.tv = tv;
			this.nodeKind = nodeKind;
			setText("�½�" + nodeKind);
		}
		
		public void run() {
			TreeNode n = new TreeNode();
			n.setName("�½�" + nodeKind);
			n.setKind(nodeKind);
			n.setFatherNode(getSelectTreeNode());
			TreeContentProvider t = (TreeContentProvider) tv.getContentProvider();
			t.addChildren(getSelectTreeNode(), n);
			tv.refresh();
			tv.expandAll();
		}
	}

	
	
	private class NewUMLClassGraphic extends Action {
		TreeViewer tv;
		NewUMLClassGraphic(TreeViewer tv) {
			this.tv = tv;
			setText("�½�UML��ͼ");
		}
		public void run() {
			// TODO Auto-generated method stub
			org.eclipse.myTest.DrawUML.diagram.part.MyUMLCreationWizard wizard = new org.eclipse.myTest.DrawUML.diagram.part.MyUMLCreationWizard();
			wizard.init(Util.getWindow().getWorkbench(), StructuredSelection.EMPTY);
			WizardDialog wizardDialog = new WizardDialog(
			Util.getShell(), wizard);
			int i = wizardDialog.open();
			if (i == 0) {			
			TreeNode n = new TreeNode();
			n.setName("uml��ͼ");
			n.setKind("umlClass");
			n.setFatherNode(getSelectTreeNode());
			TreeContentProvider t = (TreeContentProvider) tv.getContentProvider();
			t.addChildren(getSelectTreeNode(), n);
			tv.refresh();
			tv.expandAll();}
		}
	}
	
	private class DeleteNode extends Action {
		TreeViewer tv;
		DeleteNode(TreeViewer tv) {
			this.tv = tv;
			setText("ɾ���ڵ�");
		}
		public void run () {
			TreeContentProvider t = (TreeContentProvider) tv.getContentProvider();
			t.removeChildren(getSelectTreeNode());
			tv.refresh();
			tv.expandAll();
		}
	}

	// Ϊ���ö��Զ���ķ�����ȡ�õ�ǰѡ��Ľ��
	private TreeNode getSelectTreeNode() {
		IStructuredSelection selection = (IStructuredSelection) tv
				.getSelection();
		return (TreeNode) (selection.getFirstElement());
	}
	
}
